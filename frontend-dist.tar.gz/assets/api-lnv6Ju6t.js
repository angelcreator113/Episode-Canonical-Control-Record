const A="",_="/api/v1";export{_ as A,A as a};
