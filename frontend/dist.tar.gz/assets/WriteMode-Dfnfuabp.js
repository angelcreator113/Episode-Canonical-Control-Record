import{j as e,L as ha}from"./index-DgWrH9lp.js";import{b as a,k as ua,u as xa}from"./react-vendor-Bbt6Sxdk.js";import{e as ys,f as $t,h as fa,M as ga,S as ba,B as ya,I as wa,N as ws,C as va,c as ja,L as Na,E as Sa}from"./ventureData-BjLkdWpw.js";import"./pdf-vendor-xECewt3f.js";import"./VoiceLayer-UnDYzzPl.js";const Ft=[{id:"unsettled_recognition",label:"Unsettled recognition",note:"They see themselves. They're not sure they like it.",acts:["act_1","act_2"],color:"#B85C38"},{id:"quiet_ache",label:"Quiet ache",note:"Something tender was touched. No resolution. Just the feeling.",acts:["act_1","act_2","act_3"],color:"#7B5EA7"},{id:"held_breath",label:"Held breath",note:"Something is about to happen. The reader can feel it but not name it yet.",acts:["act_2","act_3"],color:"#8B6914"},{id:"permission",label:"Permission",note:"The reader exhales. Something they were afraid to want has been named.",acts:["act_3","act_4"],color:"#4A7C59"},{id:"companionship",label:"Companionship",note:"They are not alone in this. That's all. That's enough.",acts:["act_1","act_2","act_3","act_4"],color:"#5B7FA6"},{id:"earned_momentum",label:"Earned momentum",note:"Something shifted. Not fixed — shifted. The next chapter pulls.",acts:["act_3","act_4","act_5"],color:"#4A7C59"},{id:"beautiful_incompleteness",label:"Beautiful incompleteness",note:"The chapter ended mid-thought. The reader carries it forward.",acts:["act_1","act_2","act_3"],color:"#C9A84C"},{id:"weight",label:"Weight",note:"Something landed. The reader will think about this later.",acts:["act_2","act_4","act_5"],color:"#5B4A6B"}];function ka({chapter:h,onExitChange:p}){const[b,r]=a.useState(!1),[_,T]=a.useState(h?.exit_emotion_note||""),[$,l]=a.useState(h?.exit_emotion==="custom"),j=h?.exit_emotion,C=Ft.find(y=>y.id===j),W=h?.pnos_act||"act_1",D=Ft.filter(y=>y.acts.includes(W)),N=Ft.filter(y=>!y.acts.includes(W));function F(y){l(!1),p?.({exit_emotion:y.id,exit_emotion_note:y.note})}function m(){_.trim()&&p?.({exit_emotion:"custom",exit_emotion_note:_.trim()})}return e.jsxs("div",{style:H.panel,children:[e.jsxs("div",{style:H.header,onClick:()=>r(!b),children:[e.jsxs("div",{style:H.headerLeft,children:[e.jsx("div",{style:H.eyebrow,children:"CHAPTER EXIT EMOTION"}),e.jsx("div",{style:H.preview,children:C?`${C.label} — ${C.note}`:$&&_?_:"What does the reader feel on the last line?"})]}),(C||$&&_)&&e.jsx("div",{style:{...H.chip,color:C?.color||"#C9A84C",borderColor:`${C?.color||"#C9A84C"}40`,background:`${C?.color||"#C9A84C"}0e`},children:C?.label||"Custom"}),e.jsx("div",{style:H.caret,children:b?"▲":"▼"})]}),b&&e.jsxs("div",{style:H.body,children:[e.jsx("div",{style:H.instruction,children:"Set this BEFORE drafting. The generator will shape the chapter's last 3–5 lines toward this feeling."}),e.jsxs("div",{style:H.section,children:[e.jsx("div",{style:H.sectionLabel,children:"FOR THIS ACT"}),e.jsx("div",{style:H.emotionGrid,children:D.map(y=>e.jsx(vs,{emotion:y,isSelected:j===y.id,onSelect:()=>F(y)},y.id))})]}),e.jsxs("div",{style:H.section,children:[e.jsx("div",{style:H.sectionLabel,children:"OTHER OPTIONS"}),e.jsx("div",{style:H.emotionGrid,children:N.map(y=>e.jsx(vs,{emotion:y,isSelected:j===y.id,onSelect:()=>F(y),dimmed:!0},y.id))})]}),e.jsxs("div",{style:H.section,children:[e.jsx("div",{style:H.sectionLabel,children:"WRITE YOUR OWN"}),e.jsxs("div",{style:H.customRow,children:[e.jsx("textarea",{style:{...H.customInput,borderColor:$&&_?"#C9A84C":"rgba(30,25,20,0.12)"},placeholder:"The reader closes the chapter feeling...",value:_,rows:2,onChange:y=>{T(y.target.value),l(!0)}}),e.jsx("button",{style:{...H.customSave,opacity:_.trim()?1:.4},onClick:m,disabled:!_.trim(),children:"Set →"})]})]}),(j||$&&_)&&e.jsx("button",{style:H.clearBtn,onClick:()=>{l(!1),p?.({exit_emotion:null,exit_emotion_note:null})},children:"Clear exit emotion"})]})]})}function vs({emotion:h,isSelected:p,onSelect:b,dimmed:r}){return e.jsxs("button",{style:{...H.emotionCard,borderColor:p?h.color:"rgba(30,25,20,0.08)",background:p?`${h.color}0e`:"white",opacity:r&&!p?.55:1},onClick:b,children:[e.jsx("div",{style:{...H.emotionLabel,color:p?h.color:"rgba(30,25,20,0.65)"},children:h.label}),e.jsx("div",{style:H.emotionNote,children:h.note})]})}const H={panel:{border:"1px solid rgba(30,25,20,0.1)",borderRadius:3,overflow:"hidden",marginBottom:10,background:"white"},header:{display:"flex",alignItems:"flex-start",gap:10,padding:"10px 14px",cursor:"pointer"},headerLeft:{flex:1,display:"flex",flexDirection:"column",gap:3},eyebrow:{fontFamily:"DM Mono, monospace",fontSize:7,letterSpacing:"0.2em",color:"rgba(30,25,20,0.3)"},preview:{fontFamily:"'Lora', 'Playfair Display', serif",fontSize:12.5,fontStyle:"italic",color:"rgba(30,25,20,0.55)",lineHeight:1.4},chip:{border:"1px solid",borderRadius:20,flexShrink:0,fontFamily:"DM Mono, monospace",fontSize:7.5,letterSpacing:"0.08em",padding:"2px 8px",alignSelf:"flex-start"},caret:{fontFamily:"DM Mono, monospace",fontSize:7,color:"rgba(30,25,20,0.2)"},body:{borderTop:"1px solid rgba(30,25,20,0.06)",padding:"12px 14px",display:"flex",flexDirection:"column",gap:12},instruction:{fontFamily:"DM Mono, monospace",fontSize:8,color:"rgba(30,25,20,0.35)",letterSpacing:"0.03em",lineHeight:1.6},section:{display:"flex",flexDirection:"column",gap:7},sectionLabel:{fontFamily:"DM Mono, monospace",fontSize:7.5,letterSpacing:"0.15em",color:"rgba(30,25,20,0.25)"},emotionGrid:{display:"flex",flexWrap:"wrap",gap:6},emotionCard:{border:"1px solid",borderRadius:2,padding:"8px 10px",cursor:"pointer",display:"flex",flexDirection:"column",gap:3,textAlign:"left",transition:"all 0.12s",maxWidth:200,minWidth:140},emotionLabel:{fontFamily:"DM Mono, monospace",fontSize:8.5,fontWeight:600,letterSpacing:"0.05em"},emotionNote:{fontFamily:"'Lora', 'Playfair Display', serif",fontSize:11,fontStyle:"italic",color:"rgba(30,25,20,0.4)",lineHeight:1.4},customRow:{display:"flex",gap:8,alignItems:"flex-start"},customInput:{flex:1,border:"1px solid",borderRadius:2,padding:"8px 10px",resize:"vertical",fontFamily:"'Lora', 'Playfair Display', serif",fontSize:12.5,fontStyle:"italic",color:"rgba(30,25,20,0.75)",lineHeight:1.5,outline:"none"},customSave:{background:"#C9A84C",border:"none",borderRadius:2,fontFamily:"DM Mono, monospace",fontSize:9,letterSpacing:"0.1em",color:"white",fontWeight:600,padding:"8px 14px",cursor:"pointer",flexShrink:0,transition:"opacity 0.12s"},clearBtn:{background:"none",border:"none",cursor:"pointer",fontFamily:"DM Mono, monospace",fontSize:7.5,letterSpacing:"0.08em",color:"rgba(30,25,20,0.25)",textDecoration:"underline",padding:0,alignSelf:"flex-start"}},Ca=[{id:"continue",icon:"→",label:"Continue",sub:"Write what happens next in their voice",endpoint:"/api/v1/memories/story-continue"},{id:"dialogue",icon:"“",label:"Their next line",sub:"What would they say right now",endpoint:"/api/v1/memories/ai-writer-action",action:"dialogue"},{id:"interior",icon:"◌",label:"Interior monologue",sub:"What they are thinking but not saying",endpoint:"/api/v1/memories/ai-writer-action",action:"interior"},{id:"reaction",icon:"↯",label:"Their reaction",sub:"How they respond to what just happened",endpoint:"/api/v1/memories/ai-writer-action",action:"reaction"},{id:"lala",icon:"✦",label:"Lala moment",sub:"The intrusive thought she would never post",endpoint:"/api/v1/memories/ai-writer-action",action:"lala",onlyFor:["special"]}],_a={pressure:"#B85C38",mirror:"#9B7FD4",support:"#4A9B6F",shadow:"#E08C3A",special:"#B8962E"};function Ta({chapterId:h,bookId:p,selectedCharacter:b,currentProse:r,chapterContext:_,onInsert:T}){const[$,l]=a.useState(null),[j,C]=a.useState(null),[W,D]=a.useState(!1),[N,F]=a.useState(null),m=_a[b?.type]||"#B8962E",y=b?.selected_name||b?.name,U=Ca.filter(v=>!v.onlyFor||v.onlyFor.includes(b?.type));async function Y(v){if(!b)return;l(v.id),C(null),F(null),D(!0);const V=r?r.slice(-600):"",ge={chapter_id:h,book_id:p,character_id:b.id,character:{name:y,type:b.type,role:b.role,belief_pressured:b.belief_pressured,emotional_function:b.emotional_function,writer_notes:b.writer_notes},recent_prose:V,chapter_context:_,action:v.action||v.id,length:"paragraph"};try{const Z=await(await fetch(v.endpoint,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(ge)})).json(),he=Z.content||Z.continuation||Z.text||Z.result||Z.suggestion||"";C(he)}catch{F("Generation failed. Try again.")}D(!1)}function me(){j&&(T?.(j),C(null),l(null))}function q(){C(null),l(null)}return b?e.jsxs("div",{style:O.root,children:[e.jsxs("div",{style:O.charHeader,children:[e.jsx("div",{style:{...O.charType,color:m},children:b.type}),e.jsx("div",{style:O.charName,children:y}),b.belief_pressured&&e.jsxs("div",{style:O.charBelief,children:["“",b.belief_pressured,"”"]})]}),!j&&e.jsx("div",{style:O.actions,children:U.map(v=>e.jsxs("button",{style:{...O.actionBtn,background:$===v.id&&W?`${m}10`:"transparent",borderColor:$===v.id?m:"rgba(28,24,20,0.1)",opacity:W&&$!==v.id?.4:1},onClick:()=>Y(v),disabled:W,children:[e.jsx("span",{style:{...O.actionIcon,color:m},children:v.icon}),e.jsxs("div",{style:O.actionText,children:[e.jsxs("div",{style:O.actionLabel,children:[v.label,W&&$===v.id&&e.jsxs("span",{style:O.spinner,children:[" ","◌"]})]}),e.jsx("div",{style:O.actionSub,children:v.sub})]})]},v.id))}),j&&e.jsxs("div",{style:O.resultPanel,children:[e.jsxs("div",{style:O.resultHeader,children:[e.jsx("div",{style:{...O.resultAction,color:m},children:U.find(v=>v.id===$)?.label||"Generated"}),e.jsx("button",{style:O.discardBtn,onClick:q,children:"✕"})]}),e.jsx("div",{style:O.resultText,children:j}),e.jsxs("div",{style:O.resultActions,children:[e.jsx("button",{style:{...O.insertBtn,background:m},onClick:me,children:"Insert into manuscript"}),e.jsx("button",{style:O.tryAgainBtn,onClick:()=>{const v=U.find(V=>V.id===$);v&&Y(v)},children:"Try again"})]})]}),N&&e.jsx("div",{style:O.error,children:N})]}):e.jsxs("div",{style:O.empty,children:[e.jsx("div",{style:O.emptyIcon,children:"◈"}),e.jsx("div",{style:O.emptyText,children:"Select a character from the picker above to write in their voice."})]})}const zt="#1C1814",pt="rgba(28,24,20,0.5)",js="rgba(28,24,20,0.25)",Aa="#FAF7F0",O={root:{display:"flex",flexDirection:"column",height:"100%",overflow:"hidden"},empty:{display:"flex",flexDirection:"column",alignItems:"center",justifyContent:"center",padding:"32px 16px",gap:12,textAlign:"center",flex:1},emptyIcon:{fontSize:22,color:js},emptyText:{fontFamily:"'Lora', Georgia, serif",fontStyle:"italic",fontSize:12,color:pt,lineHeight:1.6,maxWidth:200},charHeader:{padding:"12px 14px",borderBottom:"1px solid rgba(28,24,20,0.08)"},charType:{fontSize:7.5,letterSpacing:"0.15em",marginBottom:4,fontFamily:"'DM Mono', monospace"},charName:{fontFamily:"'Cormorant Garamond', Georgia, serif",fontSize:16,color:zt,marginBottom:4},charBelief:{fontFamily:"'Lora', Georgia, serif",fontStyle:"italic",fontSize:10,color:pt,lineHeight:1.5},actions:{display:"flex",flexDirection:"column",padding:"8px 0",overflowY:"auto",flex:1},actionBtn:{display:"flex",gap:10,padding:"10px 14px",border:"none",borderLeft:"2px solid",cursor:"pointer",textAlign:"left",transition:"all 0.12s ease",marginBottom:1},actionIcon:{fontSize:16,lineHeight:1,flexShrink:0,marginTop:2,fontFamily:"'Cormorant Garamond', Georgia, serif",width:18,textAlign:"center"},actionText:{flex:1},actionLabel:{fontSize:11,color:zt,letterSpacing:"0.02em",marginBottom:2,fontFamily:"'DM Mono', monospace"},actionSub:{fontSize:9,color:pt,lineHeight:1.4,fontFamily:"'Lora', Georgia, serif",fontStyle:"italic"},spinner:{opacity:.5},resultPanel:{flex:1,display:"flex",flexDirection:"column",padding:"12px 14px",gap:10,overflowY:"auto"},resultHeader:{display:"flex",justifyContent:"space-between",alignItems:"center"},resultAction:{fontSize:8,letterSpacing:"0.15em",fontFamily:"'DM Mono', monospace"},discardBtn:{background:"none",border:"none",color:js,fontSize:12,cursor:"pointer",padding:"2px 4px"},resultText:{fontFamily:"'Lora', Georgia, serif",fontStyle:"italic",fontSize:13,color:zt,lineHeight:1.8,flex:1,padding:"10px 12px",background:"rgba(28,24,20,0.03)",borderRadius:3,border:"1px solid rgba(28,24,20,0.08)"},resultActions:{display:"flex",flexDirection:"column",gap:6},insertBtn:{border:"none",borderRadius:3,padding:"10px",color:Aa,fontSize:9,letterSpacing:"0.1em",cursor:"pointer",fontFamily:"'DM Mono', monospace"},tryAgainBtn:{background:"none",border:"1px solid rgba(28,24,20,0.1)",borderRadius:3,padding:"8px",color:pt,fontSize:9,letterSpacing:"0.08em",cursor:"pointer",fontFamily:"'DM Mono', monospace"},error:{padding:"10px 14px",fontSize:10,color:"#B85C38",fontStyle:"italic",fontFamily:"'Lora', Georgia, serif"}},Qe="/api/v1",Xe=()=>{const h=localStorage.getItem("token")||sessionStorage.getItem("token");return{"Content-Type":"application/json",...h?{Authorization:`Bearer ${h}`}:{}}};function Da({bookId:h,chapters:p=[],onChaptersChange:b,book:r}){const[_,T]=a.useState({}),[$,l]=a.useState(null),[j,C]=a.useState(""),[W,D]=a.useState(null),[N,F]=a.useState(""),[m,y]=a.useState({}),[U,Y]=a.useState({}),[me,q]=a.useState(!1),[v,V]=a.useState(null),[ge,ne]=a.useState(null),Z=i=>T(S=>({...S,[i]:!S[i]})),he=p.map(i=>{const S=Array.isArray(i.sections)?i.sections:[],f=S.filter(B=>B.type==="h3");return{...i,scenes:f,allSections:S}}),c=he.reduce((i,S)=>i+S.scenes.length,0),d=a.useCallback(async(i,S)=>{const f=S||j;if(!f?.trim())return;const B=p.find(Se=>Se.id===i);if(!B)return;const k=Array.isArray(B.sections)?[...B.sections]:[],ee={id:`sec_${Date.now()}_${Math.random().toString(36).slice(2,8)}`,type:"h3",content:f.trim(),prose:""};k.push(ee);try{await fetch(`${Qe}/storyteller/chapters/${i}`,{method:"PUT",headers:Xe(),body:JSON.stringify({sections:k})}),b&&b()}catch(Se){console.error("Add scene error:",Se)}l(null),C("")},[j,p,b]),I=a.useCallback(async(i,S,f)=>{const B=p.find(ee=>ee.id===i);if(!B)return;const k=(Array.isArray(B.sections)?B.sections:[]).map(ee=>ee.id===S?{...ee,content:f}:ee);try{await fetch(`${Qe}/storyteller/chapters/${i}`,{method:"PUT",headers:Xe(),body:JSON.stringify({sections:k})}),b&&b()}catch(ee){console.error("Rename scene error:",ee)}D(null)},[p,b]),J=a.useCallback(async(i,S)=>{const f=p.find(k=>k.id===i);if(!f)return;const B=(Array.isArray(f.sections)?f.sections:[]).filter(k=>k.id!==S);try{await fetch(`${Qe}/storyteller/chapters/${i}`,{method:"PUT",headers:Xe(),body:JSON.stringify({sections:B})}),b&&b()}catch(k){console.error("Delete scene error:",k)}},[p,b]),Q=a.useCallback(async i=>{y(S=>({...S,[i.id]:!0})),ne(null);try{const S=(Array.isArray(i.sections)?i.sections:[]).filter(k=>k.type==="h3").map(k=>({content:k.content,title:k.content})),f=await fetch(`${Qe}/memories/scene-planner`,{method:"POST",headers:Xe(),body:JSON.stringify({book_id:h,chapter_id:i.id,chapter_title:i.title,chapter_type:i.chapter_type||"chapter",existing_scenes:S,draft_prose:i.draft_prose||"",book_title:r?.title||"",book_description:r?.description||"",all_chapters:p.map(k=>({id:k.id,title:k.title,chapter_type:k.chapter_type,scenes:(Array.isArray(k.sections)?k.sections:[]).filter(ee=>ee.type==="h3")})),theme:i.theme||"",scene_goal:i.scene_goal||""})}),B=await f.json();if(!f.ok)throw new Error(B.error||"AI request failed");Y(k=>({...k,[i.id]:B.suggestions||[]}))}catch(S){console.error("AI scene planner error:",S),ne(S.message)}finally{y(S=>({...S,[i.id]:!1}))}},[h,p,r,b]),ie=a.useCallback(async()=>{q(!0),ne(null);try{const i=await fetch(`${Qe}/memories/books/${h}/scenes`,{headers:Xe()}),S=await i.json();if(!i.ok)throw new Error(S.error||"AI request failed");V(S.scenes||S)}catch(i){console.error("Book AI scenes error:",i),ne(i.message)}finally{q(!1)}},[h]),A=a.useCallback(async(i,S)=>{await d(i,S.title),Y(f=>({...f,[i]:(f[i]||[]).filter(B=>B.title!==S.title)}))},[d]),be=a.useCallback(async i=>{const S=i.chapter_id?p.find(f=>f.id===i.chapter_id):p[0];S&&(await d(S.id,i.title),V(f=>f?f.filter(B=>B.title!==i.title):null))},[p,d]),ye=i=>i==="beginning"?"▶":i==="end"?"◀":"◆";return e.jsxs("div",{className:"scenes-panel",children:[e.jsxs("div",{className:"scenes-panel-header",children:[e.jsxs("div",{children:[e.jsx("h3",{className:"scenes-panel-title",children:"Scenes Overview"}),e.jsxs("span",{className:"scenes-panel-count",children:[c," scenes across ",p.length," chapters"]})]}),e.jsx("button",{className:"scenes-panel-ai-book-btn",onClick:ie,disabled:me,title:"AI analyzes your entire book and suggests scenes that would strengthen the arc",children:me?"⧖ Thinking…":"✨ AI Scene Architect"})]}),ge&&e.jsxs("div",{className:"scenes-panel-ai-error",children:[e.jsxs("span",{children:["⚠"," ",ge]}),e.jsx("button",{onClick:()=>ne(null),children:"×"})]}),v&&v.length>0&&e.jsxs("div",{className:"scenes-panel-ai-book-results",children:[e.jsxs("div",{className:"scenes-panel-ai-book-label",children:["✨"," AI Suggested Scenes for Your Book"]}),v.map((i,S)=>e.jsxs("div",{className:"scenes-panel-ai-card",children:[e.jsxs("div",{className:"scenes-panel-ai-card-head",children:[e.jsx("span",{className:"scenes-panel-ai-card-title",children:i.title}),i.chapter_hint&&e.jsx("span",{className:"scenes-panel-ai-card-ch",children:i.chapter_hint})]}),e.jsx("p",{className:"scenes-panel-ai-card-desc",children:i.description}),i.reason&&e.jsxs("p",{className:"scenes-panel-ai-card-reason",children:[e.jsx("span",{className:"scenes-panel-ai-card-reason-label",children:"Why:"})," ",i.reason]}),i.characters&&i.characters.length>0&&e.jsx("div",{className:"scenes-panel-ai-card-chars",children:i.characters.map(f=>e.jsx("span",{className:"scenes-panel-ai-char-tag",children:f},f))}),e.jsxs("div",{className:"scenes-panel-ai-card-actions",children:[e.jsxs("button",{className:"scenes-panel-ai-accept",onClick:()=>be(i),title:"Add this scene to the chapter",children:["✓"," Add Scene"]}),e.jsx("button",{className:"scenes-panel-ai-dismiss",onClick:()=>V(f=>f.filter((B,k)=>k!==S)),title:"Dismiss",children:"Dismiss"})]})]},S)),e.jsx("button",{className:"scenes-panel-ai-clear",onClick:()=>V(null),children:"Clear all suggestions"})]}),he.length===0?e.jsx("div",{className:"scenes-panel-empty",children:e.jsx("p",{children:"No chapters yet. Create chapters to start adding scenes."})}):e.jsx("div",{className:"scenes-panel-list",children:he.map((i,S)=>e.jsxs("div",{className:"scenes-panel-chapter",children:[e.jsxs("button",{className:`scenes-panel-chapter-btn${_[i.id]?" expanded":""}`,onClick:()=>Z(i.id),children:[e.jsxs("span",{className:"scenes-panel-ch-num",children:["Ch. ",i.chapter_number||S+1]}),i.chapter_type&&i.chapter_type!=="chapter"&&e.jsx("span",{className:"scenes-panel-ch-type",children:i.chapter_type}),e.jsx("span",{className:"scenes-panel-ch-title",children:i.title||"Untitled"}),e.jsxs("span",{className:"scenes-panel-ch-count",children:[i.scenes.length," scene",i.scenes.length!==1?"s":""]}),e.jsx("span",{className:"scenes-panel-ch-arrow",children:_[i.id]?"▾":"▸"})]}),_[i.id]&&e.jsxs("div",{className:"scenes-panel-scenes",children:[i.scenes.length===0?e.jsx("div",{className:"scenes-panel-no-scenes",children:"No scenes defined"}):i.scenes.map((f,B)=>e.jsxs("div",{className:"scenes-panel-scene",children:[e.jsx("span",{className:"scenes-panel-scene-num",children:B+1}),e.jsx("span",{className:"scenes-panel-scene-dinkus",children:"✦"}),W&&W.chId===i.id&&W.secId===f.id?e.jsx("input",{className:"scenes-panel-scene-edit",value:N,onChange:k=>F(k.target.value),onBlur:()=>I(i.id,f.id,N),onKeyDown:k=>{k.key==="Enter"&&I(i.id,f.id,N),k.key==="Escape"&&D(null)},autoFocus:!0}):e.jsx("span",{className:"scenes-panel-scene-title",onDoubleClick:()=>{D({chId:i.id,secId:f.id}),F(f.content||"")},title:"Double-click to rename",children:f.content||"Untitled Scene"}),e.jsx("button",{className:"scenes-panel-scene-del",onClick:()=>J(i.id,f.id),title:"Delete scene",children:"×"})]},f.id||B)),$===i.id?e.jsxs("div",{className:"scenes-panel-add-row",children:[e.jsx("input",{className:"scenes-panel-add-input",value:j,onChange:f=>C(f.target.value),onKeyDown:f=>{f.key==="Enter"&&d(i.id),f.key==="Escape"&&(l(null),C(""))},placeholder:"Scene title…",autoFocus:!0}),e.jsx("button",{className:"scenes-panel-add-confirm",onClick:()=>d(i.id),children:"✓"}),e.jsx("button",{className:"scenes-panel-add-cancel",onClick:()=>{l(null),C("")},children:"×"})]}):e.jsxs("div",{className:"scenes-panel-add-row-buttons",children:[e.jsx("button",{className:"scenes-panel-add-btn",onClick:()=>{l(i.id),C("")},children:"+ Add Scene"}),e.jsx("button",{className:"scenes-panel-ai-plan-btn",onClick:()=>Q(i),disabled:m[i.id],title:"AI reads your chapter and suggests scenes",children:m[i.id]?"⧖ Planning…":"✨ AI Plan Scenes"})]}),U[i.id]&&U[i.id].length>0&&e.jsxs("div",{className:"scenes-panel-ai-suggestions",children:[e.jsxs("div",{className:"scenes-panel-ai-label",children:["✨"," AI Suggestions"]}),U[i.id].map((f,B)=>e.jsxs("div",{className:"scenes-panel-ai-sug-card",children:[e.jsxs("div",{className:"scenes-panel-ai-sug-head",children:[e.jsx("span",{className:"scenes-panel-ai-sug-pos",title:f.suggested_position||"middle",children:ye(f.suggested_position)}),e.jsx("span",{className:"scenes-panel-ai-sug-title",children:f.title}),f.emotional_beat&&e.jsx("span",{className:"scenes-panel-ai-sug-beat",children:f.emotional_beat})]}),e.jsx("p",{className:"scenes-panel-ai-sug-desc",children:f.description}),f.purpose&&e.jsxs("p",{className:"scenes-panel-ai-sug-purpose",children:[e.jsx("span",{className:"scenes-panel-ai-sug-purpose-label",children:"Purpose:"})," ",f.purpose]}),e.jsxs("div",{className:"scenes-panel-ai-sug-actions",children:[e.jsxs("button",{className:"scenes-panel-ai-accept",onClick:()=>A(i.id,f),children:["✓"," Add Scene"]}),e.jsx("button",{className:"scenes-panel-ai-dismiss",onClick:()=>Y(k=>({...k,[i.id]:(k[i.id]||[]).filter((ee,Se)=>Se!==B)})),children:"Dismiss"})]})]},B)),e.jsx("button",{className:"scenes-panel-ai-clear",onClick:()=>Y(f=>({...f,[i.id]:[]})),children:"Clear suggestions"})]})]})]},i.id))}),e.jsx("style",{children:`
        .scenes-panel { padding: 24px; max-width: 760px; margin: 0 auto; }
        .scenes-panel-header {
          display: flex; align-items: flex-start; justify-content: space-between;
          margin-bottom: 24px; gap: 16px; flex-wrap: wrap;
        }
        .scenes-panel-title {
          font-family: 'Playfair Display', 'Lora', Georgia, serif;
          font-size: 20px; font-weight: 600; color: #1C1814; margin: 0 0 4px;
        }
        .scenes-panel-count {
          font-family: 'DM Mono', monospace; font-size: 10px;
          letter-spacing: 0.1em; color: rgba(28,24,20,0.4);
        }
        .scenes-panel-empty {
          text-align: center; padding: 48px 24px;
          font-family: 'Lora', Georgia, serif; font-style: italic;
          color: rgba(28,24,20,0.4); font-size: 14px;
        }

        /* ── Book-level AI button ── */
        .scenes-panel-ai-book-btn {
          background: linear-gradient(135deg, rgba(198,168,94,0.08), rgba(198,168,94,0.15));
          border: 1px solid rgba(198,168,94,0.25);
          border-radius: 6px; padding: 8px 16px;
          font-family: 'DM Mono', monospace; font-size: 10px;
          letter-spacing: 0.08em; color: #B8962E;
          cursor: pointer; transition: all 0.15s ease; white-space: nowrap;
        }
        .scenes-panel-ai-book-btn:hover:not(:disabled) {
          background: linear-gradient(135deg, rgba(198,168,94,0.15), rgba(198,168,94,0.25));
          border-color: rgba(198,168,94,0.4);
        }
        .scenes-panel-ai-book-btn:disabled { opacity: 0.6; cursor: wait; }

        /* ── AI error ── */
        .scenes-panel-ai-error {
          display: flex; align-items: center; justify-content: space-between;
          background: rgba(184,92,56,0.06); border: 1px solid rgba(184,92,56,0.15);
          border-radius: 6px; padding: 10px 14px; margin-bottom: 16px;
          font-family: 'DM Sans', sans-serif; font-size: 12px; color: #B85C38;
        }
        .scenes-panel-ai-error button {
          background: none; border: none; font-size: 16px;
          color: #B85C38; cursor: pointer;
        }

        /* ── Book-wide AI results ── */
        .scenes-panel-ai-book-results {
          background: rgba(198,168,94,0.03);
          border: 1px solid rgba(198,168,94,0.12);
          border-radius: 8px; padding: 16px; margin-bottom: 24px;
        }
        .scenes-panel-ai-book-label {
          font-family: 'DM Mono', monospace; font-size: 10px;
          letter-spacing: 0.12em; color: #B8962E; margin-bottom: 12px;
          text-transform: uppercase;
        }

        /* ── AI card (book-wide) ── */
        .scenes-panel-ai-card {
          background: rgba(250,248,245,0.8);
          border: 1px solid rgba(232,226,218,0.6);
          border-radius: 6px; padding: 12px 14px; margin-bottom: 10px;
        }
        .scenes-panel-ai-card-head {
          display: flex; align-items: baseline; gap: 8px; margin-bottom: 6px;
        }
        .scenes-panel-ai-card-title {
          font-family: 'Lora', Georgia, serif; font-size: 14px;
          font-weight: 600; color: #1C1814;
        }
        .scenes-panel-ai-card-ch {
          font-family: 'DM Mono', monospace; font-size: 9px;
          color: rgba(28,24,20,0.35); letter-spacing: 0.05em;
        }
        .scenes-panel-ai-card-desc {
          font-family: 'Lora', Georgia, serif; font-size: 12.5px;
          color: rgba(28,24,20,0.7); line-height: 1.5; margin: 0 0 6px;
        }
        .scenes-panel-ai-card-reason {
          font-family: 'DM Sans', sans-serif; font-size: 11px;
          color: rgba(28,24,20,0.45); margin: 0 0 6px; font-style: italic;
        }
        .scenes-panel-ai-card-reason-label {
          font-weight: 600; font-style: normal; color: rgba(28,24,20,0.5);
        }
        .scenes-panel-ai-card-chars {
          display: flex; gap: 4px; flex-wrap: wrap; margin-bottom: 8px;
        }
        .scenes-panel-ai-char-tag {
          font-family: 'DM Mono', monospace; font-size: 9px;
          background: rgba(198,168,94,0.1); color: #B8962E;
          border-radius: 3px; padding: 2px 6px;
        }
        .scenes-panel-ai-card-actions {
          display: flex; gap: 8px;
        }

        /* ── Per-chapter AI plan button ── */
        .scenes-panel-add-row-buttons {
          display: flex; align-items: center; gap: 12px; padding: 4px 0;
        }
        .scenes-panel-ai-plan-btn {
          background: none; border: none;
          font-family: 'DM Mono', monospace; font-size: 9px;
          letter-spacing: 0.08em; color: #B8962E;
          cursor: pointer; padding: 8px 0; transition: all 0.12s ease;
          opacity: 0.7;
        }
        .scenes-panel-ai-plan-btn:hover:not(:disabled) { opacity: 1; }
        .scenes-panel-ai-plan-btn:disabled { opacity: 0.5; cursor: wait; }

        /* ── AI suggestions per chapter ── */
        .scenes-panel-ai-suggestions {
          background: rgba(198,168,94,0.03);
          border: 1px solid rgba(198,168,94,0.1);
          border-radius: 6px; padding: 12px; margin-top: 8px;
        }
        .scenes-panel-ai-label {
          font-family: 'DM Mono', monospace; font-size: 9px;
          letter-spacing: 0.12em; color: #B8962E; margin-bottom: 10px;
          text-transform: uppercase;
        }
        .scenes-panel-ai-sug-card {
          background: rgba(250,248,245,0.8);
          border: 1px solid rgba(232,226,218,0.5);
          border-radius: 5px; padding: 10px 12px; margin-bottom: 8px;
        }
        .scenes-panel-ai-sug-head {
          display: flex; align-items: baseline; gap: 6px; margin-bottom: 4px;
        }
        .scenes-panel-ai-sug-pos {
          font-size: 8px; color: rgba(28,24,20,0.25);
        }
        .scenes-panel-ai-sug-title {
          font-family: 'Lora', Georgia, serif; font-size: 13px;
          font-weight: 600; color: #1C1814;
        }
        .scenes-panel-ai-sug-beat {
          font-family: 'DM Sans', sans-serif; font-size: 10px;
          color: #B8962E; font-style: italic; margin-left: auto;
        }
        .scenes-panel-ai-sug-desc {
          font-family: 'Lora', Georgia, serif; font-size: 12px;
          color: rgba(28,24,20,0.65); line-height: 1.45; margin: 0 0 4px;
        }
        .scenes-panel-ai-sug-purpose {
          font-family: 'DM Sans', sans-serif; font-size: 10.5px;
          color: rgba(28,24,20,0.4); margin: 0 0 6px; font-style: italic;
        }
        .scenes-panel-ai-sug-purpose-label {
          font-weight: 600; font-style: normal; color: rgba(28,24,20,0.45);
        }
        .scenes-panel-ai-sug-actions {
          display: flex; gap: 8px;
        }

        /* ── Shared AI action buttons ── */
        .scenes-panel-ai-accept {
          background: rgba(74,155,111,0.08); border: 1px solid rgba(74,155,111,0.2);
          border-radius: 4px; padding: 4px 10px;
          font-family: 'DM Mono', monospace; font-size: 9px;
          color: #4A9B6F; cursor: pointer; transition: all 0.12s ease;
        }
        .scenes-panel-ai-accept:hover {
          background: rgba(74,155,111,0.15); border-color: rgba(74,155,111,0.35);
        }
        .scenes-panel-ai-dismiss {
          background: none; border: none;
          font-family: 'DM Mono', monospace; font-size: 9px;
          color: rgba(28,24,20,0.3); cursor: pointer;
        }
        .scenes-panel-ai-dismiss:hover { color: rgba(28,24,20,0.5); }
        .scenes-panel-ai-clear {
          background: none; border: none;
          font-family: 'DM Mono', monospace; font-size: 9px;
          color: rgba(28,24,20,0.25); cursor: pointer;
          padding: 6px 0; margin-top: 4px;
        }
        .scenes-panel-ai-clear:hover { color: rgba(28,24,20,0.4); }

        /* ── Chapter type badge ── */
        .scenes-panel-ch-type {
          font-family: 'DM Mono', monospace; font-size: 8px;
          letter-spacing: 0.08em; text-transform: uppercase;
          color: #B8962E; background: rgba(198,168,94,0.08);
          border-radius: 3px; padding: 1px 5px;
        }

        /* ── Existing styles ── */
        .scenes-panel-chapter { margin-bottom: 2px; }
        .scenes-panel-chapter-btn {
          display: flex; align-items: center; gap: 10px; width: 100%;
          background: none; border: none; border-bottom: 1px solid rgba(28,24,20,0.06);
          padding: 12px 8px; cursor: pointer; text-align: left;
          transition: background 0.12s ease;
        }
        .scenes-panel-chapter-btn:hover { background: rgba(28,24,20,0.02); }
        .scenes-panel-ch-num {
          font-family: 'DM Mono', monospace; font-size: 10px;
          color: rgba(28,24,20,0.35); min-width: 40px;
        }
        .scenes-panel-ch-title {
          flex: 1; font-family: 'Lora', Georgia, serif; font-size: 14px; color: #1C1814;
        }
        .scenes-panel-ch-count {
          font-family: 'DM Mono', monospace; font-size: 9px;
          color: rgba(28,24,20,0.3); letter-spacing: 0.05em;
        }
        .scenes-panel-ch-arrow {
          font-size: 10px; color: rgba(28,24,20,0.3); min-width: 14px; text-align: center;
        }
        .scenes-panel-scenes {
          padding: 4px 0 12px 52px;
        }
        .scenes-panel-no-scenes {
          font-family: 'Lora', Georgia, serif; font-style: italic;
          font-size: 12px; color: rgba(28,24,20,0.3); padding: 8px 0;
        }
        .scenes-panel-scene {
          display: flex; align-items: center; gap: 8px;
          padding: 6px 0; font-family: 'Lora', Georgia, serif; font-size: 13px;
        }
        .scenes-panel-scene-num {
          font-family: 'DM Mono', monospace; font-size: 9px;
          color: rgba(28,24,20,0.25); min-width: 16px;
        }
        .scenes-panel-scene-dinkus {
          font-size: 8px; color: #B8962E; opacity: 0.6;
        }
        .scenes-panel-scene-title {
          color: #1C1814; cursor: default; flex: 1;
        }
        .scenes-panel-scene-title:hover { text-decoration: underline dotted rgba(28,24,20,0.2); }
        .scenes-panel-scene-edit {
          flex: 1; border: none; border-bottom: 1px solid rgba(184,150,46,0.4);
          background: none; font-family: 'Lora', Georgia, serif; font-size: 13px;
          color: #1C1814; padding: 2px 0; outline: none;
        }
        .scenes-panel-scene-del {
          background: none; border: none; font-size: 14px; color: rgba(28,24,20,0.2);
          cursor: pointer; padding: 2px 4px; opacity: 0; transition: opacity 0.1s ease;
        }
        .scenes-panel-scene:hover .scenes-panel-scene-del { opacity: 1; }
        .scenes-panel-scene-del:hover { color: #B85C38; }

        /* Add scene */
        .scenes-panel-add-btn {
          background: none; border: none; font-family: 'DM Mono', monospace;
          font-size: 9px; letter-spacing: 0.08em; color: rgba(28,24,20,0.35);
          cursor: pointer; padding: 8px 0; transition: color 0.12s ease;
        }
        .scenes-panel-add-btn:hover { color: #B8962E; }
        .scenes-panel-add-row {
          display: flex; align-items: center; gap: 6px; padding: 6px 0;
        }
        .scenes-panel-add-input {
          flex: 1; border: none; border-bottom: 1px solid rgba(28,24,20,0.12);
          background: none; font-family: 'Lora', Georgia, serif; font-size: 13px;
          color: #1C1814; padding: 4px 0; outline: none;
        }
        .scenes-panel-add-input:focus { border-bottom-color: rgba(184,150,46,0.4); }
        .scenes-panel-add-confirm,
        .scenes-panel-add-cancel {
          background: none; border: none; font-size: 14px;
          cursor: pointer; padding: 2px 4px; color: rgba(28,24,20,0.4);
        }
        .scenes-panel-add-confirm:hover { color: #4A9B6F; }
        .scenes-panel-add-cancel:hover { color: #B85C38; }

        @media (max-width: 480px) {
          .scenes-panel { padding: 16px 12px; }
          .scenes-panel-scenes { padding-left: 32px; }
          .scenes-panel-header { flex-direction: column; }
          .scenes-panel-ai-sug-head { flex-wrap: wrap; }
        }
      `})]})}const Rt="/api/v1",Ns=[{value:"prologue",label:"Prologue",icon:"◈"},{value:"chapter",label:"Chapter",icon:"§"},{value:"interlude",label:"Interlude",icon:"~"},{value:"epilogue",label:"Epilogue",icon:"◇"},{value:"afterword",label:"Afterword",icon:"∗"}],It=h=>{const p=[10,9,5,4,1],b=["X","IX","V","IV","I"];let r="";return p.forEach((_,T)=>{for(;h>=_;)r+=b[T],h-=_}),r||""},Ot=()=>{const h=localStorage.getItem("token")||sessionStorage.getItem("token");return{"Content-Type":"application/json",...h?{Authorization:`Bearer ${h}`}:{}}};function Ea({bookId:h,allChapters:p=[],onChapterUpdate:b,onReloadChapters:r}){const[_,T]=a.useState(null),[$,l]=a.useState(!0),[j,C]=a.useState("overview"),[W,D]=a.useState(!1),[N,F]=a.useState({dedication:"",epigraph:"",epigraph_attribution:"",foreword:"",preface:"",copyright:""}),[m,y]=a.useState({about_author:"",acknowledgments:"",glossary:"",appendix:"",bibliography:"",notes:""}),[U,Y]=a.useState("");a.useEffect(()=>{h&&(l(!0),fetch(`${Rt}/storyteller/books/${h}`,{headers:Ot()}).then(c=>c.json()).then(c=>{const d=c.book||c;T(d),Y(d.author_name||""),d.front_matter&&F(I=>({...I,...d.front_matter})),d.back_matter&&y(I=>({...I,...d.back_matter}))}).catch(console.error).finally(()=>l(!1)))},[h]);const me=a.useCallback(async()=>{if(h){D(!0);try{await fetch(`${Rt}/storyteller/books/${h}`,{method:"PUT",headers:Ot(),body:JSON.stringify({author_name:U,front_matter:N,back_matter:m})})}catch(c){console.error("Save book meta error:",c)}finally{D(!1)}}},[h,U,N,m]),q=a.useCallback(async(c,d)=>{try{await fetch(`${Rt}/storyteller/chapters/${c}`,{method:"PUT",headers:Ot(),body:JSON.stringify(d)}),b&&b(c,d)}catch(I){console.error("Save chapter meta error:",I)}},[b]),v=[...p].sort((c,d)=>(c.sort_order??c.chapter_number??0)-(d.sort_order??d.chapter_number??0)),V=v.reduce((c,d)=>{const I=d.part_number||0;return c[I]||(c[I]={number:I,title:d.part_title||"",chapters:[]}),c[I].chapters.push(d),c},{}),ge=Object.values(V).sort((c,d)=>c.number-d.number),ne=v.reduce((c,d)=>{const I=d.draft_prose?d.draft_prose.split(/\s+/).filter(Boolean).length:0;return c+I},0),Z=v.reduce((c,d)=>{const I=d.sections||[];return c+I.filter(J=>J.type==="h3").length},0),he=[{id:"overview",label:"Overview",icon:"📖"},{id:"front",label:"Front Matter",icon:"◈"},{id:"structure",label:"Parts & Chapters",icon:"§"},{id:"back",label:"Back Matter",icon:"◇"}];return $?e.jsx("div",{className:"bsp-loading",children:e.jsx("span",{className:"bsp-loading-text",children:"Loading book structure…"})}):e.jsxs("div",{className:"bsp-panel",children:[e.jsx("div",{className:"bsp-nav",children:he.map(c=>e.jsxs("button",{className:`bsp-nav-btn${j===c.id?" active":""}`,onClick:()=>C(c.id),children:[e.jsx("span",{className:"bsp-nav-icon",children:c.icon}),e.jsx("span",{className:"bsp-nav-label",children:c.label})]},c.id))}),j==="overview"&&e.jsxs("div",{className:"bsp-section",children:[e.jsxs("div",{className:"bsp-overview-header",children:[e.jsx("h2",{className:"bsp-title",children:_?.title||"Untitled"}),_?.subtitle&&e.jsx("p",{className:"bsp-subtitle",children:_.subtitle})]}),e.jsxs("div",{className:"bsp-stats-grid",children:[e.jsxs("div",{className:"bsp-stat",children:[e.jsx("span",{className:"bsp-stat-num",children:v.length}),e.jsx("span",{className:"bsp-stat-label",children:"Chapters"})]}),e.jsxs("div",{className:"bsp-stat",children:[e.jsx("span",{className:"bsp-stat-num",children:Z}),e.jsx("span",{className:"bsp-stat-label",children:"Scenes"})]}),e.jsxs("div",{className:"bsp-stat",children:[e.jsx("span",{className:"bsp-stat-num",children:ne.toLocaleString()}),e.jsx("span",{className:"bsp-stat-label",children:"Words"})]}),e.jsxs("div",{className:"bsp-stat",children:[e.jsx("span",{className:"bsp-stat-num",children:Math.max(1,Math.round(ne/250))}),e.jsx("span",{className:"bsp-stat-label",children:"Min Read"})]})]}),e.jsxs("div",{className:"bsp-outline",children:[e.jsx("h3",{className:"bsp-outline-title",children:"Book Outline"}),e.jsxs("div",{className:"bsp-outline-group",children:[e.jsx("span",{className:"bsp-outline-group-label",children:"Front Matter"}),e.jsxs("div",{className:"bsp-outline-pills",children:[N.dedication&&e.jsx("span",{className:"bsp-pill filled",children:"Dedication"}),N.epigraph&&e.jsx("span",{className:"bsp-pill filled",children:"Epigraph"}),N.foreword&&e.jsx("span",{className:"bsp-pill filled",children:"Foreword"}),N.preface&&e.jsx("span",{className:"bsp-pill filled",children:"Preface"}),N.copyright&&e.jsx("span",{className:"bsp-pill filled",children:"Copyright"}),!N.dedication&&!N.epigraph&&!N.foreword&&!N.preface&&!N.copyright&&e.jsx("span",{className:"bsp-pill empty",children:"None added yet"})]})]}),ge.map(c=>e.jsxs("div",{className:"bsp-outline-group",children:[c.number>0&&e.jsxs("span",{className:"bsp-outline-part-label",children:["Part ",It(c.number),c.title?` — ${c.title}`:""]}),c.number===0&&ge.length>1&&e.jsx("span",{className:"bsp-outline-part-label bsp-outline-part-unassigned",children:"Unassigned"}),c.chapters.map((d,I)=>{const J=Ns.find(A=>A.value===(d.chapter_type||"chapter")),Q=d.draft_prose?d.draft_prose.split(/\s+/).filter(Boolean).length:0,ie=(d.sections||[]).filter(A=>A.type==="h3").length;return e.jsxs("div",{className:"bsp-outline-chapter",children:[e.jsx("span",{className:"bsp-outline-ch-icon",children:J?.icon||"§"}),e.jsx("span",{className:"bsp-outline-ch-type",children:J?.label||"Chapter"}),e.jsx("span",{className:"bsp-outline-ch-title",children:d.title||"Untitled"}),e.jsxs("span",{className:"bsp-outline-ch-meta",children:[ie>0&&`${ie} scene${ie>1?"s":""}`,ie>0&&Q>0&&" · ",Q>0&&`${Q.toLocaleString()}w`]})]},d.id)})]},c.number)),e.jsxs("div",{className:"bsp-outline-group",children:[e.jsx("span",{className:"bsp-outline-group-label",children:"Back Matter"}),e.jsxs("div",{className:"bsp-outline-pills",children:[m.about_author&&e.jsx("span",{className:"bsp-pill filled",children:"About the Author"}),m.acknowledgments&&e.jsx("span",{className:"bsp-pill filled",children:"Acknowledgments"}),m.glossary&&e.jsx("span",{className:"bsp-pill filled",children:"Glossary"}),m.appendix&&e.jsx("span",{className:"bsp-pill filled",children:"Appendix"}),m.bibliography&&e.jsx("span",{className:"bsp-pill filled",children:"Bibliography"}),m.notes&&e.jsx("span",{className:"bsp-pill filled",children:"Notes"}),!m.about_author&&!m.acknowledgments&&!m.glossary&&!m.appendix&&!m.bibliography&&!m.notes&&e.jsx("span",{className:"bsp-pill empty",children:"None added yet"})]})]})]})]}),j==="front"&&e.jsxs("div",{className:"bsp-section",children:[e.jsxs("div",{className:"bsp-section-header",children:[e.jsx("h3",{className:"bsp-section-title",children:"Front Matter"}),e.jsx("p",{className:"bsp-section-desc",children:"These pages appear before Chapter 1 in your manuscript."})]}),e.jsxs("div",{className:"bsp-field",children:[e.jsx("label",{className:"bsp-field-label",children:"Author Name"}),e.jsx("input",{className:"bsp-input",value:U,onChange:c=>Y(c.target.value),placeholder:"Your name as it appears on the title page"})]}),e.jsxs("div",{className:"bsp-field",children:[e.jsx("label",{className:"bsp-field-label",children:"Copyright Page"}),e.jsx("textarea",{className:"bsp-textarea",value:N.copyright,onChange:c=>F(d=>({...d,copyright:c.target.value})),placeholder:`© ${new Date().getFullYear()} ${U||"[Author Name]"}. All rights reserved.

No part of this publication may be reproduced...`,rows:4})]}),e.jsxs("div",{className:"bsp-field",children:[e.jsx("label",{className:"bsp-field-label",children:"Dedication"}),e.jsx("textarea",{className:"bsp-textarea bsp-textarea--short",value:N.dedication,onChange:c=>F(d=>({...d,dedication:c.target.value})),placeholder:"For those who dare to imagine…",rows:2})]}),e.jsxs("div",{className:"bsp-field",children:[e.jsx("label",{className:"bsp-field-label",children:"Epigraph"}),e.jsx("textarea",{className:"bsp-textarea bsp-textarea--short",value:N.epigraph,onChange:c=>F(d=>({...d,epigraph:c.target.value})),placeholder:"A quote that sets the tone for the entire work…",rows:2}),e.jsx("input",{className:"bsp-input bsp-input--secondary",value:N.epigraph_attribution,onChange:c=>F(d=>({...d,epigraph_attribution:c.target.value})),placeholder:"— Attribution (e.g., Virginia Woolf)"})]}),e.jsxs("div",{className:"bsp-field",children:[e.jsx("label",{className:"bsp-field-label",children:"Foreword"}),e.jsx("p",{className:"bsp-field-hint",children:"Written by someone other than the author — an endorsement or context-setting piece."}),e.jsx("textarea",{className:"bsp-textarea",value:N.foreword,onChange:c=>F(d=>({...d,foreword:c.target.value})),placeholder:"Press Enter to begin your foreword…",rows:6})]}),e.jsxs("div",{className:"bsp-field",children:[e.jsx("label",{className:"bsp-field-label",children:"Preface"}),e.jsx("p",{className:"bsp-field-hint",children:"Written by the author — explains why you wrote this book and how to read it."}),e.jsx("textarea",{className:"bsp-textarea",value:N.preface,onChange:c=>F(d=>({...d,preface:c.target.value})),placeholder:"Press Enter to begin your preface…",rows:6})]}),e.jsx("div",{className:"bsp-save-row",children:e.jsx("button",{className:"bsp-save-btn",onClick:me,disabled:W,children:W?"Saving…":"Save Front Matter"})})]}),j==="structure"&&e.jsxs("div",{className:"bsp-section",children:[e.jsxs("div",{className:"bsp-section-header",children:[e.jsx("h3",{className:"bsp-section-title",children:"Parts & Chapters"}),e.jsx("p",{className:"bsp-section-desc",children:"Organize chapters into Parts/Acts and set chapter types (Prologue, Interlude, Epilogue, etc.)."})]}),v.map((c,d)=>{const I=c.chapter_type||"chapter",J=c.part_number||0,Q=d>0?v[d-1].part_number||0:-1,ie=J!==Q&&J>0;return e.jsxs("div",{children:[ie&&e.jsxs("div",{className:"bsp-part-header",children:[e.jsxs("span",{className:"bsp-part-numeral",children:["Part ",It(J)]}),e.jsx("input",{className:"bsp-part-title-input",value:c.part_title||"",onChange:A=>{const be=A.target.value;v.filter(ye=>ye.part_number===J).forEach(ye=>{q(ye.id,{part_title:be})})},placeholder:"Part title (optional)"})]}),e.jsxs("div",{className:"bsp-chapter-row",children:[e.jsxs("div",{className:"bsp-ch-left",children:[e.jsx("span",{className:"bsp-ch-num",children:c.chapter_number||d+1}),e.jsx("span",{className:"bsp-ch-title",children:c.title||"Untitled"})]}),e.jsxs("div",{className:"bsp-ch-controls",children:[e.jsx("select",{className:"bsp-select",value:I,onChange:A=>q(c.id,{chapter_type:A.target.value}),children:Ns.map(A=>e.jsxs("option",{value:A.value,children:[A.icon," ",A.label]},A.value))}),e.jsxs("select",{className:"bsp-select bsp-select--part",value:J,onChange:A=>q(c.id,{part_number:parseInt(A.target.value)||null,part_title:A.target.value==0?null:c.part_title}),children:[e.jsx("option",{value:0,children:"No Part"}),[1,2,3,4,5,6,7,8].map(A=>e.jsxs("option",{value:A,children:["Part ",It(A)]},A))]}),(()=>{const A=(c.sections||[]).filter(be=>be.type==="h3").length;return A>0?e.jsxs("span",{className:"bsp-scene-badge",children:[A," scene",A>1?"s":""]}):null})()]})]})]},c.id)}),v.length===0&&e.jsx("div",{className:"bsp-empty",children:"No chapters yet. Add chapters from the TOC sidebar."})]}),j==="back"&&e.jsxs("div",{className:"bsp-section",children:[e.jsxs("div",{className:"bsp-section-header",children:[e.jsx("h3",{className:"bsp-section-title",children:"Back Matter"}),e.jsx("p",{className:"bsp-section-desc",children:"These pages appear after the final chapter."})]}),e.jsxs("div",{className:"bsp-field",children:[e.jsx("label",{className:"bsp-field-label",children:"About the Author"}),e.jsx("textarea",{className:"bsp-textarea",value:m.about_author,onChange:c=>y(d=>({...d,about_author:c.target.value})),placeholder:"A short biography — who you are, what you write, where you live…",rows:5})]}),e.jsxs("div",{className:"bsp-field",children:[e.jsx("label",{className:"bsp-field-label",children:"Acknowledgments"}),e.jsx("textarea",{className:"bsp-textarea",value:m.acknowledgments,onChange:c=>y(d=>({...d,acknowledgments:c.target.value})),placeholder:"Thank the people and forces that made this book possible…",rows:5})]}),e.jsxs("div",{className:"bsp-field",children:[e.jsx("label",{className:"bsp-field-label",children:"Glossary"}),e.jsxs("p",{className:"bsp-field-hint",children:["Define specialized terms used in your book. One term per line: ",e.jsx("em",{children:"Term — Definition"})]}),e.jsx("textarea",{className:"bsp-textarea",value:m.glossary,onChange:c=>y(d=>({...d,glossary:c.target.value})),placeholder:"Chronoweave — The fabric of intersecting timelines…\\nEchostone — A memory artifact that replays…",rows:6})]}),e.jsxs("div",{className:"bsp-field",children:[e.jsx("label",{className:"bsp-field-label",children:"Appendix"}),e.jsx("textarea",{className:"bsp-textarea",value:m.appendix,onChange:c=>y(d=>({...d,appendix:c.target.value})),placeholder:"Supplementary material, tables, maps, or charts…",rows:5})]}),e.jsxs("div",{className:"bsp-field",children:[e.jsx("label",{className:"bsp-field-label",children:"Bibliography / References"}),e.jsx("textarea",{className:"bsp-textarea",value:m.bibliography,onChange:c=>y(d=>({...d,bibliography:c.target.value})),placeholder:"Sources, references, or further reading…",rows:4})]}),e.jsxs("div",{className:"bsp-field",children:[e.jsx("label",{className:"bsp-field-label",children:"Author's Notes / Endnotes"}),e.jsx("textarea",{className:"bsp-textarea",value:m.notes,onChange:c=>y(d=>({...d,notes:c.target.value})),placeholder:"Behind-the-scenes thoughts, research notes, or endnotes…",rows:4})]}),e.jsx("div",{className:"bsp-save-row",children:e.jsx("button",{className:"bsp-save-btn",onClick:me,disabled:W,children:W?"Saving…":"Save Back Matter"})})]}),e.jsx("style",{children:`
/* ═══ BookStructurePanel Styles ═══ */
.bsp-panel {
  display: flex;
  flex-direction: column;
  height: 100%;
  overflow: hidden;
  background: #FAF7F0;
}
.bsp-loading {
  display: flex;
  align-items: center;
  justify-content: center;
  height: 300px;
  font-family: 'Lora', Georgia, serif;
  font-style: italic;
  color: rgba(28, 24, 20, 0.4);
  font-size: 14px;
}

/* ── Nav ── */
.bsp-nav {
  display: flex;
  gap: 0;
  border-bottom: 1px solid rgba(28, 24, 20, 0.08);
  padding: 0 12px;
  background: #FAF7F0;
  flex-shrink: 0;
  overflow-x: auto;
  -webkit-overflow-scrolling: touch;
}
.bsp-nav-btn {
  display: flex;
  align-items: center;
  gap: 6px;
  background: none;
  border: none;
  border-bottom: 2px solid transparent;
  padding: 10px 14px 8px;
  font-family: 'DM Mono', monospace;
  font-size: 10px;
  letter-spacing: 0.08em;
  color: rgba(28, 24, 20, 0.4);
  cursor: pointer;
  transition: all 0.12s ease;
  white-space: nowrap;
}
.bsp-nav-btn:hover { color: rgba(28, 24, 20, 0.7); }
.bsp-nav-btn.active {
  color: #1C1814;
  border-bottom-color: #B8962E;
}
.bsp-nav-icon { font-size: 12px; }

/* ── Section ── */
.bsp-section {
  flex: 1;
  overflow-y: auto;
  padding: 20px 24px 40px;
  max-width: 720px;
  margin: 0 auto;
  width: 100%;
}
.bsp-section-header { margin-bottom: 24px; }
.bsp-section-title {
  font-family: 'Lora', Georgia, serif;
  font-size: 18px;
  font-weight: 500;
  color: #1C1814;
  margin: 0 0 6px;
}
.bsp-section-desc {
  font-family: 'Spectral', Georgia, serif;
  font-size: 13px;
  color: rgba(28, 24, 20, 0.5);
  margin: 0;
  line-height: 1.6;
}

/* ── Overview ── */
.bsp-overview-header { text-align: center; padding: 16px 0 24px; }
.bsp-title {
  font-family: 'Lora', Georgia, serif;
  font-size: 24px;
  font-weight: 500;
  font-style: italic;
  color: #1C1814;
  margin: 0 0 4px;
}
.bsp-subtitle {
  font-family: 'Spectral', Georgia, serif;
  font-size: 14px;
  color: rgba(28, 24, 20, 0.5);
  margin: 0;
}

/* Stats grid */
.bsp-stats-grid {
  display: grid;
  grid-template-columns: repeat(4, 1fr);
  gap: 12px;
  margin-bottom: 28px;
}
.bsp-stat {
  display: flex;
  flex-direction: column;
  align-items: center;
  padding: 14px 8px;
  border: 1px solid rgba(28, 24, 20, 0.06);
  border-radius: 4px;
  background: #FFFDF9;
}
.bsp-stat-num {
  font-family: 'DM Mono', monospace;
  font-size: 20px;
  color: #1C1814;
  font-weight: 500;
}
.bsp-stat-label {
  font-family: 'DM Mono', monospace;
  font-size: 8px;
  letter-spacing: 0.15em;
  color: rgba(28, 24, 20, 0.35);
  text-transform: uppercase;
  margin-top: 4px;
}

/* Outline */
.bsp-outline { margin-top: 8px; }
.bsp-outline-title {
  font-family: 'DM Mono', monospace;
  font-size: 9px;
  letter-spacing: 0.15em;
  color: rgba(28, 24, 20, 0.3);
  text-transform: uppercase;
  margin: 0 0 16px;
  padding-bottom: 8px;
  border-bottom: 1px solid rgba(28, 24, 20, 0.06);
}
.bsp-outline-group { margin-bottom: 16px; }
.bsp-outline-group-label {
  font-family: 'DM Mono', monospace;
  font-size: 8px;
  letter-spacing: 0.12em;
  color: rgba(28, 24, 20, 0.35);
  text-transform: uppercase;
  display: block;
  margin-bottom: 8px;
}
.bsp-outline-part-label {
  font-family: 'Lora', Georgia, serif;
  font-size: 13px;
  font-weight: 600;
  color: #B8962E;
  display: block;
  margin-bottom: 8px;
  padding: 6px 0;
  border-bottom: 1px solid rgba(184, 150, 46, 0.15);
}
.bsp-outline-part-unassigned { color: rgba(28, 24, 20, 0.3); }
.bsp-outline-pills { display: flex; flex-wrap: wrap; gap: 6px; }
.bsp-pill {
  font-family: 'DM Mono', monospace;
  font-size: 9px;
  letter-spacing: 0.05em;
  padding: 4px 10px;
  border-radius: 3px;
  border: 1px solid rgba(28, 24, 20, 0.08);
}
.bsp-pill.filled { background: rgba(184, 150, 46, 0.08); color: #8A7434; border-color: rgba(184, 150, 46, 0.2); }
.bsp-pill.empty { color: rgba(28, 24, 20, 0.3); font-style: italic; }

.bsp-outline-chapter {
  display: flex;
  align-items: center;
  gap: 8px;
  padding: 6px 0 6px 8px;
  border-bottom: 1px solid rgba(28, 24, 20, 0.04);
}
.bsp-outline-ch-icon { font-size: 11px; color: rgba(28, 24, 20, 0.3); width: 16px; text-align: center; }
.bsp-outline-ch-type {
  font-family: 'DM Mono', monospace;
  font-size: 8px;
  letter-spacing: 0.08em;
  color: rgba(28, 24, 20, 0.35);
  text-transform: uppercase;
  min-width: 60px;
}
.bsp-outline-ch-title {
  font-family: 'Spectral', Georgia, serif;
  font-size: 14px;
  color: #1C1814;
  flex: 1;
  min-width: 0;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}
.bsp-outline-ch-meta {
  font-family: 'DM Mono', monospace;
  font-size: 9px;
  color: rgba(28, 24, 20, 0.3);
  white-space: nowrap;
}

/* ── Fields (Front/Back matter) ── */
.bsp-field { margin-bottom: 20px; }
.bsp-field-label {
  display: block;
  font-family: 'DM Mono', monospace;
  font-size: 10px;
  letter-spacing: 0.1em;
  color: rgba(28, 24, 20, 0.5);
  text-transform: uppercase;
  margin-bottom: 6px;
}
.bsp-field-hint {
  font-family: 'Spectral', Georgia, serif;
  font-size: 12px;
  color: rgba(28, 24, 20, 0.4);
  font-style: italic;
  margin: 0 0 8px;
  line-height: 1.5;
}
.bsp-input,
.bsp-textarea {
  width: 100%;
  border: 1px solid rgba(28, 24, 20, 0.1);
  border-radius: 3px;
  padding: 10px 14px;
  font-family: 'Spectral', Georgia, serif;
  font-size: 14px;
  line-height: 1.7;
  color: #1C1814;
  background: #FFFDF9;
  outline: none;
  transition: border-color 0.12s ease;
  box-sizing: border-box;
}
.bsp-input:focus,
.bsp-textarea:focus {
  border-color: rgba(184, 150, 46, 0.4);
}
.bsp-input--secondary {
  margin-top: 6px;
  font-style: italic;
  color: rgba(28, 24, 20, 0.6);
  font-size: 13px;
}
.bsp-textarea { resize: vertical; min-height: 60px; }
.bsp-textarea--short { min-height: 40px; }

.bsp-save-row {
  display: flex;
  justify-content: flex-end;
  margin-top: 24px;
  padding-top: 16px;
  border-top: 1px solid rgba(28, 24, 20, 0.06);
}
.bsp-save-btn {
  background: #1C1814;
  color: #FAF7F0;
  border: none;
  border-radius: 3px;
  padding: 10px 28px;
  font-family: 'DM Mono', monospace;
  font-size: 10px;
  letter-spacing: 0.1em;
  cursor: pointer;
  transition: opacity 0.12s ease;
}
.bsp-save-btn:hover { opacity: 0.85; }
.bsp-save-btn:disabled { opacity: 0.5; cursor: not-allowed; }

/* ── Parts & Chapters ── */
.bsp-part-header {
  display: flex;
  align-items: center;
  gap: 12px;
  padding: 14px 0 8px;
  border-top: 2px solid rgba(184, 150, 46, 0.2);
  margin-top: 16px;
}
.bsp-part-header:first-child { margin-top: 0; }
.bsp-part-numeral {
  font-family: 'Lora', Georgia, serif;
  font-size: 14px;
  font-weight: 600;
  color: #B8962E;
  white-space: nowrap;
}
.bsp-part-title-input {
  flex: 1;
  background: none;
  border: none;
  border-bottom: 1px solid rgba(28, 24, 20, 0.08);
  padding: 4px 0;
  font-family: 'Spectral', Georgia, serif;
  font-size: 14px;
  color: #1C1814;
  outline: none;
}
.bsp-part-title-input:focus { border-bottom-color: rgba(184, 150, 46, 0.4); }

.bsp-chapter-row {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 10px 0;
  border-bottom: 1px solid rgba(28, 24, 20, 0.04);
  gap: 12px;
  flex-wrap: wrap;
}
.bsp-ch-left {
  display: flex;
  align-items: center;
  gap: 10px;
  min-width: 0;
  flex: 1;
}
.bsp-ch-num {
  font-family: 'DM Mono', monospace;
  font-size: 11px;
  color: rgba(28, 24, 20, 0.3);
  width: 24px;
  text-align: right;
  flex-shrink: 0;
}
.bsp-ch-title {
  font-family: 'Spectral', Georgia, serif;
  font-size: 14px;
  color: #1C1814;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}
.bsp-ch-controls {
  display: flex;
  align-items: center;
  gap: 8px;
  flex-shrink: 0;
}
.bsp-select {
  background: #FFFDF9;
  border: 1px solid rgba(28, 24, 20, 0.1);
  border-radius: 3px;
  padding: 5px 8px;
  font-family: 'DM Mono', monospace;
  font-size: 9px;
  color: #1C1814;
  cursor: pointer;
  outline: none;
}
.bsp-select:focus { border-color: rgba(184, 150, 46, 0.4); }
.bsp-select--part { min-width: 85px; }
.bsp-scene-badge {
  font-family: 'DM Mono', monospace;
  font-size: 8px;
  letter-spacing: 0.08em;
  color: rgba(28, 24, 20, 0.35);
  background: rgba(28, 24, 20, 0.04);
  padding: 3px 8px;
  border-radius: 10px;
  white-space: nowrap;
}

.bsp-empty {
  text-align: center;
  padding: 32px 16px;
  font-family: 'Lora', Georgia, serif;
  font-style: italic;
  color: rgba(28, 24, 20, 0.35);
  font-size: 14px;
}

/* ── Mobile responsive ── */
@media (max-width: 480px) {
  .bsp-section { padding: 16px 12px 32px; }
  .bsp-stats-grid { grid-template-columns: repeat(2, 1fr); }
  .bsp-chapter-row { flex-direction: column; align-items: flex-start; gap: 8px; }
  .bsp-ch-controls { width: 100%; }
  .bsp-select { flex: 1; }
  .bsp-nav-btn { padding: 8px 10px 6px; font-size: 9px; }
  .bsp-outline-chapter { padding: 6px 0; }
}
@media (min-width: 481px) and (max-width: 768px) {
  .bsp-section { padding: 16px 16px 32px; }
  .bsp-stats-grid { grid-template-columns: repeat(4, 1fr); gap: 8px; }
}
      `})]})}const Me={act_1:"#C9A84C",act_2:"#B85C38",act_3:"#7B5EA7",act_4:"#4A7C59",act_5:"#C9A84C"};function Ma({chapter:h,onActChange:p,onThreadChange:b}){const r=h?.pnos_act||Ba(h?.chapter_notes)||"act_1",_=h?.active_threads||[],[T,$]=a.useState(r),[l,j]=a.useState(_),[C,W]=a.useState(!1),D=ys[T];function N(m){$(m),p?.(m)}function F(m){const y=l.includes(m)?l.filter(U=>U!==m):[...l,m];j(y),b?.(y)}return e.jsxs("div",{style:P.panel,children:[e.jsxs("div",{style:P.collapsedRow,onClick:()=>W(!C),children:[e.jsxs("div",{style:P.collapsedLeft,children:[e.jsx("div",{style:{...P.actPill,background:`${Me[T]}18`,color:Me[T],borderColor:`${Me[T]}40`},children:D.label}),e.jsxs("div",{style:P.beliefPreview,children:['"',D.belief,'"']})]}),e.jsxs("div",{style:{...P.threadDots,gap:5},children:[Object.values($t).map(m=>e.jsx("div",{style:{...P.threadDot,background:l.includes(m.id)?m.color:"rgba(30,25,20,0.1)"},title:m.label},m.id)),e.jsx("div",{style:P.expandCaret,children:C?"▲":"▼"})]})]}),C&&e.jsxs("div",{style:P.expandedBody,children:[e.jsxs("div",{style:P.section,children:[e.jsx("div",{style:P.sectionLabel,children:"PNOS ACT"}),e.jsx("div",{style:P.actRow,children:Object.values(ys).map(m=>e.jsxs("button",{style:{...P.actBtn,background:T===m.id?`${Me[m.id]}18`:"white",borderColor:T===m.id?Me[m.id]:"rgba(30,25,20,0.1)",color:T===m.id?Me[m.id]:"rgba(30,25,20,0.45)"},onClick:()=>N(m.id),children:[m.label.split(" — ")[0],e.jsx("br",{}),e.jsx("span",{style:{fontWeight:400,fontSize:8},children:m.label.split(" — ")[1]})]},m.id))})]}),e.jsxs("div",{style:P.beliefBlock,children:[e.jsxs("div",{style:{...P.beliefQuote,color:Me[T]},children:['"',D.belief,'"']}),e.jsxs("div",{style:P.beliefVoice,children:[e.jsx("span",{style:P.voiceLabel,children:"VOICE: "}),D.voice_note]}),e.jsxs("div",{style:P.beliefShift,children:[e.jsx("span",{style:P.voiceLabel,children:"SHIFT: "}),D.shifted_by]})]}),e.jsxs("div",{style:P.section,children:[e.jsx("div",{style:P.sectionLabel,children:"ACTIVE THREADS THIS CHAPTER"}),e.jsx("div",{style:P.threadRow,children:Object.values($t).map(m=>e.jsxs("button",{style:{...P.threadBtn,borderColor:l.includes(m.id)?m.color:"rgba(30,25,20,0.1)",background:l.includes(m.id)?`${m.color}12`:"white",color:l.includes(m.id)?m.color:"rgba(30,25,20,0.35)"},onClick:()=>F(m.id),children:[e.jsx("div",{style:{...P.threadBtnDot,background:m.color}}),m.label]},m.id))}),l.length>0&&e.jsx("div",{style:P.threadQuestions,children:l.map(m=>{const y=$t[m];return y?e.jsxs("div",{style:{...P.threadQuestion,borderLeftColor:y.color},children:[e.jsxs("span",{style:{color:y.color,fontFamily:"DM Mono, monospace",fontSize:7,letterSpacing:"0.1em"},children:[y.label.toUpperCase(),": "]}),y.question]},m):null})})]})]})]})}function Ba(h){if(!h)return null;const p=h.match(/^\[PNOS:(act_\d)\]/);return p?p[1]:null}const P={panel:{border:"1px solid rgba(201,168,76,0.15)",borderRadius:3,background:"rgba(255,253,248,0.6)",overflow:"hidden",marginBottom:16},collapsedRow:{display:"flex",justifyContent:"space-between",alignItems:"center",padding:"8px 14px",cursor:"pointer"},collapsedLeft:{display:"flex",alignItems:"center",gap:10},actPill:{border:"1px solid",borderRadius:20,fontFamily:"DM Mono, monospace",fontSize:7.5,letterSpacing:"0.1em",padding:"3px 9px",flexShrink:0},beliefPreview:{fontFamily:"'Lora', 'Playfair Display', serif",fontSize:12,fontStyle:"italic",color:"rgba(30,25,20,0.55)",lineHeight:1.4},threadDots:{display:"flex",alignItems:"center"},threadDot:{width:7,height:7,borderRadius:"50%",transition:"background 0.15s"},expandCaret:{fontFamily:"DM Mono, monospace",fontSize:7,color:"rgba(30,25,20,0.2)",marginLeft:6},expandedBody:{borderTop:"1px solid rgba(201,168,76,0.1)",padding:"12px 14px",display:"flex",flexDirection:"column",gap:14,background:"rgba(255,253,248,0.4)"},section:{display:"flex",flexDirection:"column",gap:8},sectionLabel:{fontFamily:"DM Mono, monospace",fontSize:7.5,letterSpacing:"0.16em",color:"rgba(30,25,20,0.3)"},actRow:{display:"flex",gap:6,flexWrap:"wrap"},actBtn:{border:"1px solid",borderRadius:2,fontFamily:"DM Mono, monospace",fontSize:8.5,fontWeight:600,letterSpacing:"0.08em",padding:"6px 10px",cursor:"pointer",lineHeight:1.4,textAlign:"center",transition:"all 0.12s"},beliefBlock:{background:"rgba(201,168,76,0.04)",border:"1px solid rgba(201,168,76,0.12)",borderRadius:2,padding:"10px 12px",display:"flex",flexDirection:"column",gap:7},beliefQuote:{fontFamily:"'Lora', 'Playfair Display', serif",fontSize:14,fontStyle:"italic",lineHeight:1.5},beliefVoice:{fontFamily:"DM Mono, monospace",fontSize:8,color:"rgba(30,25,20,0.5)",letterSpacing:"0.03em",lineHeight:1.6},beliefShift:{fontFamily:"DM Mono, monospace",fontSize:8,color:"rgba(30,25,20,0.4)",letterSpacing:"0.03em",lineHeight:1.5},voiceLabel:{color:"rgba(30,25,20,0.25)",letterSpacing:"0.12em",fontSize:7},threadRow:{display:"flex",gap:6,flexWrap:"wrap"},threadBtn:{border:"1px solid",borderRadius:2,fontFamily:"DM Mono, monospace",fontSize:8,letterSpacing:"0.08em",padding:"5px 10px 5px 8px",cursor:"pointer",display:"flex",alignItems:"center",gap:6,transition:"all 0.12s"},threadBtnDot:{width:6,height:6,borderRadius:"50%",flexShrink:0},threadQuestions:{display:"flex",flexDirection:"column",gap:6},threadQuestion:{borderLeft:"2px solid",paddingLeft:8,fontFamily:"'Lora', 'Playfair Display', serif",fontSize:12,fontStyle:"italic",color:"rgba(30,25,20,0.6)",lineHeight:1.55}},Ss=Object.values(fa);function La({chapterCharacters:h=[],onCharacterToggle:p}){const[b,r]=a.useState(!1),[_,T]=a.useState(null),$=Ss.filter(l=>h.includes(l.name.toLowerCase().replace(/\s+/g,"_")));return e.jsxs("div",{style:M.panel,children:[e.jsxs("div",{style:M.header,onClick:()=>r(!b),children:[e.jsxs("div",{style:M.headerLeft,children:[e.jsx("div",{style:M.eyebrow,children:"CHARACTERS IN THIS CHAPTER"}),e.jsx("div",{style:M.summary,children:$.length===0?"None selected — mark who's present":$.map(l=>l.name).join(" · ")})]}),e.jsx("div",{style:M.caret,children:b?"▲":"▼"})]}),b&&e.jsxs("div",{style:M.body,children:[e.jsx("div",{style:M.grid,children:Ss.map(l=>{const j=l.name.toLowerCase().replace(/\s+/g,"_"),C=h.includes(j);return e.jsxs("button",{style:{...M.charChip,borderColor:C?l.color:"rgba(30,25,20,0.1)",color:C?l.color:"rgba(30,25,20,0.35)",background:C?`${l.color}0e`:"white"},onClick:()=>p?.(j),children:[e.jsx("div",{style:{...M.chipDot,background:l.color,opacity:C?1:.3}}),e.jsxs("div",{style:M.chipInfo,children:[e.jsx("div",{style:M.chipName,children:l.name}),e.jsx("div",{style:M.chipMode,children:l.appearance_mode.split(" — ")[0]})]})]},j)})}),$.length>0&&e.jsx("div",{style:M.rules,children:$.map(l=>{const j=l.name.toLowerCase().replace(/\s+/g,"_"),C=_===j,W=l.what_he_cannot_do||l.what_she_cannot_do||l.what_they_cannot_do||[];return e.jsxs("div",{style:{...M.charRule,borderLeftColor:l.color},children:[e.jsxs("div",{style:M.charRuleHeader,onClick:()=>T(C?null:j),children:[e.jsx("div",{style:M.charRuleName,children:l.name}),e.jsx("div",{style:{...M.modeBadge,color:l.color},children:l.appearance_mode}),e.jsx("div",{style:M.rulesCaret,children:C?"▲":"▼"})]}),e.jsx("div",{style:M.criticalRule,children:l.rules[0]}),C&&e.jsxs("div",{style:M.ruleDetail,children:[l.rules.slice(1).map((D,N)=>e.jsxs("div",{style:M.ruleItem,children:["· ",D]},N)),W.length>0&&e.jsxs("div",{style:M.violations,children:[e.jsx("div",{style:M.violationsLabel,children:"CANNOT:"}),W.map((D,N)=>e.jsxs("div",{style:M.violationItem,children:["✕ ",D]},N))]}),(l.how_he_enters||l.how_she_enters)&&e.jsxs("div",{style:M.entryNote,children:[e.jsx("span",{style:M.entryLabel,children:"HOW THEY ENTER: "}),l.how_he_enters||l.how_she_enters]}),l.absence_tracking&&e.jsxs("div",{style:M.absenceNote,children:[e.jsx("span",{style:M.absenceLabel,children:"ABSENCE: "}),l.absence_tracking]})]})]},j)})})]})]})}const M={panel:{border:"1px solid rgba(219,112,147,0.18)",borderRadius:6,overflow:"hidden",marginBottom:10,background:"#FFF0F3"},header:{display:"flex",justifyContent:"space-between",alignItems:"flex-start",padding:"12px 14px",cursor:"pointer",gap:10},headerLeft:{display:"flex",flexDirection:"column",gap:3,flex:1},eyebrow:{fontFamily:"DM Mono, monospace",fontSize:9,letterSpacing:"0.2em",color:"rgba(180,80,120,0.55)"},summary:{fontFamily:"'Lora', 'Playfair Display', serif",fontSize:13,fontStyle:"italic",color:"rgba(100,40,60,0.65)"},caret:{fontFamily:"DM Mono, monospace",fontSize:8,color:"rgba(180,80,120,0.3)"},body:{borderTop:"1px solid rgba(219,112,147,0.12)",padding:"12px 14px",display:"flex",flexDirection:"column",gap:12},grid:{display:"flex",flexWrap:"wrap",gap:6},charChip:{display:"flex",alignItems:"center",gap:7,border:"1px solid",borderRadius:2,padding:"6px 10px",cursor:"pointer",transition:"all 0.12s",textAlign:"left"},chipDot:{width:7,height:7,borderRadius:"50%",flexShrink:0,transition:"opacity 0.15s"},chipInfo:{display:"flex",flexDirection:"column",gap:1},chipName:{fontFamily:"DM Mono, monospace",fontSize:9.5,fontWeight:600,letterSpacing:"0.06em"},chipMode:{fontFamily:"DM Mono, monospace",fontSize:8,letterSpacing:"0.04em",opacity:.6},rules:{display:"flex",flexDirection:"column",gap:8},charRule:{borderLeft:"2px solid",paddingLeft:10,display:"flex",flexDirection:"column",gap:5},charRuleHeader:{display:"flex",alignItems:"center",gap:8,cursor:"pointer"},charRuleName:{fontFamily:"DM Mono, monospace",fontSize:10,fontWeight:600,letterSpacing:"0.08em",color:"rgba(100,40,60,0.7)"},modeBadge:{fontFamily:"DM Mono, monospace",fontSize:8,letterSpacing:"0.06em",flex:1},rulesCaret:{fontFamily:"DM Mono, monospace",fontSize:8,color:"rgba(180,80,120,0.3)"},criticalRule:{fontFamily:"'Lora', 'Playfair Display', serif",fontSize:12.5,fontStyle:"italic",color:"rgba(100,40,60,0.65)",lineHeight:1.55},ruleDetail:{display:"flex",flexDirection:"column",gap:5},ruleItem:{fontFamily:"DM Mono, monospace",fontSize:9,color:"rgba(100,40,60,0.5)",letterSpacing:"0.03em",lineHeight:1.55},violations:{display:"flex",flexDirection:"column",gap:3,marginTop:4,background:"rgba(184,92,56,0.06)",border:"1px solid rgba(184,92,56,0.15)",borderRadius:3,padding:"7px 9px"},violationsLabel:{fontFamily:"DM Mono, monospace",fontSize:8,letterSpacing:"0.15em",color:"#B85C38",marginBottom:2},violationItem:{fontFamily:"DM Mono, monospace",fontSize:9,color:"rgba(184,92,56,0.7)",letterSpacing:"0.03em",lineHeight:1.5},entryNote:{fontFamily:"DM Mono, monospace",fontSize:9,color:"rgba(100,40,60,0.55)",letterSpacing:"0.03em",lineHeight:1.6,marginTop:3},entryLabel:{color:"rgba(180,80,120,0.35)",letterSpacing:"0.12em",fontSize:8},absenceNote:{fontFamily:"DM Mono, monospace",fontSize:8,color:"rgba(139,105,20,0.7)",letterSpacing:"0.03em",lineHeight:1.6,background:"rgba(201,168,76,0.06)",border:"1px solid rgba(201,168,76,0.15)",borderRadius:2,padding:"6px 9px",marginTop:3},absenceLabel:{color:"#8B6914",letterSpacing:"0.12em",fontSize:7}},L="/api/v1",ks=[{type:"h2",label:"Chapter Title",icon:"H2"},{type:"h3",label:"Section",icon:"H3"},{type:"h4",label:"Subsection",icon:"H4"},{type:"body",label:"Body",icon:"¶"},{type:"quote",label:"Quote",icon:"“"},{type:"reflection",label:"Reflection",icon:"?"},{type:"divider",label:"Divider",icon:"─"}],Pa=["h1","h2","h3","h4"];function Ht(){return crypto.randomUUID?crypto.randomUUID():`${Date.now()}-${Math.random().toString(36).slice(2,9)}`}const $a=[{id:"write",label:"Write"},{id:"review",label:"Review"},{id:"structure",label:"Structure"},{id:"scenes",label:"Scenes"},{id:"memory",label:"Memory"},{id:"lala",label:"Lala"},{id:"export",label:"Export"}];function Ka(){const{bookId:h,chapterId:p}=ua(),b=xa(),[r,_]=a.useState(null),[T,$]=a.useState(null),[l,j]=a.useState([]),[C,W]=a.useState(!0),[D,N]=a.useState(()=>{const t=localStorage.getItem("wm-show-toc");return t!==null?t==="true":!0}),[F,m]=a.useState(()=>{const t=localStorage.getItem("wm-show-context");return t!==null?t==="true":!0}),[y,U]=a.useState(null),[Y,me]=a.useState(null),[q,v]=a.useState(null),[V,ge]=a.useState(""),[ne,Z]=a.useState(!1),[he,c]=a.useState(""),[d,I]=a.useState(null),[J,Q]=a.useState([]),[ie,A]=a.useState(null),[be,ye]=a.useState(""),[i,S]=a.useState(null),[f,B]=a.useState(!1),k=a.useRef(null),[ee,Se]=a.useState({}),mt=a.useRef({}),[Te,te]=a.useState(null),[K,re]=a.useState(""),[He,Wt]=a.useState(null),[Ze,Gt]=a.useState("plan"),[x,oe]=a.useState(""),[ue,le]=a.useState(0),[ht,xe]=a.useState(!0),[ut,et]=a.useState(!1),[ke,tt]=a.useState(!1),[Ut,xt]=a.useState(""),[E,ce]=a.useState(!1),[Jt,ft]=a.useState(null),[we,Cs]=a.useState(!1),[Be,gt]=a.useState(""),[_s,bt]=a.useState(!1),[Fa,Kt]=a.useState(""),[Ce,Le]=a.useState(null),[qt,We]=a.useState(null),[Ge,yt]=a.useState(null),[Ae,Ts]=a.useState("paragraph"),[Ue,Pe]=a.useState(""),[As,Ds]=a.useState([]),[se,Vt]=a.useState(null),[za,Yt]=a.useState(!1),[Es,wt]=a.useState(!1),[Qt,$e]=a.useState(null),[Xt,Ms]=a.useState([]),[Fe,Bs]=a.useState(!1),vt=a.useRef({toc:!0,ctx:!0}),[Zt]=a.useState(()=>Date.now()),[st,Ls]=a.useState(0),[ze,Ps]=a.useState(()=>{const t=localStorage.getItem("wm-word-goal");return t?parseInt(t,10):0}),[jt,Nt]=a.useState(!1),at=a.useRef(0),[X,ve]=a.useState(null),[es,De]=a.useState(null),[Re,$s]=a.useState([]),[nt,it]=a.useState(!1),[ts,St]=a.useState(!1),[fe,ot]=a.useState("write"),[Ie,kt]=a.useState([]),[Ct,_t]=a.useState(null),[Je,Tt]=a.useState(""),[Fs,zs]=a.useState(null),[Rs,ss]=a.useState(!1),[At,Is]=a.useState([]),[Os,Hs]=a.useState([]),[Ra,Ws]=a.useState({exit_emotion:"",exit_emotion_note:""}),[Ia,Gs]=a.useState("act_1"),[Oa,Us]=a.useState([]),[Js,as]=a.useState([]),[Ks,ns]=a.useState(!1),is=x.split(/\n\n+/).filter(t=>t.trim().length>20).length,qs=is>=5&&fe==="write",os=a.useRef(null),rs=a.useRef(null),Ee=a.useRef(null),Dt=a.useRef(null),rt=a.useRef(null),Ke=a.useRef(""),qe=a.useRef(""),ls=a.useCallback(async()=>{try{const s=await(await fetch(`${L}/storyteller/books/${h}`)).json(),n=s?.book||s;$(n);const o=(n.chapters||[]).sort((u,g)=>(u.sort_order??u.chapter_number??0)-(g.sort_order??g.chapter_number??0));return j(o),o}catch{return null}},[h]);a.useEffect(()=>{async function t(){try{const n=await(await fetch(`${L}/storyteller/books/${h}`)).json(),o=n?.book||n;$(o);const u=(o.chapters||[]).sort((z,w)=>(z.sort_order??z.chapter_number??0)-(w.sort_order??w.chapter_number??0));j(u);const g=u.find(z=>z.id===p);if(_(g||{id:p,title:"Chapter"}),g?.draft_prose&&(oe(g.draft_prose),le(g.draft_prose.split(/\s+/).filter(Boolean).length)),g?.sections?.length>0){const z={};g.sections.forEach(R=>{R.id&&(z[R.id]=R.prose||"")}),Se(z),mt.current=z;const w=g.sections.filter(R=>["h2","h3","h4"].includes(R.type)&&R.prose?.trim()).map(R=>R.prose).join(`

`);w.trim()&&(oe(w),le(w.split(/\s+/).filter(Boolean).length))}const G=u.findIndex(z=>z.id===p);if(G>0){const z=u[G-1],w=z.draft_prose?.trim();if(w){const R=w.split(/\n\n+/).filter(Boolean),_e=R[R.length-1];Wt({title:z.title,excerpt:_e.length>200?_e.slice(0,200)+"…":_e,wordCount:w.split(/\s+/).filter(Boolean).length})}else Wt({title:z.title,excerpt:null,wordCount:0})}}catch{_({id:p,title:"Chapter"})}finally{W(!1)}}t()},[h,p]),a.useEffect(()=>{async function t(){Yt(!0);try{const n=await(await fetch(`${L}/character-registry/registries`)).json(),o=n.registries||n||[],u=[];for(const g of o){const z=await(await fetch(`${L}/character-registry/registries/${g.id}`)).json();(z.characters||z.registry?.characters||[]).forEach(R=>u.push({...R,_registryTitle:g.title||g.book_tag}))}Ds(u.filter(g=>g.status!=="declined"))}catch(s){console.error("Failed to load characters:",s)}Yt(!1)}t()},[]),a.useEffect(()=>{const t=setInterval(()=>{Ls(Math.floor((Date.now()-Zt)/1e3))},1e3);return()=>clearInterval(t)},[Zt]),a.useEffect(()=>{at.current===0&&ue>0&&(at.current=ue)},[ue]),a.useEffect(()=>{fetch(`${L}/character-registry/registries`).then(t=>t.json()).then(t=>{const s=t?.registries||t||[],n=Array.isArray(s)?s.flatMap(o=>o.characters||[]):[];Is(n)}).catch(()=>{})},[]),a.useEffect(()=>{fe!=="review"||!p||lt()},[fe,p]),a.useEffect(()=>{!p||!h||fetch(`${L}/storyteller/echoes?book_id=${h}&target_chapter_id=${p}`).then(t=>t.json()).then(t=>as(Array.isArray(t)?t:[])).catch(()=>{})},[p,h]),a.useEffect(()=>{const t=document.createElement("style");return t.textContent=ga,document.head.appendChild(t),()=>document.head.removeChild(t)},[]);const de=a.useCallback(t=>{x.trim()&&$s(s=>[...s.slice(-19),{prose:x,label:t,timestamp:Date.now(),wordCount:ue}])},[x,ue]),Et=a.useCallback(async t=>{if(X===null||E)return;const s=x.split(/\n\n+/),n=s[X];if(n){if(t==="delete"){de("Before delete paragraph");const u=s.filter((g,G)=>G!==X).join(`

`);oe(u),le(u.split(/\s+/).filter(Boolean).length),xe(!1),ve(null),De(null);return}de(`Before ${t} paragraph`),ce(!0),De(t);try{const u=await(await fetch(`${L}/memories/story-edit`,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({current_prose:n,edit_note:t==="rewrite"?"Rewrite this paragraph with better prose, keeping the same meaning and tone.":"Expand this paragraph with more sensory detail, interiority, and emotional depth. Keep the same voice.",pnos_act:r?.pnos_act||"act_1",chapter_title:r?.title,character_id:se?.id||null})})).json();if(u.prose){const g=[...s];g[X]=u.prose.trim();const G=g.join(`

`);oe(G),le(G.split(/\s+/).filter(Boolean).length),xe(!1)}}catch(o){console.error("paragraph action error:",o)}ce(!1),ve(null),De(null)}},[x,X,E,r,se,de]);a.useEffect(()=>{if(rt.current&&clearTimeout(rt.current),!(!x||ht))return rt.current=setTimeout(()=>Oe(x),8e3),()=>clearTimeout(rt.current)},[x,ht]);const Oe=a.useCallback(async t=>{if(t){et(!0);try{await fetch(`${L}/storyteller/chapters/${p}/save-draft`,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({draft_prose:t})});const s=mt.current;Object.keys(s).length>0&&_(n=>{if(n?.sections?.length>0){const o=n.sections.map(u=>({...u,prose:s[u.id]??u.prose??""}));return fetch(`${L}/storyteller/chapters/${p}`,{method:"PUT",headers:{"Content-Type":"application/json"},body:JSON.stringify({sections:o})}).catch(()=>{}),{...n,sections:o}}return n}),xe(!0)}catch{}et(!1)}},[p]),cs=a.useCallback(()=>{if(!("webkitSpeechRecognition"in window)&&!("SpeechRecognition"in window)){ft("Voice not supported on this browser. Try Chrome.");return}const t=window.SpeechRecognition||window.webkitSpeechRecognition,s=new t;s.continuous=!0,s.interimResults=!0,s.lang="en-US",Ke.current="",s.onresult=n=>{let o="",u=Ke.current;for(let g=n.resultIndex;g<n.results.length;g++)n.results[g].isFinal?u+=n.results[g][0].transcript+" ":o=n.results[g][0].transcript;Ke.current=u,xt(u+o)},s.onerror=n=>{n.error!=="no-speech"&&ft("Mic error — tap to retry"),tt(!1)},s.onend=()=>tt(!1),os.current=s,s.start(),tt(!0),ft(null),xt(""),Ke.current=""},[]),ds=a.useCallback(async t=>{de("Before voice-to-story"),ce(!0),Pe("");try{const n=(await fetch(`${L}/memories/voice-to-story`,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({spoken:t,existing_prose:x,chapter_title:r?.title,chapter_brief:r?.scene_goal||r?.chapter_notes,pnos_act:r?.pnos_act||"act_1",book_character:T?.character||"JustAWoman",session_log:Xt.slice(-4),character_id:se?.id||null,gen_length:Ae,stream:!0})})).body.getReader(),o=new TextDecoder;let u="",g=null;for(;;){const{done:G,value:z}=await n.read();if(G)break;const R=o.decode(z,{stream:!0}).split(`
`);for(const _e of R)if(_e.startsWith("data: "))try{const Ne=JSON.parse(_e.slice(6));Ne.type==="text"?(u+=Ne.text,Pe(u),Ee.current&&(Ee.current.scrollTop=Ee.current.scrollHeight)):Ne.type==="done"?g=Ne.hint||null:Ne.type==="error"&&console.error("voice-to-story stream error:",Ne.error)}catch{}}if(u){const G=x?x.trimEnd()+`

`+u:u;oe(G),le(G.split(/\s+/).filter(Boolean).length),xe(!1),Ms(z=>[...z,{spoken:t,generated:u}]),g&&($e(g),setTimeout(()=>$e(null),6e3))}}catch(s){console.error("voice-to-story error:",s)}Pe(""),ce(!1)},[x,r,T,Xt,Ae,se,de]),Vs=a.useCallback(async()=>{if(ke){os.current?.stop(),tt(!1);const t=Ke.current.trim();if(!t)return;xt(""),await ds(t)}else cs()},[ke,cs,ds]),Ys=a.useCallback(()=>{const t=window.SpeechRecognition||window.webkitSpeechRecognition;if(!t)return;const s=new t;s.continuous=!0,s.interimResults=!0,s.lang="en-US",qe.current="",s.onresult=n=>{let o="",u=qe.current;for(let g=n.resultIndex;g<n.results.length;g++)n.results[g].isFinal?u+=n.results[g][0].transcript+" ":o=n.results[g][0].transcript;qe.current=u,Kt(u+o),gt(u+o)},s.onend=()=>bt(!1),rs.current=s,s.start(),bt(!0),qe.current=""},[]),Qs=a.useCallback(()=>{rs.current?.stop(),bt(!1)},[]),Xs=a.useCallback(async()=>{if(Be.trim()){de("Before edit"),ce(!0);try{const s=await(await fetch(`${L}/memories/story-edit`,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({current_prose:x,edit_note:Be.trim(),pnos_act:r?.pnos_act||"act_1",chapter_title:r?.title})})).json();s.prose&&(oe(s.prose),le(s.prose.split(/\s+/).filter(Boolean).length),xe(!1),gt(""),Kt(""),qe.current="")}catch(t){console.error("story-edit error:",t)}ce(!1)}},[x,Be,r,de]),Mt=a.useCallback(async()=>{if(!(!x.trim()||E)){de("Before continue"),Le("continue"),ce(!0),yt(x),We(null),Pe("");try{const s=(await fetch(`${L}/memories/story-continue`,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({current_prose:x,chapter_title:r?.title,chapter_brief:r?.scene_goal||r?.chapter_notes,pnos_act:r?.pnos_act||"act_1",book_character:T?.character||"JustAWoman",character_id:se?.id||null,gen_length:Ae,stream:!0})})).body.getReader(),n=new TextDecoder;let o="";for(;;){const{done:u,value:g}=await s.read();if(u)break;const z=n.decode(g,{stream:!0}).split(`
`);for(const w of z)if(w.startsWith("data: "))try{const R=JSON.parse(w.slice(6));R.type==="text"?(o+=R.text,Pe(o),Ee.current&&(Ee.current.scrollTop=Ee.current.scrollHeight)):R.type==="error"&&($e(R.error),setTimeout(()=>$e(null),5e3))}catch{}}if(o){const u=x.trimEnd()+`

`+o;oe(u),le(u.split(/\s+/).filter(Boolean).length),xe(!1)}}catch(t){console.error("story-continue error:",t)}Pe(""),ce(!1),Le(null)}},[x,r,T,E,Ae,se,de]),Bt=a.useCallback(async()=>{if(!(!x.trim()||E)){de("Before deepen"),Le("deepen"),ce(!0),yt(x),We(null);try{const s=await(await fetch(`${L}/memories/story-deepen`,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({current_prose:x,pnos_act:r?.pnos_act||"act_1",chapter_title:r?.title,character_id:se?.id||null})})).json();s.prose?(oe(s.prose),le(s.prose.split(/\s+/).filter(Boolean).length),xe(!1)):s.error&&($e(s.error),setTimeout(()=>$e(null),5e3))}catch(t){console.error("story-deepen error:",t)}ce(!1),Le(null)}},[x,r,E,de]),Zs=a.useCallback(async()=>{if(!E){Le("nudge"),ce(!0),We(null);try{const s=await(await fetch(`${L}/memories/story-nudge`,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({current_prose:x,chapter_title:r?.title,chapter_brief:r?.scene_goal||r?.chapter_notes,pnos_act:r?.pnos_act||"act_1",character_id:se?.id||null})})).json();s.nudge&&We(s.nudge)}catch(t){console.error("story-nudge error:",t)}ce(!1),Le(null)}},[x,r,E]),ea=a.useCallback(()=>{Ge!==null&&(oe(Ge),le(Ge.split(/\s+/).filter(Boolean).length),xe(!1),yt(null))},[Ge]),lt=a.useCallback(async()=>{ss(!0);try{const s=await(await fetch(`${L}/storyteller/books/${h}`)).json(),o=((s?.book||s).chapters||[]).find(u=>u.id===p);kt(o?.lines||[])}catch{}ss(!1)},[h,p]),ps=(t,s)=>{kt(n=>n.map(o=>o.id===t?{...o,...s}:o))},ms=async t=>{try{await fetch(`${L}/storyteller/lines/${t}`,{method:"PUT",headers:{"Content-Type":"application/json"},body:JSON.stringify({status:"approved"})}),ps(t,{status:"approved"});const s=Ie.find(n=>n.id===t);s&&zs({...s,status:"approved"})}catch{}},ta=async t=>{try{await fetch(`${L}/storyteller/lines/${t}`,{method:"DELETE"}),kt(s=>s.filter(n=>n.id!==t))}catch{}},sa=t=>{_t(t.id),Tt(t.text||t.content||"")},aa=async()=>{try{await fetch(`${L}/storyteller/lines/${Ct}`,{method:"PUT",headers:{"Content-Type":"application/json"},body:JSON.stringify({text:Je,content:Je,status:"edited"})}),ps(Ct,{text:Je,content:Je,status:"edited"}),_t(null),Tt("")}catch{}},na=async()=>{const t=Ie.filter(s=>s.status==="pending");for(const s of t)await ms(s.id)},ia=a.useCallback(async()=>{et(!0);try{await fetch(`${L}/storyteller/chapters/${p}/save-draft`,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({draft_prose:x})});const s=x.split(/\n\n+/).map(n=>n.trim()).filter(Boolean).map((n,o)=>`LINE ${o+1}
${n}`).join(`

`);await fetch(`${L}/storyteller/chapters/${p}/import`,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({raw_text:s,mode:"replace"})}),se?.id&&x&&fetch(`${L}/storyteller/chapters/${p}/emotional-impact`,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({prose:x,character_id:se.id})}).catch(()=>{}),ot("review"),await lt()}catch(t){console.error("sendToReview error:",t)}et(!1)},[x,p,h,se,lt]),oa=t=>{const s=t.target.value;oe(s),le(s.split(/\s+/).filter(Boolean).length),xe(!1),ct(t.target)},ct=a.useCallback(t=>{!t||window.innerWidth>767||(t.style.height="auto",t.style.height=t.scrollHeight+"px")},[]);a.useEffect(()=>{Dt.current&&window.innerWidth<=767&&ct(Dt.current)},[x,Ue,ct]);const ra=r?.sections?.length>0&&r.sections.some(t=>["h2","h3","h4"].includes(t.type)),la=a.useCallback((t,s)=>{Se(n=>{const o={...n,[t]:s};mt.current=o;const u=(r?.sections||[]).filter(g=>["h2","h3","h4"].includes(g.type)).map(g=>o[g.id]||"").filter(Boolean).join(`

`);return oe(u),le(u.split(/\s+/).filter(Boolean).length),xe(!1),o})},[r?.sections]),Ve=a.useCallback(()=>{Bs(t=>(t?(N(vt.current.toc),m(vt.current.ctx)):(vt.current={toc:D,ctx:F},N(!1),m(!1)),!t))},[D,F]);a.useEffect(()=>{const t=s=>{if((s.ctrlKey||s.metaKey)&&s.key==="Enter"&&(s.preventDefault(),!we&&x.trim()&&!E&&Mt()),(s.ctrlKey||s.metaKey)&&s.key==="d"&&(s.preventDefault(),!we&&x.trim()&&!E&&Bt()),(s.ctrlKey||s.metaKey)&&s.key==="s"&&(s.preventDefault(),x&&Oe(x)),s.key==="Escape"){if(we){Cs(!1);return}if(nt){it(!1);return}if(jt){Nt(!1);return}if(Fe){Ve();return}if(X!==null){ve(null),De(null);return}if(q){v(null);return}if(ne){Z(!1);return}if(Te){te(null);return}}s.key==="F11"&&(s.preventDefault(),Ve()),(s.ctrlKey||s.metaKey)&&s.key==="["&&(s.preventDefault(),dt(-1)),(s.ctrlKey||s.metaKey)&&s.key==="]"&&(s.preventDefault(),dt(1)),(s.ctrlKey||s.metaKey)&&s.key==="b"&&(s.preventDefault(),N(n=>!n))};return window.addEventListener("keydown",t),()=>window.removeEventListener("keydown",t)},[we,x,E,Fe,nt,jt,X,Mt,Bt,Oe,Ve]),a.useEffect(()=>{localStorage.setItem("wm_showToc",JSON.stringify(D))},[D]),a.useEffect(()=>{localStorage.setItem("wm_showContext",JSON.stringify(F))},[F]);const Lt=a.useCallback(async t=>{t!==p&&(x&&await Oe(x),b(`/chapter/${h}/${t}`))},[p,h,x,Oe,b]),dt=a.useCallback(t=>{const s=l.findIndex(o=>o.id===p);if(s<0)return;const n=l[s+t];n&&Lt(n.id)},[l,p,Lt]),ca=a.useCallback(async()=>{if(y===null||Y===null||y===Y){U(null),me(null);return}const t=[...l],[s]=t.splice(y,1);t.splice(Y,0,s),j(t),U(null),me(null);try{await Promise.all(t.map((n,o)=>fetch(`${L}/storyteller/chapters/${n.id}`,{method:"PUT",headers:{"Content-Type":"application/json"},body:JSON.stringify({sort_order:o+1})})))}catch(n){console.error("reorder error",n)}},[l,y,Y]),hs=a.useCallback(async()=>{if(!q||!V.trim()){v(null);return}j(t=>t.map(s=>s.id===q?{...s,title:V.trim()}:s)),q===p&&_(t=>({...t,title:V.trim()})),v(null);try{await fetch(`${L}/storyteller/chapters/${q}`,{method:"PUT",headers:{"Content-Type":"application/json"},body:JSON.stringify({title:V.trim()})})}catch(t){console.error("rename error",t)}},[q,V,p]),da=a.useCallback(t=>{if(d===t){I(null),Q([]);return}I(t);const s=l.find(o=>o.id===t),n=s?.sections&&Array.isArray(s.sections)?s.sections.map(o=>({...o,id:o.id||Ht()})):[];Q(n)},[d,l]),us=a.useCallback(async t=>{if(d)try{await fetch(`${L}/storyteller/chapters/${d}`,{method:"PUT",headers:{"Content-Type":"application/json"},body:JSON.stringify({sections:t})}),j(s=>s.map(n=>n.id===d?{...n,sections:t}:n)),d===p&&_(s=>({...s,sections:t}))}catch(s){console.error("save sections error",s)}},[d,p]);a.useEffect(()=>{if(!(!d||J.length===0))return clearTimeout(k.current),k.current=setTimeout(()=>us(J),1500),()=>clearTimeout(k.current)},[J,d,us]);const pa=a.useCallback((t="body")=>{const s={id:Ht(),type:t,content:""};Q(n=>[...n,s]),B(!1),setTimeout(()=>{A(s.id),ye("")},50)},[]),xs=a.useCallback(()=>{ie&&(Q(t=>t.map(s=>s.id===ie?{...s,content:be}:s)),A(null))},[ie,be]),ma=a.useCallback(t=>{Q(s=>s.filter(n=>n.id!==t))},[]),fs=a.useCallback((t,s)=>{Q(n=>{const o=n.findIndex(G=>G.id===t);if(o<0)return n;const u=o+s;if(u<0||u>=n.length)return n;const g=[...n];return[g[o],g[u]]=[g[u],g[o]],g})},[]);a.useCallback((t,s)=>{Q(n=>n.map(o=>o.id===t?{...o,type:s}:o))},[]);const gs=a.useCallback(async()=>{const t=he.trim()||`Chapter ${l.length+1}`;Z(!1),c("");try{const n=await(await fetch(`${L}/storyteller/books/${h}/chapters`,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({title:t,chapter_number:l.length+1,sort_order:l.length+1})})).json(),o=n.chapter||n;j(u=>[...u,o])}catch(s){console.error("add chapter error",s)}},[h,l.length,he]),pe=a.useCallback(async(t,s)=>{_(n=>({...n,[t]:s})),j(n=>n.map(o=>o.id===p?{...o,[t]:s}:o)),te(null);try{await fetch(`${L}/storyteller/chapters/${p}`,{method:"PUT",headers:{"Content-Type":"application/json"},body:JSON.stringify({[t]:s})})}catch(n){console.error("save context field error",n)}},[p]),Pt=a.useMemo(()=>{const t=l.length,s=l.filter(o=>o.draft_prose?.trim()).length,n=l.reduce((o,u)=>o+(u.draft_prose?u.draft_prose.split(/\s+/).filter(Boolean).length:0),0);return{total:t,written:s,totalWords:n}},[l]);if(C)return e.jsx("div",{className:"wm-load-screen",children:e.jsx(ha,{variant:"editor"})});const Ye=Ie.filter(t=>t.status==="approved"||t.status==="edited"),je=Ie.filter(t=>t.status==="pending");function bs(t,s){const n=Ct===t.id,o=t.text||t.content||"";return e.jsxs("div",{className:`wm-review-line wm-review-line--${t.status}${n?" editing":""}`,children:[e.jsx("div",{className:"wm-review-line-content",children:n?e.jsxs(e.Fragment,{children:[e.jsx("textarea",{className:"wm-review-line-edit",value:Je,onChange:u=>Tt(u.target.value),autoFocus:!0}),e.jsxs("div",{className:"wm-review-line-edit-actions",children:[e.jsx("button",{className:"wm-review-save",onClick:aa,children:"Save"}),e.jsx("button",{className:"wm-review-cancel",onClick:()=>_t(null),children:"Cancel"})]})]}):e.jsx("p",{className:`wm-review-line-text${s?" pending":""}`,children:o})}),!n&&e.jsxs("div",{className:"wm-review-line-actions",children:[s&&e.jsx("button",{className:"wm-line-approve",onClick:()=>ms(t.id),title:"Approve",children:"✓"}),e.jsx("button",{className:"wm-line-edit",onClick:()=>sa(t),title:"Edit",children:"✎"}),s&&e.jsx("button",{className:"wm-line-reject",onClick:()=>ta(t.id),title:"Reject",children:"✕"})]})]},t.id)}return e.jsxs("div",{className:`wm-root${Fe?" wm-focus-mode":""}`,children:[Fe&&e.jsx("button",{className:"wm-focus-exit",onClick:Ve,title:"Exit focus mode (F11)",children:"✕"}),e.jsxs("header",{className:"wm-topbar",children:[e.jsx("button",{className:"wm-back-btn",onClick:()=>wt(!0),children:"←"}),e.jsx("button",{className:`wm-sidebar-toggle${D?" active":""}`,onClick:()=>N(t=>!t),title:"Table of Contents (Ctrl+B)",children:"☰"}),e.jsxs("div",{className:"wm-chapter-info",children:[e.jsx("div",{className:"wm-chapter-title",children:r?.title||"Untitled"}),e.jsx("div",{className:"wm-book-title",children:T?.title||T?.character||""})]}),e.jsxs("div",{className:"wm-session-timer",children:[e.jsx("span",{className:"wm-timer-icon",children:"⏱"}),e.jsxs("span",{className:"wm-timer-value",children:[Math.floor(st/3600)>0&&`${Math.floor(st/3600)}:`,String(Math.floor(st%3600/60)).padStart(2,"0"),":",String(st%60).padStart(2,"0")]})]}),e.jsxs("div",{className:"wm-top-right",children:[e.jsxs("div",{className:"wm-quick-char-wrap",children:[e.jsxs("button",{className:"wm-quick-char-btn",onClick:()=>St(t=>!t),title:"Quick switch character",children:[e.jsx("span",{children:se?.icon||"👤"}),e.jsx("span",{className:"wm-quick-char-caret",children:ts?"▲":"▼"})]}),ts&&e.jsxs("div",{className:"wm-quick-char-dropdown",children:[e.jsxs("div",{className:`wm-quick-char-option${se?"":" selected"}`,onClick:()=>{Vt(null),St(!1)},children:[e.jsx("span",{className:"wm-quick-char-option-icon",children:"—"}),e.jsx("span",{children:"No character voice"})]}),As.map(t=>e.jsxs("div",{className:`wm-quick-char-option${se?.id===t.id?" selected":""}`,onClick:()=>{Vt(t),St(!1)},children:[e.jsx("span",{className:"wm-quick-char-option-icon",children:t.icon||"👤"}),e.jsx("span",{children:t.display_name||t.selected_name})]},t.id))]})]}),ue>0&&e.jsxs("div",{className:"wm-word-count",onClick:()=>Nt(t=>!t),title:"Click to set word goal",children:[ue,"w",ze>0&&e.jsxs("span",{className:"wm-goal-fraction",children:[" / ",ze]})]}),e.jsx("div",{className:"wm-save-status",children:ut?"·· saving":ht?"":"· unsaved"}),e.jsxs("button",{className:`wm-history-btn${nt?" active":""}`,onClick:()=>it(t=>!t),title:`Snapshots (${Re.length})`,children:["📜",Re.length>0&&e.jsx("span",{className:"wm-history-badge",children:Re.length})]}),e.jsx("button",{className:`wm-focus-btn${Fe?" active":""}`,onClick:Ve,title:"Focus mode (F11)",children:"⛶"}),e.jsx("button",{className:`wm-sidebar-toggle wm-ctx-toggle${F?" active":""}`,onClick:()=>m(t=>!t),title:"Chapter context panel",children:"ℹ"})]})]}),ze>0&&e.jsxs("div",{className:"wm-goal-bar-wrap",children:[e.jsx("div",{className:"wm-goal-bar",children:e.jsx("div",{className:"wm-goal-fill",style:{width:`${Math.min(100,(ue-at.current)/ze*100)}%`}})}),e.jsxs("span",{className:"wm-goal-label",children:[Math.max(0,ue-at.current)," / ",ze," words this session"]})]}),jt&&e.jsxs("div",{className:"wm-goal-input-wrap",children:[e.jsx("label",{className:"wm-goal-input-label",children:"Session word goal:"}),e.jsx("input",{className:"wm-goal-input",type:"number",min:0,step:50,value:ze,onChange:t=>{const s=parseInt(t.target.value)||0;Ps(s),localStorage.setItem("wm_word_goal",s)},placeholder:"e.g. 500"}),e.jsx("button",{className:"wm-goal-input-close",onClick:()=>Nt(!1),children:"✓"})]}),e.jsxs("div",{className:"wm-hub-layout",children:[D&&e.jsxs("aside",{className:"wm-toc-sidebar",children:[e.jsxs("div",{className:"wm-toc-header",children:[e.jsx("span",{className:"wm-toc-header-title",children:"Contents"}),e.jsxs("span",{className:"wm-toc-stats",children:[Pt.written,"/",Pt.total," · ",Pt.totalWords.toLocaleString(),"w"]})]}),e.jsx("div",{className:"wm-toc-list",children:l.map((t,s)=>{const n=t.id===p,o=t.draft_prose?t.draft_prose.split(/\s+/).filter(Boolean).length:0,u=d===t.id;t.sections&&Array.isArray(t.sections)&&t.sections.length>0;const g=t.chapter_type||"chapter",G=g==="prologue"?"◈":g==="epilogue"?"◇":g==="interlude"?"~":g==="afterword"?"∗":null,z=t.part_number&&(s===0||t.part_number!==l[s-1]?.part_number);return e.jsxs("div",{className:"wm-toc-chapter-group",children:[z&&e.jsx("div",{className:"wm-toc-part-divider",children:e.jsxs("span",{className:"wm-toc-part-label",children:["Part ",t.part_number,t.part_title?` — ${t.part_title}`:""]})}),e.jsxs("div",{className:`wm-toc-item${n?" current":""}${Y===s?" drag-over":""}`,draggable:!0,onDragStart:()=>U(s),onDragOver:w=>{w.preventDefault(),me(s)},onDragEnd:ca,onClick:()=>!q&&Lt(t.id),children:[e.jsx("span",{className:"wm-toc-drag",children:"≡"}),e.jsx("button",{className:`wm-toc-expand${u?" expanded":""}`,onClick:w=>{w.stopPropagation(),da(t.id)},title:u?"Collapse sections":"Show sections",children:"▸"}),e.jsx("span",{className:"wm-toc-num",children:t.chapter_number||s+1}),G&&e.jsx("span",{className:"wm-toc-type-badge",title:g,children:G}),q===t.id?e.jsx("input",{className:"wm-toc-edit-input",value:V,onChange:w=>ge(w.target.value),onBlur:hs,onKeyDown:w=>{w.key==="Enter"&&hs(),w.key==="Escape"&&v(null)},autoFocus:!0,onClick:w=>w.stopPropagation()}):e.jsx("span",{className:"wm-toc-title",onDoubleClick:w=>{w.stopPropagation(),v(t.id),ge(t.title||"")},children:t.title||"Untitled"}),e.jsx("span",{className:"wm-toc-words",children:o>0?`${o}w`:"—"})]}),u&&e.jsxs("div",{className:"wm-toc-sections",children:[J.length===0&&e.jsx("div",{className:"wm-toc-sec-empty",children:"No sections yet"}),J.map(w=>{const R=ks.find(ae=>ae.type===w.type)||{icon:"?",label:w.type},_e=Pa.includes(w.type),Ne=w.type==="divider";return e.jsxs("div",{className:`wm-toc-sec-item${_e?" is-header":""}${Ne?" is-divider":""}`,children:[e.jsx("span",{className:"wm-toc-sec-icon",title:R.label,children:R.icon}),Ne?e.jsx("span",{className:"wm-toc-sec-divider-line"}):ie===w.id?e.jsx("input",{className:"wm-toc-sec-edit",value:be,onChange:ae=>ye(ae.target.value),onBlur:xs,onKeyDown:ae=>{ae.key==="Enter"&&xs(),ae.key==="Escape"&&A(null)},placeholder:R.label+"…",autoFocus:!0}):e.jsx("span",{className:"wm-toc-sec-text",onClick:ae=>{ae.stopPropagation(),A(w.id),ye(w.content||"")},children:w.content||e.jsx("span",{className:"wm-toc-sec-placeholder",children:R.label})}),e.jsxs("div",{className:"wm-toc-sec-actions",children:[e.jsx("button",{onClick:ae=>{ae.stopPropagation(),fs(w.id,-1)},title:"Move up",children:"↑"}),e.jsx("button",{onClick:ae=>{ae.stopPropagation(),fs(w.id,1)},title:"Move down",children:"↓"}),e.jsx("button",{className:"wm-toc-sec-del",onClick:ae=>{ae.stopPropagation(),ma(w.id)},title:"Delete",children:"×"})]})]},w.id)}),f&&d===t.id?e.jsx("div",{className:"wm-toc-sec-type-menu",children:ks.map(w=>e.jsxs("button",{className:"wm-toc-sec-type-opt",onClick:()=>pa(w.type),children:[e.jsx("span",{className:"wm-toc-sec-type-icon",children:w.icon})," ",w.label]},w.type))}):e.jsx("button",{className:"wm-toc-sec-add",onClick:w=>{w.stopPropagation(),B(!0)},children:"+ Add Section"})]})]},t.id)})}),ne?e.jsx("div",{className:"wm-toc-add-row",children:e.jsx("input",{className:"wm-toc-add-input",value:he,onChange:t=>c(t.target.value),onBlur:gs,onKeyDown:t=>{t.key==="Enter"&&gs(),t.key==="Escape"&&Z(!1)},placeholder:`Chapter ${l.length+1}`,autoFocus:!0})}):e.jsx("button",{className:"wm-toc-add-btn",onClick:()=>Z(!0),children:"+ Add Chapter"}),e.jsxs("div",{className:"wm-toc-nav",children:[e.jsxs("button",{className:"wm-toc-nav-btn",disabled:l.findIndex(t=>t.id===p)<=0,onClick:()=>dt(-1),children:["←"," Prev"]}),e.jsxs("button",{className:"wm-toc-nav-btn",disabled:l.findIndex(t=>t.id===p)>=l.length-1,onClick:()=>dt(1),children:["Next ","→"]})]})]}),e.jsxs("div",{className:"wm-main-col",children:[e.jsx("div",{className:"wm-center-tabs",children:$a.map(t=>e.jsxs("button",{className:`wm-center-tab${fe===t.id?" wm-center-tab--active":""}`,onClick:()=>ot(t.id),children:[t.label,t.id==="review"&&je.length>0&&e.jsx("span",{className:"wm-tab-badge",children:je.length})]},t.id))}),fe==="write"&&e.jsxs(e.Fragment,{children:[e.jsx("div",{className:"wm-content-row",children:e.jsxs("div",{className:"wm-prose-wrap",ref:Ee,children:[!x.trim()&&!Ks&&e.jsx("div",{className:"wm-scene-interview-wrap",children:e.jsx(ba,{book:T,chapter:r,characters:At,onComplete:()=>ns(!0),onSkip:()=>ns(!0),onLineAdded:()=>{ot("review"),lt()}})}),x.trim()&&e.jsxs("div",{className:"wm-alive-systems",children:[e.jsx(Ma,{chapter:r,onActChange:t=>Gs(t),onThreadChange:t=>Us(t)}),e.jsx(ya,{book:T,chapter:r,onDirectionChange:()=>{}}),e.jsx(La,{chapterCharacters:Os,onCharacterToggle:t=>Hs(t)}),e.jsx(ka,{chapter:r,onExitChange:t=>Ws(t)}),e.jsx(wa,{echoes:Js,onMarkLanded:async t=>{try{await fetch(`${L}/storyteller/echoes/${t}`,{method:"PUT",headers:{"Content-Type":"application/json"},body:JSON.stringify({status:"landed"})}),as(s=>s.map(n=>n.id===t?{...n,status:"landed"}:n))}catch{}}})]}),e.jsxs("div",{className:"wm-manuscript-page",children:[e.jsxs("div",{className:"wm-manuscript-header",children:[e.jsx("span",{className:"wm-mh-book",children:T?.title||""}),e.jsx("span",{className:"wm-mh-chapter",children:r?.chapter_number?`Chapter ${r.chapter_number}`:""})]}),e.jsxs("div",{className:"wm-chapter-opening",children:[e.jsx("div",{className:"wm-chapter-num",children:r?.chapter_number?String(r.chapter_number).padStart(2,"0"):"—"}),e.jsx("h2",{className:"wm-chapter-heading",children:r?.title||"Untitled"}),e.jsx("div",{className:"wm-chapter-ornament",children:"❖"})]}),ra?e.jsx("div",{className:"wm-canvas-sections",children:r.sections.map((t,s)=>{const n=["h2","h3","h4"].includes(t.type);return e.jsxs("div",{className:"wm-cs-block",children:[t.type==="divider"&&e.jsx("div",{className:"wm-cs-divider",children:e.jsx("span",{className:"wm-cs-divider-line"})}),t.type==="h2"&&e.jsx("h2",{className:"wm-cs-h2",children:t.content||"Untitled Section"}),t.type==="h3"&&e.jsx("h3",{className:"wm-cs-h3",children:t.content||"Untitled Section"}),t.type==="h4"&&e.jsx("h4",{className:"wm-cs-h4",children:t.content||"Untitled"}),t.type==="quote"&&e.jsx("blockquote",{className:"wm-cs-quote",children:t.content}),t.type==="reflection"&&e.jsx("div",{className:"wm-cs-reflection",children:t.content}),t.type==="body"&&e.jsx("p",{className:"wm-cs-body",children:t.content}),n&&e.jsx("textarea",{className:"wm-prose-area wm-section-prose",value:ee[t.id]||"",onChange:o=>{la(t.id,o.target.value),ct(o.target)},placeholder:`Write under ${t.content||"this section"}…`,spellCheck:!1,readOnly:E})]},t.id||s)})}):e.jsx("textarea",{className:"wm-prose-area",ref:Dt,value:Ue?x?x.trimEnd()+`

`+Ue:Ue:x,onChange:oa,placeholder:we?"":"Begin writing…",spellCheck:!1,readOnly:E}),e.jsxs("div",{className:"wm-manuscript-footer",children:[e.jsx("span",{className:"wm-mf-words",children:ue>0?`${ue.toLocaleString()} words`:""}),e.jsx("span",{className:"wm-mf-ornament",children:"—"}),e.jsx("span",{className:"wm-mf-page",children:r?.chapter_number?`Ch. ${r.chapter_number}`:""})]})]}),qs&&e.jsxs("div",{className:"wm-ni-panel",children:[e.jsx("div",{className:"wm-ni-panel-header",children:e.jsx("span",{className:"wm-ni-label",children:"Narrative Intelligence"})}),e.jsx(ws,{chapter:r,lines:x.split(/\n\n+/).filter(t=>t.trim()).map((t,s)=>({id:`prose-${s}`,content:t,text:t,status:"approved"})),lineIndex:is-1,book:T,characters:At})]}),!we&&x.trim()&&e.jsx("div",{className:`wm-para-float-hint${X!==null?" active":""}`,onClick:()=>{X!==null?(ve(null),De(null)):ve(0)},title:"Paragraph actions",children:"¶"}),X!==null&&e.jsx("div",{className:"wm-para-overlay",children:x.split(/\n\n+/).map((t,s)=>e.jsxs("div",{className:`wm-para-block${s===X?" selected":""}`,onClick:()=>ve(s===X?null:s),children:[e.jsx("p",{children:t}),s===X&&e.jsxs("div",{className:"wm-para-actions",children:[e.jsx("button",{onClick:n=>{n.stopPropagation(),Et("rewrite")},disabled:E,children:E&&es==="rewrite"?"Rewriting…":"✎ Rewrite"}),e.jsx("button",{onClick:n=>{n.stopPropagation(),Et("expand")},disabled:E,children:E&&es==="expand"?"Expanding…":"↔ Expand"}),e.jsx("button",{className:"wm-para-delete",onClick:n=>{n.stopPropagation(),Et("delete")},disabled:E,children:"✗ Delete"}),e.jsx("button",{className:"wm-para-cancel",onClick:n=>{n.stopPropagation(),ve(null),De(null)},children:"✕"})]})]},s))}),E&&!Ue&&e.jsxs("div",{className:"wm-generating",children:[e.jsxs("div",{className:"wm-generating-dots",children:[e.jsx("span",{className:"wm-generating-dot"}),e.jsx("span",{className:"wm-generating-dot"}),e.jsx("span",{className:"wm-generating-dot"})]}),e.jsx("div",{className:"wm-generating-label",children:Ce==="continue"?"continuing your story":Ce==="deepen"?"deepening the moment":Ce==="nudge"?"thinking":"writing"})]}),Qt&&!E&&e.jsxs("div",{className:"wm-hint",children:[e.jsx("div",{className:"wm-hint-dot"}),e.jsx("div",{className:"wm-hint-text",children:Qt})]})]})}),ke&&Ut&&e.jsx("div",{className:"wm-transcript",children:e.jsx("div",{className:"wm-transcript-text",children:Ut})}),qt&&!E&&e.jsxs("div",{className:"wm-nudge",children:[e.jsx("div",{className:"wm-nudge-icon",children:"💡"}),e.jsx("div",{className:"wm-nudge-text",children:qt}),e.jsx("button",{className:"wm-nudge-close",onClick:()=>We(null),children:"×"})]}),!we&&e.jsxs("div",{className:"wm-ai-toolbar",children:[e.jsxs("button",{className:`wm-ai-btn${Ce==="continue"?" active":""}`,onClick:Mt,disabled:E||!x.trim(),children:[e.jsx("span",{className:"wm-ai-icon",children:"✨"})," Continue"]}),e.jsxs("button",{className:`wm-ai-btn${Ce==="deepen"?" active":""}`,onClick:Bt,disabled:E||!x.trim(),children:[e.jsx("span",{className:"wm-ai-icon",children:"🔍"})," Deepen"]}),e.jsxs("button",{className:`wm-ai-btn${Ce==="nudge"?" active":""}`,onClick:Zs,disabled:E,children:[e.jsx("span",{className:"wm-ai-icon",children:"💡"})," Nudge"]}),Ge!==null&&!E&&e.jsxs("button",{className:"wm-ai-btn wm-undo-ai",onClick:ea,children:[e.jsx("span",{className:"wm-ai-icon",children:"↩"})," Undo"]}),e.jsx("button",{className:`wm-len-toggle${Ae==="sentence"?" sentence":""}`,onClick:()=>Ts(t=>t==="paragraph"?"sentence":"paragraph"),title:Ae==="sentence"?"Generating one sentence at a time":"Generating full paragraphs",children:Ae==="sentence"?"1 line":"¶ full"}),x.trim()&&e.jsxs("button",{className:`wm-ai-btn wm-para-mode-btn${X!==null?" active":""}`,onClick:()=>{X!==null?(ve(null),De(null)):ve(0)},title:"Paragraph-level actions",children:[e.jsx("span",{className:"wm-ai-icon",children:"¶"})," Paragraphs"]})]}),nt&&e.jsxs("div",{className:"wm-history-panel",children:[e.jsxs("div",{className:"wm-history-header",children:[e.jsx("span",{className:"wm-history-title",children:"Snapshots"}),e.jsx("button",{className:"wm-history-close",onClick:()=>it(!1),children:"×"})]}),Re.length===0?e.jsx("div",{className:"wm-history-empty",children:"No snapshots yet. Snapshots are taken automatically before each AI action."}):e.jsx("div",{className:"wm-history-list",children:[...Re].reverse().map((t,s)=>{Re.length-1-s;const n=new Date(t.timestamp),o=`${n.getHours()}:${String(n.getMinutes()).padStart(2,"0")}`;return e.jsxs("div",{className:"wm-history-item",children:[e.jsxs("div",{className:"wm-history-item-header",children:[e.jsx("span",{className:"wm-history-item-label",children:t.label}),e.jsxs("span",{className:"wm-history-item-meta",children:[o," · ",t.wordCount,"w"]})]}),e.jsx("div",{className:"wm-history-item-preview",children:t.prose.length>200?t.prose.slice(0,200)+"…":t.prose}),e.jsx("button",{className:"wm-history-restore",onClick:()=>{de("Before restore"),oe(t.prose),le(t.prose.split(/\s+/).filter(Boolean).length),xe(!1),it(!1)},children:"Restore this version"})]},s)})})]}),we&&e.jsxs("div",{className:"wm-edit-panel",children:[e.jsx("div",{className:"wm-edit-label",children:"What needs to change?"}),e.jsxs("div",{className:"wm-edit-row",children:[e.jsx("textarea",{className:"wm-edit-input",value:Be,onChange:t=>gt(t.target.value),placeholder:"That part is right but she wouldn't say it that way...",rows:3}),e.jsx("button",{className:"wm-edit-mic-btn",onPointerDown:Ys,onPointerUp:Qs,children:_s?e.jsx("span",{className:"wm-mic-active-ring",children:"🎙"}):"🎙"})]}),e.jsx("button",{className:"wm-apply-btn",style:{opacity:Be.trim()?1:.35},onClick:Xs,disabled:!Be.trim()||E,children:E?"Rewriting…":"Apply →"})]}),Jt&&e.jsx("div",{className:"wm-mic-error",children:Jt}),!we&&e.jsxs("div",{className:"wm-bottom-bar",children:[e.jsx("button",{className:`wm-mic-btn${ke?" listening":""}`,onClick:Vs,disabled:E,children:e.jsxs("svg",{width:"28",height:"28",viewBox:"0 0 28 28",fill:"none",children:[e.jsx("rect",{x:"9",y:"3",width:"10",height:"16",rx:"5",fill:ke?"#F5F0E8":"#1a1a1a"}),e.jsx("path",{d:"M5 14c0 5 3.5 9 9 9s9-4 9-9",stroke:ke?"#F5F0E8":"#1a1a1a",strokeWidth:"2",strokeLinecap:"round",fill:"none"}),e.jsx("line",{x1:"14",y1:"23",x2:"14",y2:"26",stroke:ke?"#F5F0E8":"#1a1a1a",strokeWidth:"2",strokeLinecap:"round"})]})}),e.jsx("div",{className:"wm-bottom-hint",children:ke?"Tap mic to stop & write":E?Ce==="continue"?"Continuing…":Ce==="deepen"?"Deepening…":"Writing your story…":x?"Tap mic to speak — or use AI tools above":"Tap mic to speak, or type and use AI tools"}),x.length>20&&e.jsx("button",{className:"wm-send-btn",onClick:ia,disabled:ut,children:ut?"…":"→ Review"})]})]}),fe==="review"&&e.jsxs("div",{className:"wm-review-tab",children:[e.jsxs("div",{className:"wm-review-header",children:[e.jsxs("div",{className:"wm-review-stats",children:[e.jsxs("span",{className:"wm-review-stat approved",children:[Ye.length," approved"]}),je.length>0&&e.jsxs("span",{className:"wm-review-stat pending",children:[je.length," pending"]}),e.jsxs("span",{className:"wm-review-stat total",children:[Ie.length," total"]})]}),je.length>0&&e.jsxs("button",{className:"wm-approve-all-btn",onClick:na,children:["Approve all (",je.length,")"]})]}),Rs?e.jsxs("div",{className:"wm-review-loading",children:["Loading lines","…"]}):Ie.length===0?e.jsxs("div",{className:"wm-review-empty",children:[e.jsx("div",{className:"wm-review-empty-icon",children:"◌"}),e.jsxs("div",{className:"wm-review-empty-text",children:["No lines yet. Write in the Write tab and click ","→"," Review to send them here."]}),e.jsxs("button",{className:"wm-review-go-write",onClick:()=>ot("write"),children:["Go to Write tab ","→"]})]}):e.jsxs("div",{className:"wm-review-manuscript",children:[Ye.map((t,s)=>e.jsxs("div",{children:[bs(t,!1),(s+1)%5===0&&s<Ye.length-1&&e.jsx("div",{className:"wm-ni-inline",children:e.jsx(ws,{chapter:r,lines:Ye.slice(Math.max(0,s-4),s+1),lineIndex:s,book:T,characters:At})})]},t.id)),e.jsx(va,{chapter:r,lines:Ye,book:T,triggerLine:Fs}),je.length>0&&e.jsxs("div",{className:"wm-pending-section",children:[e.jsxs("div",{className:"wm-pending-label",children:[je.length," pending"]}),je.map(t=>bs(t,!0))]})]})]}),fe==="structure"&&e.jsx("div",{className:"wm-panel-tab",children:e.jsx(Ea,{bookId:h,allChapters:l,onChapterUpdate:(t,s)=>{j(n=>n.map(o=>o.id===t?{...o,...s}:o))},onReloadChapters:ls})}),fe==="scenes"&&e.jsx("div",{className:"wm-panel-tab",children:e.jsx(Da,{bookId:h,chapters:l,onChaptersChange:ls,book:T})}),fe==="memory"&&e.jsx("div",{className:"wm-panel-tab",children:e.jsx(ja,{bookId:h})}),fe==="lala"&&e.jsx("div",{className:"wm-panel-tab",children:e.jsx(Na,{bookId:h})}),fe==="export"&&e.jsx("div",{className:"wm-panel-tab",children:e.jsx(Sa,{bookId:h})})]}),F&&e.jsxs("aside",{className:"wm-context-panel",children:[e.jsx("div",{className:"wm-ctx-header",children:e.jsxs("div",{className:"wm-ctx-tabs",children:[e.jsx("button",{className:`wm-ctx-tab${Ze==="plan"?" wm-ctx-tab--active":""}`,onClick:()=>Gt("plan"),children:"Chapter Plan"}),e.jsxs("button",{className:`wm-ctx-tab${Ze==="ai-writer"?" wm-ctx-tab--active":""}`,onClick:()=>Gt("ai-writer"),children:["✦"," Write"]})]})}),Ze==="ai-writer"&&e.jsx(Ta,{chapterId:p,bookId:h,selectedCharacter:null,currentProse:x,chapterContext:{scene_goal:r?.scene_goal,theme:r?.theme,emotional_arc_start:r?.emotional_state_start,emotional_arc_end:r?.emotional_state_end,pov:r?.pov},onInsert:t=>{oe(s=>s?s+`

`+t:t)}}),Ze==="plan"&&e.jsxs(e.Fragment,{children:[e.jsxs("div",{className:"wm-ctx-field",children:[e.jsx("label",{className:"wm-ctx-label",children:"Scene Goal"}),Te==="scene_goal"?e.jsx("textarea",{className:"wm-ctx-input",value:K,onChange:t=>re(t.target.value),onBlur:()=>pe("scene_goal",K),onKeyDown:t=>{t.key==="Enter"&&!t.shiftKey&&(t.preventDefault(),pe("scene_goal",K)),t.key==="Escape"&&te(null)},rows:3,autoFocus:!0}):e.jsx("div",{className:"wm-ctx-value",onClick:()=>{te("scene_goal"),re(r?.scene_goal||"")},title:"Click to edit",children:r?.scene_goal||e.jsx("span",{className:"wm-ctx-empty",children:"What happens in this chapter?"})})]}),e.jsxs("div",{className:"wm-ctx-field",children:[e.jsx("label",{className:"wm-ctx-label",children:"Theme"}),Te==="theme"?e.jsx("input",{className:"wm-ctx-input",value:K,onChange:t=>re(t.target.value),onBlur:()=>pe("theme",K),onKeyDown:t=>{t.key==="Enter"&&pe("theme",K),t.key==="Escape"&&te(null)},autoFocus:!0}):e.jsx("div",{className:"wm-ctx-value",onClick:()=>{te("theme"),re(r?.theme||"")},children:r?.theme||e.jsx("span",{className:"wm-ctx-empty",children:"Central theme"})})]}),e.jsxs("div",{className:"wm-ctx-field",children:[e.jsx("label",{className:"wm-ctx-label",children:"Emotional Arc"}),e.jsxs("div",{className:"wm-ctx-arc",children:[Te==="emotional_state_start"?e.jsx("input",{className:"wm-ctx-input wm-ctx-input-sm",value:K,onChange:t=>re(t.target.value),onBlur:()=>pe("emotional_state_start",K),onKeyDown:t=>{t.key==="Enter"&&pe("emotional_state_start",K),t.key==="Escape"&&te(null)},placeholder:"Start",autoFocus:!0}):e.jsx("span",{className:"wm-ctx-arc-point",onClick:()=>{te("emotional_state_start"),re(r?.emotional_state_start||"")},children:r?.emotional_state_start||"Start"}),e.jsx("span",{className:"wm-ctx-arc-arrow",children:"→"}),Te==="emotional_state_end"?e.jsx("input",{className:"wm-ctx-input wm-ctx-input-sm",value:K,onChange:t=>re(t.target.value),onBlur:()=>pe("emotional_state_end",K),onKeyDown:t=>{t.key==="Enter"&&pe("emotional_state_end",K),t.key==="Escape"&&te(null)},placeholder:"End",autoFocus:!0}):e.jsx("span",{className:"wm-ctx-arc-point",onClick:()=>{te("emotional_state_end"),re(r?.emotional_state_end||"")},children:r?.emotional_state_end||"End"})]})]}),e.jsxs("div",{className:"wm-ctx-field",children:[e.jsx("label",{className:"wm-ctx-label",children:"POV"}),Te==="pov"?e.jsx("input",{className:"wm-ctx-input",value:K,onChange:t=>re(t.target.value),onBlur:()=>pe("pov",K),onKeyDown:t=>{t.key==="Enter"&&pe("pov",K),t.key==="Escape"&&te(null)},autoFocus:!0}):e.jsx("div",{className:"wm-ctx-value",onClick:()=>{te("pov"),re(r?.pov||"")},children:r?.pov||e.jsx("span",{className:"wm-ctx-empty",children:"Perspective"})})]}),e.jsxs("div",{className:"wm-ctx-field",children:[e.jsx("label",{className:"wm-ctx-label",children:"Notes"}),Te==="chapter_notes"?e.jsx("textarea",{className:"wm-ctx-input",value:K,onChange:t=>re(t.target.value),onBlur:()=>pe("chapter_notes",K),onKeyDown:t=>{t.key==="Enter"&&!t.shiftKey&&(t.preventDefault(),pe("chapter_notes",K)),t.key==="Escape"&&te(null)},rows:4,autoFocus:!0}):e.jsx("div",{className:"wm-ctx-value wm-ctx-notes",onClick:()=>{te("chapter_notes"),re(r?.chapter_notes||"")},children:r?.chapter_notes||e.jsx("span",{className:"wm-ctx-empty",children:"Reminders, ideas, references…"})})]}),He&&e.jsxs("div",{className:"wm-ctx-prev",children:[e.jsxs("label",{className:"wm-ctx-label",children:["Previous: ",He.title]}),e.jsxs("div",{className:"wm-ctx-prev-stats",children:[He.wordCount.toLocaleString()," words"]}),He.excerpt?e.jsxs("div",{className:"wm-ctx-prev-excerpt",children:["“",He.excerpt,"”"]}):e.jsx("div",{className:"wm-ctx-prev-excerpt wm-ctx-empty",children:"Not yet written"})]}),e.jsxs("button",{className:"wm-ctx-structure-link",onClick:()=>{D||N(!0),I(t=>{if(t!==p){const s=l.find(o=>o.id===p),n=s?.sections&&Array.isArray(s.sections)?s.sections.map(o=>({...o,id:o.id||Ht()})):[];Q(n)}return p})},children:["☰"," Show Chapter Structure"]})]})]})]}),Es&&e.jsx("div",{className:"wm-modal-overlay",onClick:()=>wt(!1),children:e.jsxs("div",{className:"wm-modal",onClick:t=>t.stopPropagation(),children:[e.jsx("div",{className:"wm-modal-title",children:"Leave Write Mode?"}),e.jsx("div",{className:"wm-modal-sub",children:x?"Your draft is saved. You can come back.":"Nothing written yet."}),e.jsxs("div",{className:"wm-modal-btns",children:[e.jsx("button",{className:"wm-modal-cancel",onClick:()=>wt(!1),children:"Stay"}),e.jsx("button",{className:"wm-modal-leave",onClick:async()=>{x&&await Oe(x),b(`/book/${h}`)},children:x?"Save & Leave":"Leave"})]})]})})]})}export{Ka as default};
