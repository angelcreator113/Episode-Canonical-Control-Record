// Shared environment variables for both API and Worker
const sharedEnv = {
  NODE_ENV: 'development',
  // Prepend Node 20 bin to PATH to ensure it's used
  PATH: '/home/ubuntu/.nvm/versions/node/v20.20.0/bin:' + process.env.PATH,
  NODE_VERSION: '20.20.0',

  // Database Config - AWS RDS Development (use individual vars, not DATABASE_URL)
  DB_HOST: 'episode-control-dev.csnow208wqtv.us-east-1.rds.amazonaws.com',
  DB_PORT: '5432',
  DB_NAME: 'episode_metadata',
  DB_USER: 'postgres',
  DB_PASSWORD: 'Ayanna123!!',
  DATABASE_POOL_MIN: '2',
  DATABASE_POOL_MAX: '10',
  DATABASE_TIMEOUT: '30000',
  DB_SSL: 'true',

  // AWS Config — credentials come from ~/.aws/credentials or env vars
  AWS_REGION: 'us-east-1',
  AWS_ACCOUNT_ID: '637423256673',

  // S3 Buckets - Development
  AWS_S3_BUCKET: 'episode-metadata-storage-dev',
  S3_PRIMARY_BUCKET: 'episode-metadata-storage-dev',
  S3_THUMBNAIL_BUCKET: 'episode-metadata-thumbnails-dev',
  MAX_FILE_UPLOAD_SIZE_MB: '500',

  // Cognito Auth - Development Pool
  COGNITO_USER_POOL_ID: 'us-east-1_mFVU52978',
  COGNITO_CLIENT_ID: 'lgtf3odnar8c456iehqfck1au',
  COGNITO_REGION: 'us-east-1',

  // JWT Tokens
  JWT_SECRET: 'dev-secret-minimum-32-characters-long-for-security',
  JWT_EXPIRATION: '24h',

  // Redis
  REDIS_HOST: '127.0.0.1',
  REDIS_PORT: '6379',

  // Claude AI — Anthropic API (set via GitHub Secret → deploy workflow)
  ANTHROPIC_API_KEY: process.env.ANTHROPIC_API_KEY || '',
};

module.exports = {
  apps: [
    {
      name: 'episode-api',
      script: '/home/ubuntu/episode-metadata/src/server.js',
      cwd: '/home/ubuntu/episode-metadata',
      interpreter: 'node',
      interpreter_args: '',
      instances: 1,
      autorestart: true,
      watch: false,
      max_memory_restart: '1G',
      error_file: '/home/ubuntu/episode-metadata/logs/error.log',
      out_file: '/home/ubuntu/episode-metadata/logs/out.log',
      log_date_format: 'YYYY-MM-DD HH:mm:ss Z',
      env: {
        ...sharedEnv,
        PORT: 3002,
        HOST: '0.0.0.0',
        API_VERSION: 'v1',
        APP_NAME: 'Episode Metadata API (Development)',
        ALLOWED_ORIGINS: 'https://dev.episodes.primestudios.dev,http://localhost:3000,http://localhost:3002,http://localhost:5173,http://127.0.0.1:3002,http://127.0.0.1:5173,https://dev.primepisodes.com',
      }
    },
    {
      name: 'episode-worker',
      script: '/home/ubuntu/episode-metadata/src/workers/start.js',
      cwd: '/home/ubuntu/episode-metadata',
      interpreter: 'node',
      interpreter_args: '',
      instances: 1,
      exec_mode: 'fork',
      autorestart: true,
      watch: false,
      max_memory_restart: '2G',
      error_file: '/home/ubuntu/episode-metadata/logs/worker-error.log',
      out_file: '/home/ubuntu/episode-metadata/logs/worker-out.log',
      log_date_format: 'YYYY-MM-DD HH:mm:ss Z',
      env: {
        ...sharedEnv,
        EXPORT_TEMP_DIR: '/home/ubuntu/episode-metadata/exports-temp',
        EXPORT_MAX_CONCURRENT_JOBS: '1',
      }
    }
  ]
};
