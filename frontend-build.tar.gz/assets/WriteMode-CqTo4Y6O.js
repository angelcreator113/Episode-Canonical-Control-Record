import{j as e,L as Ys}from"./index-BAl95eR3.js";import{b as a,k as Vs,u as Qs}from"./react-vendor-Bbt6Sxdk.js";import{M as Xs,N as ps,C as Zs,a as ea,L as ta,E as sa}from"./ExportPanel-CJtXW2NI.js";import"./pdf-vendor-xECewt3f.js";const aa=[{id:"continue",icon:"→",label:"Continue",sub:"Write what happens next in their voice",endpoint:"/api/v1/memories/story-continue"},{id:"dialogue",icon:"“",label:"Their next line",sub:"What would they say right now",endpoint:"/api/v1/memories/ai-writer-action",action:"dialogue"},{id:"interior",icon:"◌",label:"Interior monologue",sub:"What they are thinking but not saying",endpoint:"/api/v1/memories/ai-writer-action",action:"interior"},{id:"reaction",icon:"↯",label:"Their reaction",sub:"How they respond to what just happened",endpoint:"/api/v1/memories/ai-writer-action",action:"reaction"},{id:"lala",icon:"✦",label:"Lala moment",sub:"The intrusive thought she would never post",endpoint:"/api/v1/memories/ai-writer-action",action:"lala",onlyFor:["special"]}],na={pressure:"#B85C38",mirror:"#9B7FD4",support:"#4A9B6F",shadow:"#E08C3A",special:"#B8962E"};function ra({chapterId:A,bookId:b,selectedCharacter:c,currentProse:H,chapterContext:d,onInsert:J}){const[D,K]=a.useState(null),[f,$]=a.useState(null),[W,pe]=a.useState(!1),[j,P]=a.useState(null),w=na[c?.type]||"#B8962E",z=c?.selected_name||c?.name,F=aa.filter(g=>!g.onlyFor||g.onlyFor.includes(c?.type));async function q(g){if(!c)return;K(g.id),$(null),P(null),pe(!0);const I=H?H.slice(-600):"",Y={chapter_id:A,book_id:b,character_id:c.id,character:{name:z,type:c.type,role:c.role,belief_pressured:c.belief_pressured,emotional_function:c.emotional_function,writer_notes:c.writer_notes},recent_prose:I,chapter_context:d,action:g.action||g.id,length:"paragraph"};try{const ne=await(await fetch(g.endpoint,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(Y)})).json(),re=ne.content||ne.continuation||ne.text||ne.result||ne.suggestion||"";$(re)}catch{P("Generation failed. Try again.")}pe(!1)}function Z(){f&&(J?.(f),$(null),K(null))}function ae(){$(null),K(null)}return c?e.jsxs("div",{style:M.root,children:[e.jsxs("div",{style:M.charHeader,children:[e.jsx("div",{style:{...M.charType,color:w},children:c.type}),e.jsx("div",{style:M.charName,children:z}),c.belief_pressured&&e.jsxs("div",{style:M.charBelief,children:["“",c.belief_pressured,"”"]})]}),!f&&e.jsx("div",{style:M.actions,children:F.map(g=>e.jsxs("button",{style:{...M.actionBtn,background:D===g.id&&W?`${w}10`:"transparent",borderColor:D===g.id?w:"rgba(28,24,20,0.1)",opacity:W&&D!==g.id?.4:1},onClick:()=>q(g),disabled:W,children:[e.jsx("span",{style:{...M.actionIcon,color:w},children:g.icon}),e.jsxs("div",{style:M.actionText,children:[e.jsxs("div",{style:M.actionLabel,children:[g.label,W&&D===g.id&&e.jsxs("span",{style:M.spinner,children:[" ","◌"]})]}),e.jsx("div",{style:M.actionSub,children:g.sub})]})]},g.id))}),f&&e.jsxs("div",{style:M.resultPanel,children:[e.jsxs("div",{style:M.resultHeader,children:[e.jsx("div",{style:{...M.resultAction,color:w},children:F.find(g=>g.id===D)?.label||"Generated"}),e.jsx("button",{style:M.discardBtn,onClick:ae,children:"✕"})]}),e.jsx("div",{style:M.resultText,children:f}),e.jsxs("div",{style:M.resultActions,children:[e.jsx("button",{style:{...M.insertBtn,background:w},onClick:Z,children:"Insert into manuscript"}),e.jsx("button",{style:M.tryAgainBtn,onClick:()=>{const g=F.find(I=>I.id===D);g&&q(g)},children:"Try again"})]})]}),j&&e.jsx("div",{style:M.error,children:j})]}):e.jsxs("div",{style:M.empty,children:[e.jsx("div",{style:M.emptyIcon,children:"◈"}),e.jsx("div",{style:M.emptyText,children:"Select a character from the picker above to write in their voice."})]})}const Mt="#1C1814",rt="rgba(28,24,20,0.5)",ms="rgba(28,24,20,0.25)",ia="#FAF7F0",M={root:{display:"flex",flexDirection:"column",height:"100%",overflow:"hidden"},empty:{display:"flex",flexDirection:"column",alignItems:"center",justifyContent:"center",padding:"32px 16px",gap:12,textAlign:"center",flex:1},emptyIcon:{fontSize:22,color:ms},emptyText:{fontFamily:"'Lora', Georgia, serif",fontStyle:"italic",fontSize:12,color:rt,lineHeight:1.6,maxWidth:200},charHeader:{padding:"12px 14px",borderBottom:"1px solid rgba(28,24,20,0.08)"},charType:{fontSize:7.5,letterSpacing:"0.15em",marginBottom:4,fontFamily:"'DM Mono', monospace"},charName:{fontFamily:"'Cormorant Garamond', Georgia, serif",fontSize:16,color:Mt,marginBottom:4},charBelief:{fontFamily:"'Lora', Georgia, serif",fontStyle:"italic",fontSize:10,color:rt,lineHeight:1.5},actions:{display:"flex",flexDirection:"column",padding:"8px 0",overflowY:"auto",flex:1},actionBtn:{display:"flex",gap:10,padding:"10px 14px",border:"none",borderLeft:"2px solid",cursor:"pointer",textAlign:"left",transition:"all 0.12s ease",marginBottom:1},actionIcon:{fontSize:16,lineHeight:1,flexShrink:0,marginTop:2,fontFamily:"'Cormorant Garamond', Georgia, serif",width:18,textAlign:"center"},actionText:{flex:1},actionLabel:{fontSize:11,color:Mt,letterSpacing:"0.02em",marginBottom:2,fontFamily:"'DM Mono', monospace"},actionSub:{fontSize:9,color:rt,lineHeight:1.4,fontFamily:"'Lora', Georgia, serif",fontStyle:"italic"},spinner:{opacity:.5},resultPanel:{flex:1,display:"flex",flexDirection:"column",padding:"12px 14px",gap:10,overflowY:"auto"},resultHeader:{display:"flex",justifyContent:"space-between",alignItems:"center"},resultAction:{fontSize:8,letterSpacing:"0.15em",fontFamily:"'DM Mono', monospace"},discardBtn:{background:"none",border:"none",color:ms,fontSize:12,cursor:"pointer",padding:"2px 4px"},resultText:{fontFamily:"'Lora', Georgia, serif",fontStyle:"italic",fontSize:13,color:Mt,lineHeight:1.8,flex:1,padding:"10px 12px",background:"rgba(28,24,20,0.03)",borderRadius:3,border:"1px solid rgba(28,24,20,0.08)"},resultActions:{display:"flex",flexDirection:"column",gap:6},insertBtn:{border:"none",borderRadius:3,padding:"10px",color:ia,fontSize:9,letterSpacing:"0.1em",cursor:"pointer",fontFamily:"'DM Mono', monospace"},tryAgainBtn:{background:"none",border:"1px solid rgba(28,24,20,0.1)",borderRadius:3,padding:"8px",color:rt,fontSize:9,letterSpacing:"0.08em",cursor:"pointer",fontFamily:"'DM Mono', monospace"},error:{padding:"10px 14px",fontSize:10,color:"#B85C38",fontStyle:"italic",fontFamily:"'Lora', Georgia, serif"}},Ke="/api/v1",qe=()=>{const A=localStorage.getItem("token")||sessionStorage.getItem("token");return{"Content-Type":"application/json",...A?{Authorization:`Bearer ${A}`}:{}}};function oa({bookId:A,chapters:b=[],onChaptersChange:c,book:H}){const[d,J]=a.useState({}),[D,K]=a.useState(null),[f,$]=a.useState(""),[W,pe]=a.useState(null),[j,P]=a.useState(""),[w,z]=a.useState({}),[F,q]=a.useState({}),[Z,ae]=a.useState(!1),[g,I]=a.useState(null),[Y,ee]=a.useState(null),ne=r=>J(y=>({...y,[r]:!y[r]})),re=b.map(r=>{const y=Array.isArray(r.sections)?r.sections:[],u=y.filter(C=>C.type==="h3");return{...r,scenes:u,allSections:y}}),o=re.reduce((r,y)=>r+y.scenes.length,0),l=a.useCallback(async(r,y)=>{const u=y||f;if(!u?.trim())return;const C=b.find(ke=>ke.id===r);if(!C)return;const v=Array.isArray(C.sections)?[...C.sections]:[],G={id:`sec_${Date.now()}_${Math.random().toString(36).slice(2,8)}`,type:"h3",content:u.trim(),prose:""};v.push(G);try{await fetch(`${Ke}/storyteller/chapters/${r}`,{method:"PUT",headers:qe(),body:JSON.stringify({sections:v})}),c&&c()}catch(ke){console.error("Add scene error:",ke)}K(null),$("")},[f,b,c]),N=a.useCallback(async(r,y,u)=>{const C=b.find(G=>G.id===r);if(!C)return;const v=(Array.isArray(C.sections)?C.sections:[]).map(G=>G.id===y?{...G,content:u}:G);try{await fetch(`${Ke}/storyteller/chapters/${r}`,{method:"PUT",headers:qe(),body:JSON.stringify({sections:v})}),c&&c()}catch(G){console.error("Rename scene error:",G)}pe(null)},[b,c]),R=a.useCallback(async(r,y)=>{const u=b.find(v=>v.id===r);if(!u)return;const C=(Array.isArray(u.sections)?u.sections:[]).filter(v=>v.id!==y);try{await fetch(`${Ke}/storyteller/chapters/${r}`,{method:"PUT",headers:qe(),body:JSON.stringify({sections:C})}),c&&c()}catch(v){console.error("Delete scene error:",v)}},[b,c]),te=a.useCallback(async r=>{z(y=>({...y,[r.id]:!0})),ee(null);try{const y=(Array.isArray(r.sections)?r.sections:[]).filter(v=>v.type==="h3").map(v=>({content:v.content,title:v.content})),u=await fetch(`${Ke}/memories/scene-planner`,{method:"POST",headers:qe(),body:JSON.stringify({book_id:A,chapter_id:r.id,chapter_title:r.title,chapter_type:r.chapter_type||"chapter",existing_scenes:y,draft_prose:r.draft_prose||"",book_title:H?.title||"",book_description:H?.description||"",all_chapters:b.map(v=>({id:v.id,title:v.title,chapter_type:v.chapter_type,scenes:(Array.isArray(v.sections)?v.sections:[]).filter(G=>G.type==="h3")})),theme:r.theme||"",scene_goal:r.scene_goal||""})}),C=await u.json();if(!u.ok)throw new Error(C.error||"AI request failed");q(v=>({...v,[r.id]:C.suggestions||[]}))}catch(y){console.error("AI scene planner error:",y),ee(y.message)}finally{z(y=>({...y,[r.id]:!1}))}},[A,b,H,c]),O=a.useCallback(async()=>{ae(!0),ee(null);try{const r=await fetch(`${Ke}/memories/books/${A}/scenes`,{headers:qe()}),y=await r.json();if(!r.ok)throw new Error(y.error||"AI request failed");I(y.scenes||y)}catch(r){console.error("Book AI scenes error:",r),ee(r.message)}finally{ae(!1)}},[A]),k=a.useCallback(async(r,y)=>{await l(r,y.title),q(u=>({...u,[r]:(u[r]||[]).filter(C=>C.title!==y.title)}))},[l]),ue=a.useCallback(async r=>{const y=r.chapter_id?b.find(u=>u.id===r.chapter_id):b[0];y&&(await l(y.id,r.title),I(u=>u?u.filter(C=>C.title!==r.title):null))},[b,l]),xe=r=>r==="beginning"?"▶":r==="end"?"◀":"◆";return e.jsxs("div",{className:"scenes-panel",children:[e.jsxs("div",{className:"scenes-panel-header",children:[e.jsxs("div",{children:[e.jsx("h3",{className:"scenes-panel-title",children:"Scenes Overview"}),e.jsxs("span",{className:"scenes-panel-count",children:[o," scenes across ",b.length," chapters"]})]}),e.jsx("button",{className:"scenes-panel-ai-book-btn",onClick:O,disabled:Z,title:"AI analyzes your entire book and suggests scenes that would strengthen the arc",children:Z?"⧖ Thinking…":"✨ AI Scene Architect"})]}),Y&&e.jsxs("div",{className:"scenes-panel-ai-error",children:[e.jsxs("span",{children:["⚠"," ",Y]}),e.jsx("button",{onClick:()=>ee(null),children:"×"})]}),g&&g.length>0&&e.jsxs("div",{className:"scenes-panel-ai-book-results",children:[e.jsxs("div",{className:"scenes-panel-ai-book-label",children:["✨"," AI Suggested Scenes for Your Book"]}),g.map((r,y)=>e.jsxs("div",{className:"scenes-panel-ai-card",children:[e.jsxs("div",{className:"scenes-panel-ai-card-head",children:[e.jsx("span",{className:"scenes-panel-ai-card-title",children:r.title}),r.chapter_hint&&e.jsx("span",{className:"scenes-panel-ai-card-ch",children:r.chapter_hint})]}),e.jsx("p",{className:"scenes-panel-ai-card-desc",children:r.description}),r.reason&&e.jsxs("p",{className:"scenes-panel-ai-card-reason",children:[e.jsx("span",{className:"scenes-panel-ai-card-reason-label",children:"Why:"})," ",r.reason]}),r.characters&&r.characters.length>0&&e.jsx("div",{className:"scenes-panel-ai-card-chars",children:r.characters.map(u=>e.jsx("span",{className:"scenes-panel-ai-char-tag",children:u},u))}),e.jsxs("div",{className:"scenes-panel-ai-card-actions",children:[e.jsxs("button",{className:"scenes-panel-ai-accept",onClick:()=>ue(r),title:"Add this scene to the chapter",children:["✓"," Add Scene"]}),e.jsx("button",{className:"scenes-panel-ai-dismiss",onClick:()=>I(u=>u.filter((C,v)=>v!==y)),title:"Dismiss",children:"Dismiss"})]})]},y)),e.jsx("button",{className:"scenes-panel-ai-clear",onClick:()=>I(null),children:"Clear all suggestions"})]}),re.length===0?e.jsx("div",{className:"scenes-panel-empty",children:e.jsx("p",{children:"No chapters yet. Create chapters to start adding scenes."})}):e.jsx("div",{className:"scenes-panel-list",children:re.map((r,y)=>e.jsxs("div",{className:"scenes-panel-chapter",children:[e.jsxs("button",{className:`scenes-panel-chapter-btn${d[r.id]?" expanded":""}`,onClick:()=>ne(r.id),children:[e.jsxs("span",{className:"scenes-panel-ch-num",children:["Ch. ",r.chapter_number||y+1]}),r.chapter_type&&r.chapter_type!=="chapter"&&e.jsx("span",{className:"scenes-panel-ch-type",children:r.chapter_type}),e.jsx("span",{className:"scenes-panel-ch-title",children:r.title||"Untitled"}),e.jsxs("span",{className:"scenes-panel-ch-count",children:[r.scenes.length," scene",r.scenes.length!==1?"s":""]}),e.jsx("span",{className:"scenes-panel-ch-arrow",children:d[r.id]?"▾":"▸"})]}),d[r.id]&&e.jsxs("div",{className:"scenes-panel-scenes",children:[r.scenes.length===0?e.jsx("div",{className:"scenes-panel-no-scenes",children:"No scenes defined"}):r.scenes.map((u,C)=>e.jsxs("div",{className:"scenes-panel-scene",children:[e.jsx("span",{className:"scenes-panel-scene-num",children:C+1}),e.jsx("span",{className:"scenes-panel-scene-dinkus",children:"✦"}),W&&W.chId===r.id&&W.secId===u.id?e.jsx("input",{className:"scenes-panel-scene-edit",value:j,onChange:v=>P(v.target.value),onBlur:()=>N(r.id,u.id,j),onKeyDown:v=>{v.key==="Enter"&&N(r.id,u.id,j),v.key==="Escape"&&pe(null)},autoFocus:!0}):e.jsx("span",{className:"scenes-panel-scene-title",onDoubleClick:()=>{pe({chId:r.id,secId:u.id}),P(u.content||"")},title:"Double-click to rename",children:u.content||"Untitled Scene"}),e.jsx("button",{className:"scenes-panel-scene-del",onClick:()=>R(r.id,u.id),title:"Delete scene",children:"×"})]},u.id||C)),D===r.id?e.jsxs("div",{className:"scenes-panel-add-row",children:[e.jsx("input",{className:"scenes-panel-add-input",value:f,onChange:u=>$(u.target.value),onKeyDown:u=>{u.key==="Enter"&&l(r.id),u.key==="Escape"&&(K(null),$(""))},placeholder:"Scene title…",autoFocus:!0}),e.jsx("button",{className:"scenes-panel-add-confirm",onClick:()=>l(r.id),children:"✓"}),e.jsx("button",{className:"scenes-panel-add-cancel",onClick:()=>{K(null),$("")},children:"×"})]}):e.jsxs("div",{className:"scenes-panel-add-row-buttons",children:[e.jsx("button",{className:"scenes-panel-add-btn",onClick:()=>{K(r.id),$("")},children:"+ Add Scene"}),e.jsx("button",{className:"scenes-panel-ai-plan-btn",onClick:()=>te(r),disabled:w[r.id],title:"AI reads your chapter and suggests scenes",children:w[r.id]?"⧖ Planning…":"✨ AI Plan Scenes"})]}),F[r.id]&&F[r.id].length>0&&e.jsxs("div",{className:"scenes-panel-ai-suggestions",children:[e.jsxs("div",{className:"scenes-panel-ai-label",children:["✨"," AI Suggestions"]}),F[r.id].map((u,C)=>e.jsxs("div",{className:"scenes-panel-ai-sug-card",children:[e.jsxs("div",{className:"scenes-panel-ai-sug-head",children:[e.jsx("span",{className:"scenes-panel-ai-sug-pos",title:u.suggested_position||"middle",children:xe(u.suggested_position)}),e.jsx("span",{className:"scenes-panel-ai-sug-title",children:u.title}),u.emotional_beat&&e.jsx("span",{className:"scenes-panel-ai-sug-beat",children:u.emotional_beat})]}),e.jsx("p",{className:"scenes-panel-ai-sug-desc",children:u.description}),u.purpose&&e.jsxs("p",{className:"scenes-panel-ai-sug-purpose",children:[e.jsx("span",{className:"scenes-panel-ai-sug-purpose-label",children:"Purpose:"})," ",u.purpose]}),e.jsxs("div",{className:"scenes-panel-ai-sug-actions",children:[e.jsxs("button",{className:"scenes-panel-ai-accept",onClick:()=>k(r.id,u),children:["✓"," Add Scene"]}),e.jsx("button",{className:"scenes-panel-ai-dismiss",onClick:()=>q(v=>({...v,[r.id]:(v[r.id]||[]).filter((G,ke)=>ke!==C)})),children:"Dismiss"})]})]},C)),e.jsx("button",{className:"scenes-panel-ai-clear",onClick:()=>q(u=>({...u,[r.id]:[]})),children:"Clear suggestions"})]})]})]},r.id))}),e.jsx("style",{children:`
        .scenes-panel { padding: 24px; max-width: 760px; margin: 0 auto; }
        .scenes-panel-header {
          display: flex; align-items: flex-start; justify-content: space-between;
          margin-bottom: 24px; gap: 16px; flex-wrap: wrap;
        }
        .scenes-panel-title {
          font-family: 'Playfair Display', 'Lora', Georgia, serif;
          font-size: 20px; font-weight: 600; color: #1C1814; margin: 0 0 4px;
        }
        .scenes-panel-count {
          font-family: 'DM Mono', monospace; font-size: 10px;
          letter-spacing: 0.1em; color: rgba(28,24,20,0.4);
        }
        .scenes-panel-empty {
          text-align: center; padding: 48px 24px;
          font-family: 'Lora', Georgia, serif; font-style: italic;
          color: rgba(28,24,20,0.4); font-size: 14px;
        }

        /* ── Book-level AI button ── */
        .scenes-panel-ai-book-btn {
          background: linear-gradient(135deg, rgba(198,168,94,0.08), rgba(198,168,94,0.15));
          border: 1px solid rgba(198,168,94,0.25);
          border-radius: 6px; padding: 8px 16px;
          font-family: 'DM Mono', monospace; font-size: 10px;
          letter-spacing: 0.08em; color: #B8962E;
          cursor: pointer; transition: all 0.15s ease; white-space: nowrap;
        }
        .scenes-panel-ai-book-btn:hover:not(:disabled) {
          background: linear-gradient(135deg, rgba(198,168,94,0.15), rgba(198,168,94,0.25));
          border-color: rgba(198,168,94,0.4);
        }
        .scenes-panel-ai-book-btn:disabled { opacity: 0.6; cursor: wait; }

        /* ── AI error ── */
        .scenes-panel-ai-error {
          display: flex; align-items: center; justify-content: space-between;
          background: rgba(184,92,56,0.06); border: 1px solid rgba(184,92,56,0.15);
          border-radius: 6px; padding: 10px 14px; margin-bottom: 16px;
          font-family: 'DM Sans', sans-serif; font-size: 12px; color: #B85C38;
        }
        .scenes-panel-ai-error button {
          background: none; border: none; font-size: 16px;
          color: #B85C38; cursor: pointer;
        }

        /* ── Book-wide AI results ── */
        .scenes-panel-ai-book-results {
          background: rgba(198,168,94,0.03);
          border: 1px solid rgba(198,168,94,0.12);
          border-radius: 8px; padding: 16px; margin-bottom: 24px;
        }
        .scenes-panel-ai-book-label {
          font-family: 'DM Mono', monospace; font-size: 10px;
          letter-spacing: 0.12em; color: #B8962E; margin-bottom: 12px;
          text-transform: uppercase;
        }

        /* ── AI card (book-wide) ── */
        .scenes-panel-ai-card {
          background: rgba(250,248,245,0.8);
          border: 1px solid rgba(232,226,218,0.6);
          border-radius: 6px; padding: 12px 14px; margin-bottom: 10px;
        }
        .scenes-panel-ai-card-head {
          display: flex; align-items: baseline; gap: 8px; margin-bottom: 6px;
        }
        .scenes-panel-ai-card-title {
          font-family: 'Lora', Georgia, serif; font-size: 14px;
          font-weight: 600; color: #1C1814;
        }
        .scenes-panel-ai-card-ch {
          font-family: 'DM Mono', monospace; font-size: 9px;
          color: rgba(28,24,20,0.35); letter-spacing: 0.05em;
        }
        .scenes-panel-ai-card-desc {
          font-family: 'Lora', Georgia, serif; font-size: 12.5px;
          color: rgba(28,24,20,0.7); line-height: 1.5; margin: 0 0 6px;
        }
        .scenes-panel-ai-card-reason {
          font-family: 'DM Sans', sans-serif; font-size: 11px;
          color: rgba(28,24,20,0.45); margin: 0 0 6px; font-style: italic;
        }
        .scenes-panel-ai-card-reason-label {
          font-weight: 600; font-style: normal; color: rgba(28,24,20,0.5);
        }
        .scenes-panel-ai-card-chars {
          display: flex; gap: 4px; flex-wrap: wrap; margin-bottom: 8px;
        }
        .scenes-panel-ai-char-tag {
          font-family: 'DM Mono', monospace; font-size: 9px;
          background: rgba(198,168,94,0.1); color: #B8962E;
          border-radius: 3px; padding: 2px 6px;
        }
        .scenes-panel-ai-card-actions {
          display: flex; gap: 8px;
        }

        /* ── Per-chapter AI plan button ── */
        .scenes-panel-add-row-buttons {
          display: flex; align-items: center; gap: 12px; padding: 4px 0;
        }
        .scenes-panel-ai-plan-btn {
          background: none; border: none;
          font-family: 'DM Mono', monospace; font-size: 9px;
          letter-spacing: 0.08em; color: #B8962E;
          cursor: pointer; padding: 8px 0; transition: all 0.12s ease;
          opacity: 0.7;
        }
        .scenes-panel-ai-plan-btn:hover:not(:disabled) { opacity: 1; }
        .scenes-panel-ai-plan-btn:disabled { opacity: 0.5; cursor: wait; }

        /* ── AI suggestions per chapter ── */
        .scenes-panel-ai-suggestions {
          background: rgba(198,168,94,0.03);
          border: 1px solid rgba(198,168,94,0.1);
          border-radius: 6px; padding: 12px; margin-top: 8px;
        }
        .scenes-panel-ai-label {
          font-family: 'DM Mono', monospace; font-size: 9px;
          letter-spacing: 0.12em; color: #B8962E; margin-bottom: 10px;
          text-transform: uppercase;
        }
        .scenes-panel-ai-sug-card {
          background: rgba(250,248,245,0.8);
          border: 1px solid rgba(232,226,218,0.5);
          border-radius: 5px; padding: 10px 12px; margin-bottom: 8px;
        }
        .scenes-panel-ai-sug-head {
          display: flex; align-items: baseline; gap: 6px; margin-bottom: 4px;
        }
        .scenes-panel-ai-sug-pos {
          font-size: 8px; color: rgba(28,24,20,0.25);
        }
        .scenes-panel-ai-sug-title {
          font-family: 'Lora', Georgia, serif; font-size: 13px;
          font-weight: 600; color: #1C1814;
        }
        .scenes-panel-ai-sug-beat {
          font-family: 'DM Sans', sans-serif; font-size: 10px;
          color: #B8962E; font-style: italic; margin-left: auto;
        }
        .scenes-panel-ai-sug-desc {
          font-family: 'Lora', Georgia, serif; font-size: 12px;
          color: rgba(28,24,20,0.65); line-height: 1.45; margin: 0 0 4px;
        }
        .scenes-panel-ai-sug-purpose {
          font-family: 'DM Sans', sans-serif; font-size: 10.5px;
          color: rgba(28,24,20,0.4); margin: 0 0 6px; font-style: italic;
        }
        .scenes-panel-ai-sug-purpose-label {
          font-weight: 600; font-style: normal; color: rgba(28,24,20,0.45);
        }
        .scenes-panel-ai-sug-actions {
          display: flex; gap: 8px;
        }

        /* ── Shared AI action buttons ── */
        .scenes-panel-ai-accept {
          background: rgba(74,155,111,0.08); border: 1px solid rgba(74,155,111,0.2);
          border-radius: 4px; padding: 4px 10px;
          font-family: 'DM Mono', monospace; font-size: 9px;
          color: #4A9B6F; cursor: pointer; transition: all 0.12s ease;
        }
        .scenes-panel-ai-accept:hover {
          background: rgba(74,155,111,0.15); border-color: rgba(74,155,111,0.35);
        }
        .scenes-panel-ai-dismiss {
          background: none; border: none;
          font-family: 'DM Mono', monospace; font-size: 9px;
          color: rgba(28,24,20,0.3); cursor: pointer;
        }
        .scenes-panel-ai-dismiss:hover { color: rgba(28,24,20,0.5); }
        .scenes-panel-ai-clear {
          background: none; border: none;
          font-family: 'DM Mono', monospace; font-size: 9px;
          color: rgba(28,24,20,0.25); cursor: pointer;
          padding: 6px 0; margin-top: 4px;
        }
        .scenes-panel-ai-clear:hover { color: rgba(28,24,20,0.4); }

        /* ── Chapter type badge ── */
        .scenes-panel-ch-type {
          font-family: 'DM Mono', monospace; font-size: 8px;
          letter-spacing: 0.08em; text-transform: uppercase;
          color: #B8962E; background: rgba(198,168,94,0.08);
          border-radius: 3px; padding: 1px 5px;
        }

        /* ── Existing styles ── */
        .scenes-panel-chapter { margin-bottom: 2px; }
        .scenes-panel-chapter-btn {
          display: flex; align-items: center; gap: 10px; width: 100%;
          background: none; border: none; border-bottom: 1px solid rgba(28,24,20,0.06);
          padding: 12px 8px; cursor: pointer; text-align: left;
          transition: background 0.12s ease;
        }
        .scenes-panel-chapter-btn:hover { background: rgba(28,24,20,0.02); }
        .scenes-panel-ch-num {
          font-family: 'DM Mono', monospace; font-size: 10px;
          color: rgba(28,24,20,0.35); min-width: 40px;
        }
        .scenes-panel-ch-title {
          flex: 1; font-family: 'Lora', Georgia, serif; font-size: 14px; color: #1C1814;
        }
        .scenes-panel-ch-count {
          font-family: 'DM Mono', monospace; font-size: 9px;
          color: rgba(28,24,20,0.3); letter-spacing: 0.05em;
        }
        .scenes-panel-ch-arrow {
          font-size: 10px; color: rgba(28,24,20,0.3); min-width: 14px; text-align: center;
        }
        .scenes-panel-scenes {
          padding: 4px 0 12px 52px;
        }
        .scenes-panel-no-scenes {
          font-family: 'Lora', Georgia, serif; font-style: italic;
          font-size: 12px; color: rgba(28,24,20,0.3); padding: 8px 0;
        }
        .scenes-panel-scene {
          display: flex; align-items: center; gap: 8px;
          padding: 6px 0; font-family: 'Lora', Georgia, serif; font-size: 13px;
        }
        .scenes-panel-scene-num {
          font-family: 'DM Mono', monospace; font-size: 9px;
          color: rgba(28,24,20,0.25); min-width: 16px;
        }
        .scenes-panel-scene-dinkus {
          font-size: 8px; color: #B8962E; opacity: 0.6;
        }
        .scenes-panel-scene-title {
          color: #1C1814; cursor: default; flex: 1;
        }
        .scenes-panel-scene-title:hover { text-decoration: underline dotted rgba(28,24,20,0.2); }
        .scenes-panel-scene-edit {
          flex: 1; border: none; border-bottom: 1px solid rgba(184,150,46,0.4);
          background: none; font-family: 'Lora', Georgia, serif; font-size: 13px;
          color: #1C1814; padding: 2px 0; outline: none;
        }
        .scenes-panel-scene-del {
          background: none; border: none; font-size: 14px; color: rgba(28,24,20,0.2);
          cursor: pointer; padding: 2px 4px; opacity: 0; transition: opacity 0.1s ease;
        }
        .scenes-panel-scene:hover .scenes-panel-scene-del { opacity: 1; }
        .scenes-panel-scene-del:hover { color: #B85C38; }

        /* Add scene */
        .scenes-panel-add-btn {
          background: none; border: none; font-family: 'DM Mono', monospace;
          font-size: 9px; letter-spacing: 0.08em; color: rgba(28,24,20,0.35);
          cursor: pointer; padding: 8px 0; transition: color 0.12s ease;
        }
        .scenes-panel-add-btn:hover { color: #B8962E; }
        .scenes-panel-add-row {
          display: flex; align-items: center; gap: 6px; padding: 6px 0;
        }
        .scenes-panel-add-input {
          flex: 1; border: none; border-bottom: 1px solid rgba(28,24,20,0.12);
          background: none; font-family: 'Lora', Georgia, serif; font-size: 13px;
          color: #1C1814; padding: 4px 0; outline: none;
        }
        .scenes-panel-add-input:focus { border-bottom-color: rgba(184,150,46,0.4); }
        .scenes-panel-add-confirm,
        .scenes-panel-add-cancel {
          background: none; border: none; font-size: 14px;
          cursor: pointer; padding: 2px 4px; color: rgba(28,24,20,0.4);
        }
        .scenes-panel-add-confirm:hover { color: #4A9B6F; }
        .scenes-panel-add-cancel:hover { color: #B85C38; }

        @media (max-width: 480px) {
          .scenes-panel { padding: 16px 12px; }
          .scenes-panel-scenes { padding-left: 32px; }
          .scenes-panel-header { flex-direction: column; }
          .scenes-panel-ai-sug-head { flex-wrap: wrap; }
        }
      `})]})}const Dt="/api/v1",hs=[{value:"prologue",label:"Prologue",icon:"◈"},{value:"chapter",label:"Chapter",icon:"§"},{value:"interlude",label:"Interlude",icon:"~"},{value:"epilogue",label:"Epilogue",icon:"◇"},{value:"afterword",label:"Afterword",icon:"∗"}],$t=A=>{const b=[10,9,5,4,1],c=["X","IX","V","IV","I"];let H="";return b.forEach((d,J)=>{for(;A>=d;)H+=c[J],A-=d}),H||""},Pt=()=>{const A=localStorage.getItem("token")||sessionStorage.getItem("token");return{"Content-Type":"application/json",...A?{Authorization:`Bearer ${A}`}:{}}};function la({bookId:A,allChapters:b=[],onChapterUpdate:c,onReloadChapters:H}){const[d,J]=a.useState(null),[D,K]=a.useState(!0),[f,$]=a.useState("overview"),[W,pe]=a.useState(!1),[j,P]=a.useState({dedication:"",epigraph:"",epigraph_attribution:"",foreword:"",preface:"",copyright:""}),[w,z]=a.useState({about_author:"",acknowledgments:"",glossary:"",appendix:"",bibliography:"",notes:""}),[F,q]=a.useState("");a.useEffect(()=>{A&&(K(!0),fetch(`${Dt}/storyteller/books/${A}`,{headers:Pt()}).then(o=>o.json()).then(o=>{const l=o.book||o;J(l),q(l.author_name||""),l.front_matter&&P(N=>({...N,...l.front_matter})),l.back_matter&&z(N=>({...N,...l.back_matter}))}).catch(console.error).finally(()=>K(!1)))},[A]);const Z=a.useCallback(async()=>{if(A){pe(!0);try{await fetch(`${Dt}/storyteller/books/${A}`,{method:"PUT",headers:Pt(),body:JSON.stringify({author_name:F,front_matter:j,back_matter:w})})}catch(o){console.error("Save book meta error:",o)}finally{pe(!1)}}},[A,F,j,w]),ae=a.useCallback(async(o,l)=>{try{await fetch(`${Dt}/storyteller/chapters/${o}`,{method:"PUT",headers:Pt(),body:JSON.stringify(l)}),c&&c(o,l)}catch(N){console.error("Save chapter meta error:",N)}},[c]),g=[...b].sort((o,l)=>(o.sort_order??o.chapter_number??0)-(l.sort_order??l.chapter_number??0)),I=g.reduce((o,l)=>{const N=l.part_number||0;return o[N]||(o[N]={number:N,title:l.part_title||"",chapters:[]}),o[N].chapters.push(l),o},{}),Y=Object.values(I).sort((o,l)=>o.number-l.number),ee=g.reduce((o,l)=>{const N=l.draft_prose?l.draft_prose.split(/\s+/).filter(Boolean).length:0;return o+N},0),ne=g.reduce((o,l)=>{const N=l.sections||[];return o+N.filter(R=>R.type==="h3").length},0),re=[{id:"overview",label:"Overview",icon:"📖"},{id:"front",label:"Front Matter",icon:"◈"},{id:"structure",label:"Parts & Chapters",icon:"§"},{id:"back",label:"Back Matter",icon:"◇"}];return D?e.jsx("div",{className:"bsp-loading",children:e.jsx("span",{className:"bsp-loading-text",children:"Loading book structure…"})}):e.jsxs("div",{className:"bsp-panel",children:[e.jsx("div",{className:"bsp-nav",children:re.map(o=>e.jsxs("button",{className:`bsp-nav-btn${f===o.id?" active":""}`,onClick:()=>$(o.id),children:[e.jsx("span",{className:"bsp-nav-icon",children:o.icon}),e.jsx("span",{className:"bsp-nav-label",children:o.label})]},o.id))}),f==="overview"&&e.jsxs("div",{className:"bsp-section",children:[e.jsxs("div",{className:"bsp-overview-header",children:[e.jsx("h2",{className:"bsp-title",children:d?.title||"Untitled"}),d?.subtitle&&e.jsx("p",{className:"bsp-subtitle",children:d.subtitle})]}),e.jsxs("div",{className:"bsp-stats-grid",children:[e.jsxs("div",{className:"bsp-stat",children:[e.jsx("span",{className:"bsp-stat-num",children:g.length}),e.jsx("span",{className:"bsp-stat-label",children:"Chapters"})]}),e.jsxs("div",{className:"bsp-stat",children:[e.jsx("span",{className:"bsp-stat-num",children:ne}),e.jsx("span",{className:"bsp-stat-label",children:"Scenes"})]}),e.jsxs("div",{className:"bsp-stat",children:[e.jsx("span",{className:"bsp-stat-num",children:ee.toLocaleString()}),e.jsx("span",{className:"bsp-stat-label",children:"Words"})]}),e.jsxs("div",{className:"bsp-stat",children:[e.jsx("span",{className:"bsp-stat-num",children:Math.max(1,Math.round(ee/250))}),e.jsx("span",{className:"bsp-stat-label",children:"Min Read"})]})]}),e.jsxs("div",{className:"bsp-outline",children:[e.jsx("h3",{className:"bsp-outline-title",children:"Book Outline"}),e.jsxs("div",{className:"bsp-outline-group",children:[e.jsx("span",{className:"bsp-outline-group-label",children:"Front Matter"}),e.jsxs("div",{className:"bsp-outline-pills",children:[j.dedication&&e.jsx("span",{className:"bsp-pill filled",children:"Dedication"}),j.epigraph&&e.jsx("span",{className:"bsp-pill filled",children:"Epigraph"}),j.foreword&&e.jsx("span",{className:"bsp-pill filled",children:"Foreword"}),j.preface&&e.jsx("span",{className:"bsp-pill filled",children:"Preface"}),j.copyright&&e.jsx("span",{className:"bsp-pill filled",children:"Copyright"}),!j.dedication&&!j.epigraph&&!j.foreword&&!j.preface&&!j.copyright&&e.jsx("span",{className:"bsp-pill empty",children:"None added yet"})]})]}),Y.map(o=>e.jsxs("div",{className:"bsp-outline-group",children:[o.number>0&&e.jsxs("span",{className:"bsp-outline-part-label",children:["Part ",$t(o.number),o.title?` — ${o.title}`:""]}),o.number===0&&Y.length>1&&e.jsx("span",{className:"bsp-outline-part-label bsp-outline-part-unassigned",children:"Unassigned"}),o.chapters.map((l,N)=>{const R=hs.find(k=>k.value===(l.chapter_type||"chapter")),te=l.draft_prose?l.draft_prose.split(/\s+/).filter(Boolean).length:0,O=(l.sections||[]).filter(k=>k.type==="h3").length;return e.jsxs("div",{className:"bsp-outline-chapter",children:[e.jsx("span",{className:"bsp-outline-ch-icon",children:R?.icon||"§"}),e.jsx("span",{className:"bsp-outline-ch-type",children:R?.label||"Chapter"}),e.jsx("span",{className:"bsp-outline-ch-title",children:l.title||"Untitled"}),e.jsxs("span",{className:"bsp-outline-ch-meta",children:[O>0&&`${O} scene${O>1?"s":""}`,O>0&&te>0&&" · ",te>0&&`${te.toLocaleString()}w`]})]},l.id)})]},o.number)),e.jsxs("div",{className:"bsp-outline-group",children:[e.jsx("span",{className:"bsp-outline-group-label",children:"Back Matter"}),e.jsxs("div",{className:"bsp-outline-pills",children:[w.about_author&&e.jsx("span",{className:"bsp-pill filled",children:"About the Author"}),w.acknowledgments&&e.jsx("span",{className:"bsp-pill filled",children:"Acknowledgments"}),w.glossary&&e.jsx("span",{className:"bsp-pill filled",children:"Glossary"}),w.appendix&&e.jsx("span",{className:"bsp-pill filled",children:"Appendix"}),w.bibliography&&e.jsx("span",{className:"bsp-pill filled",children:"Bibliography"}),w.notes&&e.jsx("span",{className:"bsp-pill filled",children:"Notes"}),!w.about_author&&!w.acknowledgments&&!w.glossary&&!w.appendix&&!w.bibliography&&!w.notes&&e.jsx("span",{className:"bsp-pill empty",children:"None added yet"})]})]})]})]}),f==="front"&&e.jsxs("div",{className:"bsp-section",children:[e.jsxs("div",{className:"bsp-section-header",children:[e.jsx("h3",{className:"bsp-section-title",children:"Front Matter"}),e.jsx("p",{className:"bsp-section-desc",children:"These pages appear before Chapter 1 in your manuscript."})]}),e.jsxs("div",{className:"bsp-field",children:[e.jsx("label",{className:"bsp-field-label",children:"Author Name"}),e.jsx("input",{className:"bsp-input",value:F,onChange:o=>q(o.target.value),placeholder:"Your name as it appears on the title page"})]}),e.jsxs("div",{className:"bsp-field",children:[e.jsx("label",{className:"bsp-field-label",children:"Copyright Page"}),e.jsx("textarea",{className:"bsp-textarea",value:j.copyright,onChange:o=>P(l=>({...l,copyright:o.target.value})),placeholder:`© ${new Date().getFullYear()} ${F||"[Author Name]"}. All rights reserved.

No part of this publication may be reproduced...`,rows:4})]}),e.jsxs("div",{className:"bsp-field",children:[e.jsx("label",{className:"bsp-field-label",children:"Dedication"}),e.jsx("textarea",{className:"bsp-textarea bsp-textarea--short",value:j.dedication,onChange:o=>P(l=>({...l,dedication:o.target.value})),placeholder:"For those who dare to imagine…",rows:2})]}),e.jsxs("div",{className:"bsp-field",children:[e.jsx("label",{className:"bsp-field-label",children:"Epigraph"}),e.jsx("textarea",{className:"bsp-textarea bsp-textarea--short",value:j.epigraph,onChange:o=>P(l=>({...l,epigraph:o.target.value})),placeholder:"A quote that sets the tone for the entire work…",rows:2}),e.jsx("input",{className:"bsp-input bsp-input--secondary",value:j.epigraph_attribution,onChange:o=>P(l=>({...l,epigraph_attribution:o.target.value})),placeholder:"— Attribution (e.g., Virginia Woolf)"})]}),e.jsxs("div",{className:"bsp-field",children:[e.jsx("label",{className:"bsp-field-label",children:"Foreword"}),e.jsx("p",{className:"bsp-field-hint",children:"Written by someone other than the author — an endorsement or context-setting piece."}),e.jsx("textarea",{className:"bsp-textarea",value:j.foreword,onChange:o=>P(l=>({...l,foreword:o.target.value})),placeholder:"Press Enter to begin your foreword…",rows:6})]}),e.jsxs("div",{className:"bsp-field",children:[e.jsx("label",{className:"bsp-field-label",children:"Preface"}),e.jsx("p",{className:"bsp-field-hint",children:"Written by the author — explains why you wrote this book and how to read it."}),e.jsx("textarea",{className:"bsp-textarea",value:j.preface,onChange:o=>P(l=>({...l,preface:o.target.value})),placeholder:"Press Enter to begin your preface…",rows:6})]}),e.jsx("div",{className:"bsp-save-row",children:e.jsx("button",{className:"bsp-save-btn",onClick:Z,disabled:W,children:W?"Saving…":"Save Front Matter"})})]}),f==="structure"&&e.jsxs("div",{className:"bsp-section",children:[e.jsxs("div",{className:"bsp-section-header",children:[e.jsx("h3",{className:"bsp-section-title",children:"Parts & Chapters"}),e.jsx("p",{className:"bsp-section-desc",children:"Organize chapters into Parts/Acts and set chapter types (Prologue, Interlude, Epilogue, etc.)."})]}),g.map((o,l)=>{const N=o.chapter_type||"chapter",R=o.part_number||0,te=l>0?g[l-1].part_number||0:-1,O=R!==te&&R>0;return e.jsxs("div",{children:[O&&e.jsxs("div",{className:"bsp-part-header",children:[e.jsxs("span",{className:"bsp-part-numeral",children:["Part ",$t(R)]}),e.jsx("input",{className:"bsp-part-title-input",value:o.part_title||"",onChange:k=>{const ue=k.target.value;g.filter(xe=>xe.part_number===R).forEach(xe=>{ae(xe.id,{part_title:ue})})},placeholder:"Part title (optional)"})]}),e.jsxs("div",{className:"bsp-chapter-row",children:[e.jsxs("div",{className:"bsp-ch-left",children:[e.jsx("span",{className:"bsp-ch-num",children:o.chapter_number||l+1}),e.jsx("span",{className:"bsp-ch-title",children:o.title||"Untitled"})]}),e.jsxs("div",{className:"bsp-ch-controls",children:[e.jsx("select",{className:"bsp-select",value:N,onChange:k=>ae(o.id,{chapter_type:k.target.value}),children:hs.map(k=>e.jsxs("option",{value:k.value,children:[k.icon," ",k.label]},k.value))}),e.jsxs("select",{className:"bsp-select bsp-select--part",value:R,onChange:k=>ae(o.id,{part_number:parseInt(k.target.value)||null,part_title:k.target.value==0?null:o.part_title}),children:[e.jsx("option",{value:0,children:"No Part"}),[1,2,3,4,5,6,7,8].map(k=>e.jsxs("option",{value:k,children:["Part ",$t(k)]},k))]}),(()=>{const k=(o.sections||[]).filter(ue=>ue.type==="h3").length;return k>0?e.jsxs("span",{className:"bsp-scene-badge",children:[k," scene",k>1?"s":""]}):null})()]})]})]},o.id)}),g.length===0&&e.jsx("div",{className:"bsp-empty",children:"No chapters yet. Add chapters from the TOC sidebar."})]}),f==="back"&&e.jsxs("div",{className:"bsp-section",children:[e.jsxs("div",{className:"bsp-section-header",children:[e.jsx("h3",{className:"bsp-section-title",children:"Back Matter"}),e.jsx("p",{className:"bsp-section-desc",children:"These pages appear after the final chapter."})]}),e.jsxs("div",{className:"bsp-field",children:[e.jsx("label",{className:"bsp-field-label",children:"About the Author"}),e.jsx("textarea",{className:"bsp-textarea",value:w.about_author,onChange:o=>z(l=>({...l,about_author:o.target.value})),placeholder:"A short biography — who you are, what you write, where you live…",rows:5})]}),e.jsxs("div",{className:"bsp-field",children:[e.jsx("label",{className:"bsp-field-label",children:"Acknowledgments"}),e.jsx("textarea",{className:"bsp-textarea",value:w.acknowledgments,onChange:o=>z(l=>({...l,acknowledgments:o.target.value})),placeholder:"Thank the people and forces that made this book possible…",rows:5})]}),e.jsxs("div",{className:"bsp-field",children:[e.jsx("label",{className:"bsp-field-label",children:"Glossary"}),e.jsxs("p",{className:"bsp-field-hint",children:["Define specialized terms used in your book. One term per line: ",e.jsx("em",{children:"Term — Definition"})]}),e.jsx("textarea",{className:"bsp-textarea",value:w.glossary,onChange:o=>z(l=>({...l,glossary:o.target.value})),placeholder:"Chronoweave — The fabric of intersecting timelines…\\nEchostone — A memory artifact that replays…",rows:6})]}),e.jsxs("div",{className:"bsp-field",children:[e.jsx("label",{className:"bsp-field-label",children:"Appendix"}),e.jsx("textarea",{className:"bsp-textarea",value:w.appendix,onChange:o=>z(l=>({...l,appendix:o.target.value})),placeholder:"Supplementary material, tables, maps, or charts…",rows:5})]}),e.jsxs("div",{className:"bsp-field",children:[e.jsx("label",{className:"bsp-field-label",children:"Bibliography / References"}),e.jsx("textarea",{className:"bsp-textarea",value:w.bibliography,onChange:o=>z(l=>({...l,bibliography:o.target.value})),placeholder:"Sources, references, or further reading…",rows:4})]}),e.jsxs("div",{className:"bsp-field",children:[e.jsx("label",{className:"bsp-field-label",children:"Author's Notes / Endnotes"}),e.jsx("textarea",{className:"bsp-textarea",value:w.notes,onChange:o=>z(l=>({...l,notes:o.target.value})),placeholder:"Behind-the-scenes thoughts, research notes, or endnotes…",rows:4})]}),e.jsx("div",{className:"bsp-save-row",children:e.jsx("button",{className:"bsp-save-btn",onClick:Z,disabled:W,children:W?"Saving…":"Save Back Matter"})})]}),e.jsx("style",{children:`
/* ═══ BookStructurePanel Styles ═══ */
.bsp-panel {
  display: flex;
  flex-direction: column;
  height: 100%;
  overflow: hidden;
  background: #FAF7F0;
}
.bsp-loading {
  display: flex;
  align-items: center;
  justify-content: center;
  height: 300px;
  font-family: 'Lora', Georgia, serif;
  font-style: italic;
  color: rgba(28, 24, 20, 0.4);
  font-size: 14px;
}

/* ── Nav ── */
.bsp-nav {
  display: flex;
  gap: 0;
  border-bottom: 1px solid rgba(28, 24, 20, 0.08);
  padding: 0 12px;
  background: #FAF7F0;
  flex-shrink: 0;
  overflow-x: auto;
  -webkit-overflow-scrolling: touch;
}
.bsp-nav-btn {
  display: flex;
  align-items: center;
  gap: 6px;
  background: none;
  border: none;
  border-bottom: 2px solid transparent;
  padding: 10px 14px 8px;
  font-family: 'DM Mono', monospace;
  font-size: 10px;
  letter-spacing: 0.08em;
  color: rgba(28, 24, 20, 0.4);
  cursor: pointer;
  transition: all 0.12s ease;
  white-space: nowrap;
}
.bsp-nav-btn:hover { color: rgba(28, 24, 20, 0.7); }
.bsp-nav-btn.active {
  color: #1C1814;
  border-bottom-color: #B8962E;
}
.bsp-nav-icon { font-size: 12px; }

/* ── Section ── */
.bsp-section {
  flex: 1;
  overflow-y: auto;
  padding: 20px 24px 40px;
  max-width: 720px;
  margin: 0 auto;
  width: 100%;
}
.bsp-section-header { margin-bottom: 24px; }
.bsp-section-title {
  font-family: 'Lora', Georgia, serif;
  font-size: 18px;
  font-weight: 500;
  color: #1C1814;
  margin: 0 0 6px;
}
.bsp-section-desc {
  font-family: 'Spectral', Georgia, serif;
  font-size: 13px;
  color: rgba(28, 24, 20, 0.5);
  margin: 0;
  line-height: 1.6;
}

/* ── Overview ── */
.bsp-overview-header { text-align: center; padding: 16px 0 24px; }
.bsp-title {
  font-family: 'Lora', Georgia, serif;
  font-size: 24px;
  font-weight: 500;
  font-style: italic;
  color: #1C1814;
  margin: 0 0 4px;
}
.bsp-subtitle {
  font-family: 'Spectral', Georgia, serif;
  font-size: 14px;
  color: rgba(28, 24, 20, 0.5);
  margin: 0;
}

/* Stats grid */
.bsp-stats-grid {
  display: grid;
  grid-template-columns: repeat(4, 1fr);
  gap: 12px;
  margin-bottom: 28px;
}
.bsp-stat {
  display: flex;
  flex-direction: column;
  align-items: center;
  padding: 14px 8px;
  border: 1px solid rgba(28, 24, 20, 0.06);
  border-radius: 4px;
  background: #FFFDF9;
}
.bsp-stat-num {
  font-family: 'DM Mono', monospace;
  font-size: 20px;
  color: #1C1814;
  font-weight: 500;
}
.bsp-stat-label {
  font-family: 'DM Mono', monospace;
  font-size: 8px;
  letter-spacing: 0.15em;
  color: rgba(28, 24, 20, 0.35);
  text-transform: uppercase;
  margin-top: 4px;
}

/* Outline */
.bsp-outline { margin-top: 8px; }
.bsp-outline-title {
  font-family: 'DM Mono', monospace;
  font-size: 9px;
  letter-spacing: 0.15em;
  color: rgba(28, 24, 20, 0.3);
  text-transform: uppercase;
  margin: 0 0 16px;
  padding-bottom: 8px;
  border-bottom: 1px solid rgba(28, 24, 20, 0.06);
}
.bsp-outline-group { margin-bottom: 16px; }
.bsp-outline-group-label {
  font-family: 'DM Mono', monospace;
  font-size: 8px;
  letter-spacing: 0.12em;
  color: rgba(28, 24, 20, 0.35);
  text-transform: uppercase;
  display: block;
  margin-bottom: 8px;
}
.bsp-outline-part-label {
  font-family: 'Lora', Georgia, serif;
  font-size: 13px;
  font-weight: 600;
  color: #B8962E;
  display: block;
  margin-bottom: 8px;
  padding: 6px 0;
  border-bottom: 1px solid rgba(184, 150, 46, 0.15);
}
.bsp-outline-part-unassigned { color: rgba(28, 24, 20, 0.3); }
.bsp-outline-pills { display: flex; flex-wrap: wrap; gap: 6px; }
.bsp-pill {
  font-family: 'DM Mono', monospace;
  font-size: 9px;
  letter-spacing: 0.05em;
  padding: 4px 10px;
  border-radius: 3px;
  border: 1px solid rgba(28, 24, 20, 0.08);
}
.bsp-pill.filled { background: rgba(184, 150, 46, 0.08); color: #8A7434; border-color: rgba(184, 150, 46, 0.2); }
.bsp-pill.empty { color: rgba(28, 24, 20, 0.3); font-style: italic; }

.bsp-outline-chapter {
  display: flex;
  align-items: center;
  gap: 8px;
  padding: 6px 0 6px 8px;
  border-bottom: 1px solid rgba(28, 24, 20, 0.04);
}
.bsp-outline-ch-icon { font-size: 11px; color: rgba(28, 24, 20, 0.3); width: 16px; text-align: center; }
.bsp-outline-ch-type {
  font-family: 'DM Mono', monospace;
  font-size: 8px;
  letter-spacing: 0.08em;
  color: rgba(28, 24, 20, 0.35);
  text-transform: uppercase;
  min-width: 60px;
}
.bsp-outline-ch-title {
  font-family: 'Spectral', Georgia, serif;
  font-size: 14px;
  color: #1C1814;
  flex: 1;
  min-width: 0;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}
.bsp-outline-ch-meta {
  font-family: 'DM Mono', monospace;
  font-size: 9px;
  color: rgba(28, 24, 20, 0.3);
  white-space: nowrap;
}

/* ── Fields (Front/Back matter) ── */
.bsp-field { margin-bottom: 20px; }
.bsp-field-label {
  display: block;
  font-family: 'DM Mono', monospace;
  font-size: 10px;
  letter-spacing: 0.1em;
  color: rgba(28, 24, 20, 0.5);
  text-transform: uppercase;
  margin-bottom: 6px;
}
.bsp-field-hint {
  font-family: 'Spectral', Georgia, serif;
  font-size: 12px;
  color: rgba(28, 24, 20, 0.4);
  font-style: italic;
  margin: 0 0 8px;
  line-height: 1.5;
}
.bsp-input,
.bsp-textarea {
  width: 100%;
  border: 1px solid rgba(28, 24, 20, 0.1);
  border-radius: 3px;
  padding: 10px 14px;
  font-family: 'Spectral', Georgia, serif;
  font-size: 14px;
  line-height: 1.7;
  color: #1C1814;
  background: #FFFDF9;
  outline: none;
  transition: border-color 0.12s ease;
  box-sizing: border-box;
}
.bsp-input:focus,
.bsp-textarea:focus {
  border-color: rgba(184, 150, 46, 0.4);
}
.bsp-input--secondary {
  margin-top: 6px;
  font-style: italic;
  color: rgba(28, 24, 20, 0.6);
  font-size: 13px;
}
.bsp-textarea { resize: vertical; min-height: 60px; }
.bsp-textarea--short { min-height: 40px; }

.bsp-save-row {
  display: flex;
  justify-content: flex-end;
  margin-top: 24px;
  padding-top: 16px;
  border-top: 1px solid rgba(28, 24, 20, 0.06);
}
.bsp-save-btn {
  background: #1C1814;
  color: #FAF7F0;
  border: none;
  border-radius: 3px;
  padding: 10px 28px;
  font-family: 'DM Mono', monospace;
  font-size: 10px;
  letter-spacing: 0.1em;
  cursor: pointer;
  transition: opacity 0.12s ease;
}
.bsp-save-btn:hover { opacity: 0.85; }
.bsp-save-btn:disabled { opacity: 0.5; cursor: not-allowed; }

/* ── Parts & Chapters ── */
.bsp-part-header {
  display: flex;
  align-items: center;
  gap: 12px;
  padding: 14px 0 8px;
  border-top: 2px solid rgba(184, 150, 46, 0.2);
  margin-top: 16px;
}
.bsp-part-header:first-child { margin-top: 0; }
.bsp-part-numeral {
  font-family: 'Lora', Georgia, serif;
  font-size: 14px;
  font-weight: 600;
  color: #B8962E;
  white-space: nowrap;
}
.bsp-part-title-input {
  flex: 1;
  background: none;
  border: none;
  border-bottom: 1px solid rgba(28, 24, 20, 0.08);
  padding: 4px 0;
  font-family: 'Spectral', Georgia, serif;
  font-size: 14px;
  color: #1C1814;
  outline: none;
}
.bsp-part-title-input:focus { border-bottom-color: rgba(184, 150, 46, 0.4); }

.bsp-chapter-row {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 10px 0;
  border-bottom: 1px solid rgba(28, 24, 20, 0.04);
  gap: 12px;
  flex-wrap: wrap;
}
.bsp-ch-left {
  display: flex;
  align-items: center;
  gap: 10px;
  min-width: 0;
  flex: 1;
}
.bsp-ch-num {
  font-family: 'DM Mono', monospace;
  font-size: 11px;
  color: rgba(28, 24, 20, 0.3);
  width: 24px;
  text-align: right;
  flex-shrink: 0;
}
.bsp-ch-title {
  font-family: 'Spectral', Georgia, serif;
  font-size: 14px;
  color: #1C1814;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}
.bsp-ch-controls {
  display: flex;
  align-items: center;
  gap: 8px;
  flex-shrink: 0;
}
.bsp-select {
  background: #FFFDF9;
  border: 1px solid rgba(28, 24, 20, 0.1);
  border-radius: 3px;
  padding: 5px 8px;
  font-family: 'DM Mono', monospace;
  font-size: 9px;
  color: #1C1814;
  cursor: pointer;
  outline: none;
}
.bsp-select:focus { border-color: rgba(184, 150, 46, 0.4); }
.bsp-select--part { min-width: 85px; }
.bsp-scene-badge {
  font-family: 'DM Mono', monospace;
  font-size: 8px;
  letter-spacing: 0.08em;
  color: rgba(28, 24, 20, 0.35);
  background: rgba(28, 24, 20, 0.04);
  padding: 3px 8px;
  border-radius: 10px;
  white-space: nowrap;
}

.bsp-empty {
  text-align: center;
  padding: 32px 16px;
  font-family: 'Lora', Georgia, serif;
  font-style: italic;
  color: rgba(28, 24, 20, 0.35);
  font-size: 14px;
}

/* ── Mobile responsive ── */
@media (max-width: 480px) {
  .bsp-section { padding: 16px 12px 32px; }
  .bsp-stats-grid { grid-template-columns: repeat(2, 1fr); }
  .bsp-chapter-row { flex-direction: column; align-items: flex-start; gap: 8px; }
  .bsp-ch-controls { width: 100%; }
  .bsp-select { flex: 1; }
  .bsp-nav-btn { padding: 8px 10px 6px; font-size: 9px; }
  .bsp-outline-chapter { padding: 6px 0; }
}
@media (min-width: 481px) and (max-width: 768px) {
  .bsp-section { padding: 16px 16px 32px; }
  .bsp-stats-grid { grid-template-columns: repeat(4, 1fr); gap: 8px; }
}
      `})]})}const E="/api/v1",us=[{type:"h2",label:"Chapter Title",icon:"H2"},{type:"h3",label:"Section",icon:"H3"},{type:"h4",label:"Subsection",icon:"H4"},{type:"body",label:"Body",icon:"¶"},{type:"quote",label:"Quote",icon:"“"},{type:"reflection",label:"Reflection",icon:"?"},{type:"divider",label:"Divider",icon:"─"}],ca=["h1","h2","h3","h4"];function Bt(){return crypto.randomUUID?crypto.randomUUID():`${Date.now()}-${Math.random().toString(36).slice(2,9)}`}const da=[{id:"write",label:"Write"},{id:"review",label:"Review"},{id:"structure",label:"Structure"},{id:"scenes",label:"Scenes"},{id:"memory",label:"Memory"},{id:"lala",label:"Lala"},{id:"export",label:"Export"}];function ga({hideTopBar:A=!1}){const{bookId:b,chapterId:c}=Vs(),H=Qs(),[d,J]=a.useState(null),[D,K]=a.useState(null),[f,$]=a.useState([]),[W,pe]=a.useState(!0),[j,P]=a.useState(()=>{const t=localStorage.getItem("wm-show-toc");return t!==null?t==="true":!0}),[w,z]=a.useState(()=>{const t=localStorage.getItem("wm-show-context");return t!==null?t==="true":!0}),[F,q]=a.useState(null),[Z,ae]=a.useState(null),[g,I]=a.useState(null),[Y,ee]=a.useState(""),[ne,re]=a.useState(!1),[o,l]=a.useState(""),[N,R]=a.useState(null),[te,O]=a.useState([]),[k,ue]=a.useState(null),[xe,r]=a.useState(""),[y,u]=a.useState(null),[C,v]=a.useState(!1),G=a.useRef(null),[ke,Lt]=a.useState({}),it=a.useRef({}),[Se,V]=a.useState(null),[L,ie]=a.useState(""),[Fe,zt]=a.useState(null),[Ye,Ft]=a.useState("plan"),[m,se]=a.useState(""),[ge,oe]=a.useState(0),[ot,me]=a.useState(!0),[lt,Ve]=a.useState(!1),[ve,Qe]=a.useState(!1),[It,ct]=a.useState(""),[S,le]=a.useState(!1),[Rt,dt]=a.useState(null),[fe,xs]=a.useState(!1),[Ee,pt]=a.useState(""),[gs,mt]=a.useState(!1),[je,Ae]=a.useState(null),[Ot,Ie]=a.useState(null),[Re,ht]=a.useState(null),[Ce,fs]=a.useState("paragraph"),[Oe,Me]=a.useState(""),[bs,ys]=a.useState([]),[Q,Gt]=a.useState(null),[pa,Wt]=a.useState(!1),[ws,ut]=a.useState(!1),[Ut,De]=a.useState(null),[Ht,vs]=a.useState([]),[$e,js]=a.useState(!1),xt=a.useRef({toc:!0,ctx:!0}),[Jt]=a.useState(()=>Date.now()),[Xe,Ns]=a.useState(0),[Pe,ks]=a.useState(()=>{const t=localStorage.getItem("wm-word-goal");return t?parseInt(t,10):0}),[gt,ft]=a.useState(!1),Ze=a.useRef(0),[U,be]=a.useState(null),[Kt,_e]=a.useState(null),[Be,Ss]=a.useState([]),[et,tt]=a.useState(!1),[qt,bt]=a.useState(!1),[he,yt]=a.useState("write"),[Le,wt]=a.useState([]),[vt,jt]=a.useState(null),[Ge,Nt]=a.useState(""),[Cs,_s]=a.useState(null),[Ts,Yt]=a.useState(!1),[Vt,Es]=a.useState([]),Qt=m.split(/\n\n+/).filter(t=>t.trim().length>20).length,As=Qt>=5&&he==="write",Xt=a.useRef(null),Zt=a.useRef(null),Te=a.useRef(null),kt=a.useRef(null),st=a.useRef(null),We=a.useRef(""),Ue=a.useRef(""),es=a.useCallback(async()=>{try{const s=await(await fetch(`${E}/storyteller/books/${b}`)).json(),n=s?.book||s;K(n);const i=(n.chapters||[]).sort((p,h)=>(p.sort_order??p.chapter_number??0)-(h.sort_order??h.chapter_number??0));return $(i),i}catch{return null}},[b]);a.useEffect(()=>{async function t(){try{const n=await(await fetch(`${E}/storyteller/books/${b}`)).json(),i=n?.book||n;K(i);const p=(i.chapters||[]).sort((_,x)=>(_.sort_order??_.chapter_number??0)-(x.sort_order??x.chapter_number??0));$(p);const h=p.find(_=>_.id===c);if(J(h||{id:c,title:"Chapter"}),h?.draft_prose&&(se(h.draft_prose),oe(h.draft_prose.split(/\s+/).filter(Boolean).length)),h?.sections?.length>0){const _={};h.sections.forEach(T=>{T.id&&(_[T.id]=T.prose||"")}),Lt(_),it.current=_;const x=h.sections.filter(T=>["h2","h3","h4"].includes(T.type)&&T.prose?.trim()).map(T=>T.prose).join(`

`);x.trim()&&(se(x),oe(x.split(/\s+/).filter(Boolean).length))}const B=p.findIndex(_=>_.id===c);if(B>0){const _=p[B-1],x=_.draft_prose?.trim();if(x){const T=x.split(/\n\n+/).filter(Boolean),Ne=T[T.length-1];zt({title:_.title,excerpt:Ne.length>200?Ne.slice(0,200)+"…":Ne,wordCount:x.split(/\s+/).filter(Boolean).length})}else zt({title:_.title,excerpt:null,wordCount:0})}}catch{J({id:c,title:"Chapter"})}finally{pe(!1)}}t()},[b,c]),a.useEffect(()=>{async function t(){Wt(!0);try{const n=await(await fetch(`${E}/character-registry/registries`)).json(),i=n.registries||n||[],p=[];for(const h of i){const _=await(await fetch(`${E}/character-registry/registries/${h.id}`)).json();(_.characters||_.registry?.characters||[]).forEach(T=>p.push({...T,_registryTitle:h.title||h.book_tag}))}ys(p.filter(h=>h.status!=="declined"))}catch(s){console.error("Failed to load characters:",s)}Wt(!1)}t()},[]),a.useEffect(()=>{const t=setInterval(()=>{Ns(Math.floor((Date.now()-Jt)/1e3))},1e3);return()=>clearInterval(t)},[Jt]),a.useEffect(()=>{Ze.current===0&&ge>0&&(Ze.current=ge)},[ge]),a.useEffect(()=>{fetch(`${E}/character-registry/registries`).then(t=>t.json()).then(t=>{const s=t?.registries||t||[],n=Array.isArray(s)?s.flatMap(i=>i.characters||[]):[];Es(n)}).catch(()=>{})},[]),a.useEffect(()=>{he!=="review"||!c||Tt()},[he,c]),a.useEffect(()=>{const t=document.createElement("style");return t.textContent=Xs,document.head.appendChild(t),()=>document.head.removeChild(t)},[]);const ce=a.useCallback(t=>{m.trim()&&Ss(s=>[...s.slice(-19),{prose:m,label:t,timestamp:Date.now(),wordCount:ge}])},[m,ge]),St=a.useCallback(async t=>{if(U===null||S)return;const s=m.split(/\n\n+/),n=s[U];if(n){if(t==="delete"){ce("Before delete paragraph");const p=s.filter((h,B)=>B!==U).join(`

`);se(p),oe(p.split(/\s+/).filter(Boolean).length),me(!1),be(null),_e(null);return}ce(`Before ${t} paragraph`),le(!0),_e(t);try{const p=await(await fetch(`${E}/memories/story-edit`,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({current_prose:n,edit_note:t==="rewrite"?"Rewrite this paragraph with better prose, keeping the same meaning and tone.":"Expand this paragraph with more sensory detail, interiority, and emotional depth. Keep the same voice.",pnos_act:d?.pnos_act||"act_1",chapter_title:d?.title,character_id:Q?.id||null})})).json();if(p.prose){const h=[...s];h[U]=p.prose.trim();const B=h.join(`

`);se(B),oe(B.split(/\s+/).filter(Boolean).length),me(!1)}}catch(i){console.error("paragraph action error:",i)}le(!1),be(null),_e(null)}},[m,U,S,d,Q,ce]);a.useEffect(()=>{if(st.current&&clearTimeout(st.current),!(!m||ot))return st.current=setTimeout(()=>ze(m),8e3),()=>clearTimeout(st.current)},[m,ot]);const ze=a.useCallback(async t=>{if(t){Ve(!0);try{await fetch(`${E}/storyteller/chapters/${c}/save-draft`,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({draft_prose:t})});const s=it.current;Object.keys(s).length>0&&J(n=>{if(n?.sections?.length>0){const i=n.sections.map(p=>({...p,prose:s[p.id]??p.prose??""}));return fetch(`${E}/storyteller/chapters/${c}`,{method:"PUT",headers:{"Content-Type":"application/json"},body:JSON.stringify({sections:i})}).catch(()=>{}),{...n,sections:i}}return n}),me(!0)}catch{}Ve(!1)}},[c]),ts=a.useCallback(()=>{if(!("webkitSpeechRecognition"in window)&&!("SpeechRecognition"in window)){dt("Voice not supported on this browser. Try Chrome.");return}const t=window.SpeechRecognition||window.webkitSpeechRecognition,s=new t;s.continuous=!0,s.interimResults=!0,s.lang="en-US",We.current="",s.onresult=n=>{let i="",p=We.current;for(let h=n.resultIndex;h<n.results.length;h++)n.results[h].isFinal?p+=n.results[h][0].transcript+" ":i=n.results[h][0].transcript;We.current=p,ct(p+i)},s.onerror=n=>{n.error!=="no-speech"&&dt("Mic error — tap to retry"),Qe(!1)},s.onend=()=>Qe(!1),Xt.current=s,s.start(),Qe(!0),dt(null),ct(""),We.current=""},[]),ss=a.useCallback(async t=>{ce("Before voice-to-story"),le(!0),Me("");try{const n=(await fetch(`${E}/memories/voice-to-story`,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({spoken:t,existing_prose:m,chapter_title:d?.title,chapter_brief:d?.scene_goal||d?.chapter_notes,pnos_act:d?.pnos_act||"act_1",book_character:D?.character||"JustAWoman",session_log:Ht.slice(-4),character_id:Q?.id||null,gen_length:Ce,stream:!0})})).body.getReader(),i=new TextDecoder;let p="",h=null;for(;;){const{done:B,value:_}=await n.read();if(B)break;const T=i.decode(_,{stream:!0}).split(`
`);for(const Ne of T)if(Ne.startsWith("data: "))try{const we=JSON.parse(Ne.slice(6));we.type==="text"?(p+=we.text,Me(p),Te.current&&(Te.current.scrollTop=Te.current.scrollHeight)):we.type==="done"?h=we.hint||null:we.type==="error"&&console.error("voice-to-story stream error:",we.error)}catch{}}if(p){const B=m?m.trimEnd()+`

`+p:p;se(B),oe(B.split(/\s+/).filter(Boolean).length),me(!1),vs(_=>[..._,{spoken:t,generated:p}]),h&&(De(h),setTimeout(()=>De(null),6e3))}}catch(s){console.error("voice-to-story error:",s)}Me(""),le(!1)},[m,d,D,Ht,Ce,Q,ce]),Ms=a.useCallback(async()=>{if(ve){Xt.current?.stop(),Qe(!1);const t=We.current.trim();if(!t)return;ct(""),await ss(t)}else ts()},[ve,ts,ss]),Ds=a.useCallback(()=>{const t=window.SpeechRecognition||window.webkitSpeechRecognition;if(!t)return;const s=new t;s.continuous=!0,s.interimResults=!0,s.lang="en-US",Ue.current="",s.onresult=n=>{let i="",p=Ue.current;for(let h=n.resultIndex;h<n.results.length;h++)n.results[h].isFinal?p+=n.results[h][0].transcript+" ":i=n.results[h][0].transcript;Ue.current=p,pt(p+i)},s.onend=()=>mt(!1),Zt.current=s,s.start(),mt(!0),Ue.current=""},[]),$s=a.useCallback(()=>{Zt.current?.stop(),mt(!1)},[]),Ps=a.useCallback(async()=>{if(Ee.trim()){ce("Before edit"),le(!0);try{const s=await(await fetch(`${E}/memories/story-edit`,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({current_prose:m,edit_note:Ee.trim(),pnos_act:d?.pnos_act||"act_1",chapter_title:d?.title})})).json();s.prose&&(se(s.prose),oe(s.prose.split(/\s+/).filter(Boolean).length),me(!1),pt(""),Ue.current="")}catch(t){console.error("story-edit error:",t)}le(!1)}},[m,Ee,d,ce]),Ct=a.useCallback(async()=>{if(!(!m.trim()||S)){ce("Before continue"),Ae("continue"),le(!0),ht(m),Ie(null),Me("");try{const s=(await fetch(`${E}/memories/story-continue`,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({current_prose:m,chapter_title:d?.title,chapter_brief:d?.scene_goal||d?.chapter_notes,pnos_act:d?.pnos_act||"act_1",book_character:D?.character||"JustAWoman",character_id:Q?.id||null,gen_length:Ce,stream:!0})})).body.getReader(),n=new TextDecoder;let i="";for(;;){const{done:p,value:h}=await s.read();if(p)break;const _=n.decode(h,{stream:!0}).split(`
`);for(const x of _)if(x.startsWith("data: "))try{const T=JSON.parse(x.slice(6));T.type==="text"?(i+=T.text,Me(i),Te.current&&(Te.current.scrollTop=Te.current.scrollHeight)):T.type==="error"&&(De(T.error),setTimeout(()=>De(null),5e3))}catch{}}if(i){const p=m.trimEnd()+`

`+i;se(p),oe(p.split(/\s+/).filter(Boolean).length),me(!1)}}catch(t){console.error("story-continue error:",t)}Me(""),le(!1),Ae(null)}},[m,d,D,S,Ce,Q,ce]),_t=a.useCallback(async()=>{if(!(!m.trim()||S)){ce("Before deepen"),Ae("deepen"),le(!0),ht(m),Ie(null);try{const s=await(await fetch(`${E}/memories/story-deepen`,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({current_prose:m,pnos_act:d?.pnos_act||"act_1",chapter_title:d?.title,character_id:Q?.id||null})})).json();s.prose?(se(s.prose),oe(s.prose.split(/\s+/).filter(Boolean).length),me(!1)):s.error&&(De(s.error),setTimeout(()=>De(null),5e3))}catch(t){console.error("story-deepen error:",t)}le(!1),Ae(null)}},[m,d,S,ce]),Bs=a.useCallback(async()=>{if(!S){Ae("nudge"),le(!0),Ie(null);try{const s=await(await fetch(`${E}/memories/story-nudge`,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({current_prose:m,chapter_title:d?.title,chapter_brief:d?.scene_goal||d?.chapter_notes,pnos_act:d?.pnos_act||"act_1",character_id:Q?.id||null})})).json();s.nudge&&Ie(s.nudge)}catch(t){console.error("story-nudge error:",t)}le(!1),Ae(null)}},[m,d,S]),Ls=a.useCallback(()=>{Re!==null&&(se(Re),oe(Re.split(/\s+/).filter(Boolean).length),me(!1),ht(null))},[Re]),Tt=a.useCallback(async()=>{Yt(!0);try{const s=await(await fetch(`${E}/storyteller/books/${b}`)).json(),i=((s?.book||s).chapters||[]).find(p=>p.id===c);wt(i?.lines||[])}catch{}Yt(!1)},[b,c]),as=(t,s)=>{wt(n=>n.map(i=>i.id===t?{...i,...s}:i))},ns=async t=>{try{await fetch(`${E}/storyteller/lines/${t}`,{method:"PUT",headers:{"Content-Type":"application/json"},body:JSON.stringify({status:"approved"})}),as(t,{status:"approved"});const s=Le.find(n=>n.id===t);s&&_s({...s,status:"approved"})}catch{}},zs=async t=>{try{await fetch(`${E}/storyteller/lines/${t}`,{method:"DELETE"}),wt(s=>s.filter(n=>n.id!==t))}catch{}},Fs=t=>{jt(t.id),Nt(t.text||t.content||"")},Is=async()=>{try{await fetch(`${E}/storyteller/lines/${vt}`,{method:"PUT",headers:{"Content-Type":"application/json"},body:JSON.stringify({text:Ge,content:Ge,status:"edited"})}),as(vt,{text:Ge,content:Ge,status:"edited"}),jt(null),Nt("")}catch{}},Rs=async()=>{const t=Le.filter(s=>s.status==="pending");for(const s of t)await ns(s.id)},Os=a.useCallback(async()=>{Ve(!0);try{await fetch(`${E}/storyteller/chapters/${c}/save-draft`,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({draft_prose:m})});const s=m.split(/\n\n+/).map(n=>n.trim()).filter(Boolean).map((n,i)=>`LINE ${i+1}
${n}`).join(`

`);await fetch(`${E}/storyteller/chapters/${c}/import`,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({raw_text:s,mode:"replace"})}),Q?.id&&m&&fetch(`${E}/storyteller/chapters/${c}/emotional-impact`,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({prose:m,character_id:Q.id})}).catch(()=>{}),yt("review"),await Tt()}catch(t){console.error("sendToReview error:",t)}Ve(!1)},[m,c,b,Q,Tt]),Gs=t=>{const s=t.target.value;se(s),oe(s.split(/\s+/).filter(Boolean).length),me(!1),at(t.target)},at=a.useCallback(t=>{!t||window.innerWidth>767||(t.style.height="auto",t.style.height=t.scrollHeight+"px")},[]);a.useEffect(()=>{kt.current&&window.innerWidth<=767&&at(kt.current)},[m,Oe,at]);const Ws=d?.sections?.length>0&&d.sections.some(t=>["h2","h3","h4"].includes(t.type)),Us=a.useCallback((t,s)=>{Lt(n=>{const i={...n,[t]:s};it.current=i;const p=(d?.sections||[]).filter(h=>["h2","h3","h4"].includes(h.type)).map(h=>i[h.id]||"").filter(Boolean).join(`

`);return se(p),oe(p.split(/\s+/).filter(Boolean).length),me(!1),i})},[d?.sections]),He=a.useCallback(()=>{js(t=>(t?(P(xt.current.toc),z(xt.current.ctx)):(xt.current={toc:j,ctx:w},P(!1),z(!1)),!t))},[j,w]);a.useEffect(()=>{const t=s=>{if((s.ctrlKey||s.metaKey)&&s.key==="Enter"&&(s.preventDefault(),!fe&&m.trim()&&!S&&Ct()),(s.ctrlKey||s.metaKey)&&s.key==="d"&&(s.preventDefault(),!fe&&m.trim()&&!S&&_t()),(s.ctrlKey||s.metaKey)&&s.key==="s"&&(s.preventDefault(),m&&ze(m)),s.key==="Escape"){if(fe){xs(!1);return}if(et){tt(!1);return}if(gt){ft(!1);return}if($e){He();return}if(U!==null){be(null),_e(null);return}if(g){I(null);return}if(ne){re(!1);return}if(Se){V(null);return}}s.key==="F11"&&(s.preventDefault(),He()),(s.ctrlKey||s.metaKey)&&s.key==="["&&(s.preventDefault(),nt(-1)),(s.ctrlKey||s.metaKey)&&s.key==="]"&&(s.preventDefault(),nt(1)),(s.ctrlKey||s.metaKey)&&s.key==="b"&&(s.preventDefault(),P(n=>!n))};return window.addEventListener("keydown",t),()=>window.removeEventListener("keydown",t)},[fe,m,S,$e,et,gt,U,Ct,_t,ze,He]),a.useEffect(()=>{localStorage.setItem("wm-show-toc",JSON.stringify(j))},[j]),a.useEffect(()=>{localStorage.setItem("wm-show-context",JSON.stringify(w))},[w]);const Et=a.useCallback(async t=>{t!==c&&(m&&await ze(m),H(`/chapter/${b}/${t}`))},[c,b,m,ze,H]),nt=a.useCallback(t=>{const s=f.findIndex(i=>i.id===c);if(s<0)return;const n=f[s+t];n&&Et(n.id)},[f,c,Et]),Hs=a.useCallback(async()=>{if(F===null||Z===null||F===Z){q(null),ae(null);return}const t=[...f],[s]=t.splice(F,1);t.splice(Z,0,s),$(t),q(null),ae(null);try{await Promise.all(t.map((n,i)=>fetch(`${E}/storyteller/chapters/${n.id}`,{method:"PUT",headers:{"Content-Type":"application/json"},body:JSON.stringify({sort_order:i+1})})))}catch(n){console.error("reorder error",n)}},[f,F,Z]),rs=a.useCallback(async()=>{if(!g||!Y.trim()){I(null);return}$(t=>t.map(s=>s.id===g?{...s,title:Y.trim()}:s)),g===c&&J(t=>({...t,title:Y.trim()})),I(null);try{await fetch(`${E}/storyteller/chapters/${g}`,{method:"PUT",headers:{"Content-Type":"application/json"},body:JSON.stringify({title:Y.trim()})})}catch(t){console.error("rename error",t)}},[g,Y,c]),Js=a.useCallback(t=>{if(N===t){R(null),O([]);return}R(t);const s=f.find(i=>i.id===t),n=s?.sections&&Array.isArray(s.sections)?s.sections.map(i=>({...i,id:i.id||Bt()})):[];O(n)},[N,f]),is=a.useCallback(async t=>{if(N)try{await fetch(`${E}/storyteller/chapters/${N}`,{method:"PUT",headers:{"Content-Type":"application/json"},body:JSON.stringify({sections:t})}),$(s=>s.map(n=>n.id===N?{...n,sections:t}:n)),N===c&&J(s=>({...s,sections:t}))}catch(s){console.error("save sections error",s)}},[N,c]);a.useEffect(()=>{if(!(!N||te.length===0))return clearTimeout(G.current),G.current=setTimeout(()=>is(te),1500),()=>clearTimeout(G.current)},[te,N,is]);const Ks=a.useCallback((t="body")=>{const s={id:Bt(),type:t,content:""};O(n=>[...n,s]),v(!1),setTimeout(()=>{ue(s.id),r("")},50)},[]),os=a.useCallback(()=>{k&&(O(t=>t.map(s=>s.id===k?{...s,content:xe}:s)),ue(null))},[k,xe]),qs=a.useCallback(t=>{O(s=>s.filter(n=>n.id!==t))},[]),ls=a.useCallback((t,s)=>{O(n=>{const i=n.findIndex(B=>B.id===t);if(i<0)return n;const p=i+s;if(p<0||p>=n.length)return n;const h=[...n];return[h[i],h[p]]=[h[p],h[i]],h})},[]),cs=a.useCallback(async()=>{const t=o.trim()||`Chapter ${f.length+1}`;re(!1),l("");try{const n=await(await fetch(`${E}/storyteller/books/${b}/chapters`,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({title:t,chapter_number:f.length+1,sort_order:f.length+1})})).json(),i=n.chapter||n;$(p=>[...p,i])}catch(s){console.error("add chapter error",s)}},[b,f.length,o]),de=a.useCallback(async(t,s)=>{J(n=>({...n,[t]:s})),$(n=>n.map(i=>i.id===c?{...i,[t]:s}:i)),V(null);try{await fetch(`${E}/storyteller/chapters/${c}`,{method:"PUT",headers:{"Content-Type":"application/json"},body:JSON.stringify({[t]:s})})}catch(n){console.error("save context field error",n)}},[c]),At=a.useMemo(()=>{const t=f.length,s=f.filter(i=>i.draft_prose?.trim()).length,n=f.reduce((i,p)=>i+(p.draft_prose?p.draft_prose.split(/\s+/).filter(Boolean).length:0),0);return{total:t,written:s,totalWords:n}},[f]);if(W)return e.jsx("div",{className:"wm-load-screen",children:e.jsx(Ys,{variant:"editor"})});const Je=Le.filter(t=>t.status==="approved"||t.status==="edited"),ye=Le.filter(t=>t.status==="pending");function ds(t,s){const n=vt===t.id,i=t.text||t.content||"";return e.jsxs("div",{className:`wm-review-line wm-review-line--${t.status}${n?" editing":""}`,children:[e.jsx("div",{className:"wm-review-line-content",children:n?e.jsxs(e.Fragment,{children:[e.jsx("textarea",{className:"wm-review-line-edit",value:Ge,onChange:p=>Nt(p.target.value),autoFocus:!0}),e.jsxs("div",{className:"wm-review-line-edit-actions",children:[e.jsx("button",{className:"wm-review-save",onClick:Is,children:"Save"}),e.jsx("button",{className:"wm-review-cancel",onClick:()=>jt(null),children:"Cancel"})]})]}):e.jsx("p",{className:`wm-review-line-text${s?" pending":""}`,children:i})}),!n&&e.jsxs("div",{className:"wm-review-line-actions",children:[s&&e.jsx("button",{className:"wm-line-approve",onClick:()=>ns(t.id),title:"Approve",children:"✓"}),e.jsx("button",{className:"wm-line-edit",onClick:()=>Fs(t),title:"Edit",children:"✎"}),s&&e.jsx("button",{className:"wm-line-reject",onClick:()=>zs(t.id),title:"Reject",children:"✕"})]})]},t.id)}return e.jsxs("div",{className:`wm-root${$e?" wm-focus-mode":""}`,children:[$e&&e.jsx("button",{className:"wm-focus-exit",onClick:He,title:"Exit focus mode (F11)",children:"✕"}),!A&&e.jsxs("header",{className:"wm-topbar",children:[e.jsx("button",{className:"wm-back-btn",onClick:()=>ut(!0),children:"←"}),e.jsx("button",{className:`wm-sidebar-toggle${j?" active":""}`,onClick:()=>P(t=>!t),title:"Table of Contents (Ctrl+B)",children:"☰"}),e.jsxs("div",{className:"wm-chapter-info",children:[e.jsx("div",{className:"wm-chapter-title",children:d?.title||"Untitled"}),e.jsx("div",{className:"wm-book-title",children:D?.title||D?.character||""})]}),e.jsxs("div",{className:"wm-session-timer",children:[e.jsx("span",{className:"wm-timer-icon",children:"⏱"}),e.jsxs("span",{className:"wm-timer-value",children:[Math.floor(Xe/3600)>0&&`${Math.floor(Xe/3600)}:`,String(Math.floor(Xe%3600/60)).padStart(2,"0"),":",String(Xe%60).padStart(2,"0")]})]}),e.jsxs("div",{className:"wm-top-right",children:[e.jsxs("div",{className:"wm-quick-char-wrap",children:[e.jsxs("button",{className:"wm-quick-char-btn",onClick:()=>bt(t=>!t),title:"Quick switch character",children:[e.jsx("span",{children:Q?.icon||"👤"}),e.jsx("span",{className:"wm-quick-char-caret",children:qt?"▲":"▼"})]}),qt&&e.jsxs("div",{className:"wm-quick-char-dropdown",children:[e.jsxs("div",{className:`wm-quick-char-option${Q?"":" selected"}`,onClick:()=>{Gt(null),bt(!1)},children:[e.jsx("span",{className:"wm-quick-char-option-icon",children:"—"}),e.jsx("span",{children:"No character voice"})]}),bs.map(t=>e.jsxs("div",{className:`wm-quick-char-option${Q?.id===t.id?" selected":""}`,onClick:()=>{Gt(t),bt(!1)},children:[e.jsx("span",{className:"wm-quick-char-option-icon",children:t.icon||"👤"}),e.jsx("span",{children:t.display_name||t.selected_name})]},t.id))]})]}),ge>0&&e.jsxs("div",{className:"wm-word-count",onClick:()=>ft(t=>!t),title:"Click to set word goal",children:[ge,"w",Pe>0&&e.jsxs("span",{className:"wm-goal-fraction",children:[" / ",Pe]})]}),e.jsx("div",{className:"wm-save-status",children:lt?"·· saving":ot?"":"· unsaved"}),e.jsxs("button",{className:`wm-history-btn${et?" active":""}`,onClick:()=>tt(t=>!t),title:`Snapshots (${Be.length})`,children:["📜",Be.length>0&&e.jsx("span",{className:"wm-history-badge",children:Be.length})]}),e.jsx("button",{className:`wm-focus-btn${$e?" active":""}`,onClick:He,title:"Focus mode (F11)",children:"⛶"}),e.jsx("button",{className:`wm-sidebar-toggle wm-ctx-toggle${w?" active":""}`,onClick:()=>z(t=>!t),title:"Chapter context panel",children:"ℹ"})]})]}),Pe>0&&e.jsxs("div",{className:"wm-goal-bar-wrap",children:[e.jsx("div",{className:"wm-goal-bar",children:e.jsx("div",{className:"wm-goal-fill",style:{width:`${Math.min(100,(ge-Ze.current)/Pe*100)}%`}})}),e.jsxs("span",{className:"wm-goal-label",children:[Math.max(0,ge-Ze.current)," / ",Pe," words this session"]})]}),gt&&e.jsxs("div",{className:"wm-goal-input-wrap",children:[e.jsx("label",{className:"wm-goal-input-label",children:"Session word goal:"}),e.jsx("input",{className:"wm-goal-input",type:"number",min:0,step:50,value:Pe,onChange:t=>{const s=parseInt(t.target.value)||0;ks(s),localStorage.setItem("wm-word-goal",s)},placeholder:"e.g. 500"}),e.jsx("button",{className:"wm-goal-input-close",onClick:()=>ft(!1),children:"✓"})]}),e.jsxs("div",{className:"wm-hub-layout",children:[j&&e.jsxs("aside",{className:"wm-toc-sidebar",children:[e.jsxs("div",{className:"wm-toc-header",children:[e.jsx("span",{className:"wm-toc-header-title",children:"Contents"}),e.jsxs("span",{className:"wm-toc-stats",children:[At.written,"/",At.total," · ",At.totalWords.toLocaleString(),"w"]})]}),e.jsx("div",{className:"wm-toc-list",children:f.map((t,s)=>{const n=t.id===c,i=t.draft_prose?t.draft_prose.split(/\s+/).filter(Boolean).length:0,p=N===t.id;t.sections&&Array.isArray(t.sections)&&t.sections.length>0;const h=t.chapter_type||"chapter",B=h==="prologue"?"◈":h==="epilogue"?"◇":h==="interlude"?"~":h==="afterword"?"∗":null,_=t.part_number&&(s===0||t.part_number!==f[s-1]?.part_number);return e.jsxs("div",{className:"wm-toc-chapter-group",children:[_&&e.jsx("div",{className:"wm-toc-part-divider",children:e.jsxs("span",{className:"wm-toc-part-label",children:["Part ",t.part_number,t.part_title?` — ${t.part_title}`:""]})}),e.jsxs("div",{className:`wm-toc-item${n?" current":""}${Z===s?" drag-over":""}`,draggable:!0,onDragStart:()=>q(s),onDragOver:x=>{x.preventDefault(),ae(s)},onDragEnd:Hs,onClick:()=>!g&&Et(t.id),children:[e.jsx("span",{className:"wm-toc-drag",children:"≡"}),e.jsx("button",{className:`wm-toc-expand${p?" expanded":""}`,onClick:x=>{x.stopPropagation(),Js(t.id)},title:p?"Collapse sections":"Show sections",children:"▸"}),e.jsx("span",{className:"wm-toc-num",children:t.chapter_number||s+1}),B&&e.jsx("span",{className:"wm-toc-type-badge",title:h,children:B}),g===t.id?e.jsx("input",{className:"wm-toc-edit-input",value:Y,onChange:x=>ee(x.target.value),onBlur:rs,onKeyDown:x=>{x.key==="Enter"&&rs(),x.key==="Escape"&&I(null)},autoFocus:!0,onClick:x=>x.stopPropagation()}):e.jsx("span",{className:"wm-toc-title",onDoubleClick:x=>{x.stopPropagation(),I(t.id),ee(t.title||"")},children:t.title||"Untitled"}),e.jsx("span",{className:"wm-toc-words",children:i>0?`${i}w`:"—"})]}),p&&e.jsxs("div",{className:"wm-toc-sections",children:[te.length===0&&e.jsx("div",{className:"wm-toc-sec-empty",children:"No sections yet"}),te.map(x=>{const T=us.find(X=>X.type===x.type)||{icon:"?",label:x.type},Ne=ca.includes(x.type),we=x.type==="divider";return e.jsxs("div",{className:`wm-toc-sec-item${Ne?" is-header":""}${we?" is-divider":""}`,children:[e.jsx("span",{className:"wm-toc-sec-icon",title:T.label,children:T.icon}),we?e.jsx("span",{className:"wm-toc-sec-divider-line"}):k===x.id?e.jsx("input",{className:"wm-toc-sec-edit",value:xe,onChange:X=>r(X.target.value),onBlur:os,onKeyDown:X=>{X.key==="Enter"&&os(),X.key==="Escape"&&ue(null)},placeholder:T.label+"…",autoFocus:!0}):e.jsx("span",{className:"wm-toc-sec-text",onClick:X=>{X.stopPropagation(),ue(x.id),r(x.content||"")},children:x.content||e.jsx("span",{className:"wm-toc-sec-placeholder",children:T.label})}),e.jsxs("div",{className:"wm-toc-sec-actions",children:[e.jsx("button",{onClick:X=>{X.stopPropagation(),ls(x.id,-1)},title:"Move up",children:"↑"}),e.jsx("button",{onClick:X=>{X.stopPropagation(),ls(x.id,1)},title:"Move down",children:"↓"}),e.jsx("button",{className:"wm-toc-sec-del",onClick:X=>{X.stopPropagation(),qs(x.id)},title:"Delete",children:"×"})]})]},x.id)}),C&&N===t.id?e.jsx("div",{className:"wm-toc-sec-type-menu",children:us.map(x=>e.jsxs("button",{className:"wm-toc-sec-type-opt",onClick:()=>Ks(x.type),children:[e.jsx("span",{className:"wm-toc-sec-type-icon",children:x.icon})," ",x.label]},x.type))}):e.jsx("button",{className:"wm-toc-sec-add",onClick:x=>{x.stopPropagation(),v(!0)},children:"+ Add Section"})]})]},t.id)})}),ne?e.jsx("div",{className:"wm-toc-add-row",children:e.jsx("input",{className:"wm-toc-add-input",value:o,onChange:t=>l(t.target.value),onBlur:cs,onKeyDown:t=>{t.key==="Enter"&&cs(),t.key==="Escape"&&re(!1)},placeholder:`Chapter ${f.length+1}`,autoFocus:!0})}):e.jsx("button",{className:"wm-toc-add-btn",onClick:()=>re(!0),children:"+ Add Chapter"}),e.jsxs("div",{className:"wm-toc-nav",children:[e.jsxs("button",{className:"wm-toc-nav-btn",disabled:f.findIndex(t=>t.id===c)<=0,onClick:()=>nt(-1),children:["←"," Prev"]}),e.jsxs("button",{className:"wm-toc-nav-btn",disabled:f.findIndex(t=>t.id===c)>=f.length-1,onClick:()=>nt(1),children:["Next ","→"]})]})]}),e.jsxs("div",{className:"wm-main-col",children:[e.jsx("div",{className:"wm-center-tabs",children:da.map(t=>e.jsxs("button",{className:`wm-center-tab${he===t.id?" wm-center-tab--active":""}`,onClick:()=>yt(t.id),children:[t.label,t.id==="review"&&ye.length>0&&e.jsx("span",{className:"wm-tab-badge",children:ye.length})]},t.id))}),he==="write"&&e.jsxs(e.Fragment,{children:[e.jsx("div",{className:"wm-content-row",children:e.jsxs("div",{className:"wm-prose-wrap",ref:Te,children:[e.jsxs("div",{className:"wm-manuscript-page",children:[e.jsx("div",{className:"wm-chapter-opening",children:e.jsx("h2",{className:"wm-chapter-heading",children:d?.title||"Untitled"})}),Ws?e.jsx("div",{className:"wm-canvas-sections",children:d.sections.map((t,s)=>{const n=["h2","h3","h4"].includes(t.type),i=t.type==="h2"&&t.content?.trim().toLowerCase()===(d?.title||"").trim().toLowerCase();return e.jsxs("div",{className:"wm-cs-block",children:[t.type==="divider"&&e.jsx("div",{className:"wm-cs-divider",children:e.jsx("span",{className:"wm-cs-divider-line"})}),t.type==="h2"&&!i&&e.jsx("h2",{className:"wm-cs-h2",children:t.content||"Untitled Section"}),t.type==="h3"&&e.jsx("h3",{className:"wm-cs-h3",children:t.content||"Untitled Section"}),t.type==="h4"&&e.jsx("h4",{className:"wm-cs-h4",children:t.content||"Untitled"}),t.type==="quote"&&e.jsx("blockquote",{className:"wm-cs-quote",children:t.content}),t.type==="reflection"&&e.jsx("div",{className:"wm-cs-reflection",children:t.content}),t.type==="body"&&e.jsx("p",{className:"wm-cs-body",children:t.content}),n&&e.jsx("textarea",{className:"wm-prose-area wm-section-prose",value:ke[t.id]||"",onChange:p=>{Us(t.id,p.target.value),at(p.target)},placeholder:`Write under ${t.content||"this section"}…`,spellCheck:!1,readOnly:S})]},t.id||s)})}):e.jsx("textarea",{className:"wm-prose-area",ref:kt,value:Oe?m?m.trimEnd()+`

`+Oe:Oe:m,onChange:Gs,placeholder:fe?"":"Begin writing…",spellCheck:!1,readOnly:S})]}),As&&e.jsxs("div",{className:"wm-ni-panel",children:[e.jsx("div",{className:"wm-ni-panel-header",children:e.jsx("span",{className:"wm-ni-label",children:"Narrative Intelligence"})}),e.jsx(ps,{chapter:d,lines:m.split(/\n\n+/).filter(t=>t.trim()).map((t,s)=>({id:`prose-${s}`,content:t,text:t,status:"approved"})),lineIndex:Qt-1,book:D,characters:Vt})]}),!fe&&m.trim()&&e.jsx("div",{className:`wm-para-float-hint${U!==null?" active":""}`,onClick:()=>{U!==null?(be(null),_e(null)):be(0)},title:"Paragraph actions",children:"¶"}),U!==null&&e.jsx("div",{className:"wm-para-overlay",children:m.split(/\n\n+/).map((t,s)=>e.jsxs("div",{className:`wm-para-block${s===U?" selected":""}`,onClick:()=>be(s===U?null:s),children:[e.jsx("p",{children:t}),s===U&&e.jsxs("div",{className:"wm-para-actions",children:[e.jsx("button",{onClick:n=>{n.stopPropagation(),St("rewrite")},disabled:S,children:S&&Kt==="rewrite"?"Rewriting…":"✎ Rewrite"}),e.jsx("button",{onClick:n=>{n.stopPropagation(),St("expand")},disabled:S,children:S&&Kt==="expand"?"Expanding…":"↔ Expand"}),e.jsx("button",{className:"wm-para-delete",onClick:n=>{n.stopPropagation(),St("delete")},disabled:S,children:"✗ Delete"}),e.jsx("button",{className:"wm-para-cancel",onClick:n=>{n.stopPropagation(),be(null),_e(null)},children:"✕"})]})]},s))}),S&&!Oe&&e.jsxs("div",{className:"wm-generating",children:[e.jsxs("div",{className:"wm-generating-dots",children:[e.jsx("span",{className:"wm-generating-dot"}),e.jsx("span",{className:"wm-generating-dot"}),e.jsx("span",{className:"wm-generating-dot"})]}),e.jsx("div",{className:"wm-generating-label",children:je==="continue"?"continuing your story":je==="deepen"?"deepening the moment":je==="nudge"?"thinking":"writing"})]}),Ut&&!S&&e.jsxs("div",{className:"wm-hint",children:[e.jsx("div",{className:"wm-hint-dot"}),e.jsx("div",{className:"wm-hint-text",children:Ut})]})]})}),ve&&It&&e.jsx("div",{className:"wm-transcript",children:e.jsx("div",{className:"wm-transcript-text",children:It})}),Ot&&!S&&e.jsxs("div",{className:"wm-nudge",children:[e.jsx("div",{className:"wm-nudge-icon",children:"💡"}),e.jsx("div",{className:"wm-nudge-text",children:Ot}),e.jsx("button",{className:"wm-nudge-close",onClick:()=>Ie(null),children:"×"})]}),!fe&&e.jsxs("div",{className:"wm-ai-toolbar",children:[e.jsxs("button",{className:`wm-ai-btn${je==="continue"?" active":""}`,onClick:Ct,disabled:S||!m.trim(),children:[e.jsx("span",{className:"wm-ai-icon",children:"✨"})," Continue"]}),e.jsxs("button",{className:`wm-ai-btn${je==="deepen"?" active":""}`,onClick:_t,disabled:S||!m.trim(),children:[e.jsx("span",{className:"wm-ai-icon",children:"🔍"})," Deepen"]}),e.jsxs("button",{className:`wm-ai-btn${je==="nudge"?" active":""}`,onClick:Bs,disabled:S,children:[e.jsx("span",{className:"wm-ai-icon",children:"💡"})," Nudge"]}),Re!==null&&!S&&e.jsxs("button",{className:"wm-ai-btn wm-undo-ai",onClick:Ls,children:[e.jsx("span",{className:"wm-ai-icon",children:"↩"})," Undo"]}),e.jsx("button",{className:`wm-len-toggle${Ce==="sentence"?" sentence":""}`,onClick:()=>fs(t=>t==="paragraph"?"sentence":"paragraph"),title:Ce==="sentence"?"Generating one sentence at a time":"Generating full paragraphs",children:Ce==="sentence"?"1 line":"¶ full"}),m.trim()&&e.jsxs("button",{className:`wm-ai-btn wm-para-mode-btn${U!==null?" active":""}`,onClick:()=>{U!==null?(be(null),_e(null)):be(0)},title:"Paragraph-level actions",children:[e.jsx("span",{className:"wm-ai-icon",children:"¶"})," Paragraphs"]})]}),et&&e.jsxs("div",{className:"wm-history-panel",children:[e.jsxs("div",{className:"wm-history-header",children:[e.jsx("span",{className:"wm-history-title",children:"Snapshots"}),e.jsx("button",{className:"wm-history-close",onClick:()=>tt(!1),children:"×"})]}),Be.length===0?e.jsx("div",{className:"wm-history-empty",children:"No snapshots yet. Snapshots are taken automatically before each AI action."}):e.jsx("div",{className:"wm-history-list",children:[...Be].reverse().map((t,s)=>{Be.length-1-s;const n=new Date(t.timestamp),i=`${n.getHours()}:${String(n.getMinutes()).padStart(2,"0")}`;return e.jsxs("div",{className:"wm-history-item",children:[e.jsxs("div",{className:"wm-history-item-header",children:[e.jsx("span",{className:"wm-history-item-label",children:t.label}),e.jsxs("span",{className:"wm-history-item-meta",children:[i," · ",t.wordCount,"w"]})]}),e.jsx("div",{className:"wm-history-item-preview",children:t.prose.length>200?t.prose.slice(0,200)+"…":t.prose}),e.jsx("button",{className:"wm-history-restore",onClick:()=>{ce("Before restore"),se(t.prose),oe(t.prose.split(/\s+/).filter(Boolean).length),me(!1),tt(!1)},children:"Restore this version"})]},s)})})]}),fe&&e.jsxs("div",{className:"wm-edit-panel",children:[e.jsx("div",{className:"wm-edit-label",children:"What needs to change?"}),e.jsxs("div",{className:"wm-edit-row",children:[e.jsx("textarea",{className:"wm-edit-input",value:Ee,onChange:t=>pt(t.target.value),placeholder:"That part is right but she wouldn't say it that way...",rows:3}),e.jsx("button",{className:"wm-edit-mic-btn",onPointerDown:Ds,onPointerUp:$s,children:gs?e.jsx("span",{className:"wm-mic-active-ring",children:"🎙"}):"🎙"})]}),e.jsx("button",{className:"wm-apply-btn",style:{opacity:Ee.trim()?1:.35},onClick:Ps,disabled:!Ee.trim()||S,children:S?"Rewriting…":"Apply →"})]}),Rt&&e.jsx("div",{className:"wm-mic-error",children:Rt}),!fe&&e.jsxs("div",{className:"wm-bottom-bar",children:[e.jsx("button",{className:`wm-mic-btn${ve?" listening":""}`,onClick:Ms,disabled:S,children:e.jsxs("svg",{width:"28",height:"28",viewBox:"0 0 28 28",fill:"none",children:[e.jsx("rect",{x:"9",y:"3",width:"10",height:"16",rx:"5",fill:ve?"#F5F0E8":"#1a1a1a"}),e.jsx("path",{d:"M5 14c0 5 3.5 9 9 9s9-4 9-9",stroke:ve?"#F5F0E8":"#1a1a1a",strokeWidth:"2",strokeLinecap:"round",fill:"none"}),e.jsx("line",{x1:"14",y1:"23",x2:"14",y2:"26",stroke:ve?"#F5F0E8":"#1a1a1a",strokeWidth:"2",strokeLinecap:"round"})]})}),e.jsx("div",{className:"wm-bottom-hint",children:ve?"Tap mic to stop & write":S?je==="continue"?"Continuing…":je==="deepen"?"Deepening…":"Writing your story…":m?"Tap mic to speak — or use AI tools above":"Tap mic to speak, or type and use AI tools"}),m.length>20&&e.jsx("button",{className:"wm-send-btn",onClick:Os,disabled:lt,children:lt?"…":"→ Review"})]})]}),he==="review"&&e.jsxs("div",{className:"wm-review-tab",children:[e.jsxs("div",{className:"wm-review-header",children:[e.jsxs("div",{className:"wm-review-stats",children:[e.jsxs("span",{className:"wm-review-stat approved",children:[Je.length," approved"]}),ye.length>0&&e.jsxs("span",{className:"wm-review-stat pending",children:[ye.length," pending"]}),e.jsxs("span",{className:"wm-review-stat total",children:[Le.length," total"]})]}),ye.length>0&&e.jsxs("button",{className:"wm-approve-all-btn",onClick:Rs,children:["Approve all (",ye.length,")"]})]}),Ts?e.jsxs("div",{className:"wm-review-loading",children:["Loading lines","…"]}):Le.length===0?e.jsxs("div",{className:"wm-review-empty",children:[e.jsx("div",{className:"wm-review-empty-icon",children:"◌"}),e.jsxs("div",{className:"wm-review-empty-text",children:["No lines yet. Write in the Write tab and click ","→"," Review to send them here."]}),e.jsxs("button",{className:"wm-review-go-write",onClick:()=>yt("write"),children:["Go to Write tab ","→"]})]}):e.jsxs("div",{className:"wm-review-manuscript",children:[Je.map((t,s)=>e.jsxs("div",{children:[ds(t,!1),(s+1)%5===0&&s<Je.length-1&&e.jsx("div",{className:"wm-ni-inline",children:e.jsx(ps,{chapter:d,lines:Je.slice(Math.max(0,s-4),s+1),lineIndex:s,book:D,characters:Vt})})]},t.id)),e.jsx(Zs,{chapter:d,lines:Je,book:D,triggerLine:Cs}),ye.length>0&&e.jsxs("div",{className:"wm-pending-section",children:[e.jsxs("div",{className:"wm-pending-label",children:[ye.length," pending"]}),ye.map(t=>ds(t,!0))]})]})]}),he==="structure"&&e.jsx("div",{className:"wm-panel-tab",children:e.jsx(la,{bookId:b,allChapters:f,onChapterUpdate:(t,s)=>{$(n=>n.map(i=>i.id===t?{...i,...s}:i))},onReloadChapters:es})}),he==="scenes"&&e.jsx("div",{className:"wm-panel-tab",children:e.jsx(oa,{bookId:b,chapters:f,onChaptersChange:es,book:D})}),he==="memory"&&e.jsx("div",{className:"wm-panel-tab",children:e.jsx(ea,{bookId:b})}),he==="lala"&&e.jsx("div",{className:"wm-panel-tab",children:e.jsx(ta,{bookId:b})}),he==="export"&&e.jsx("div",{className:"wm-panel-tab",children:e.jsx(sa,{bookId:b})})]}),w&&e.jsxs("aside",{className:"wm-context-panel",children:[e.jsx("div",{className:"wm-ctx-header",children:e.jsxs("div",{className:"wm-ctx-tabs",children:[e.jsx("button",{className:`wm-ctx-tab${Ye==="plan"?" wm-ctx-tab--active":""}`,onClick:()=>Ft("plan"),children:"Chapter Plan"}),e.jsxs("button",{className:`wm-ctx-tab${Ye==="ai-writer"?" wm-ctx-tab--active":""}`,onClick:()=>Ft("ai-writer"),children:["✦"," Write"]})]})}),Ye==="ai-writer"&&e.jsx(ra,{chapterId:c,bookId:b,selectedCharacter:null,currentProse:m,chapterContext:{scene_goal:d?.scene_goal,theme:d?.theme,emotional_arc_start:d?.emotional_state_start,emotional_arc_end:d?.emotional_state_end,pov:d?.pov},onInsert:t=>{se(s=>s?s+`

`+t:t)}}),Ye==="plan"&&e.jsxs(e.Fragment,{children:[e.jsxs("div",{className:"wm-ctx-field",children:[e.jsx("label",{className:"wm-ctx-label",children:"Scene Goal"}),Se==="scene_goal"?e.jsx("textarea",{className:"wm-ctx-input",value:L,onChange:t=>ie(t.target.value),onBlur:()=>de("scene_goal",L),onKeyDown:t=>{t.key==="Enter"&&!t.shiftKey&&(t.preventDefault(),de("scene_goal",L)),t.key==="Escape"&&V(null)},rows:3,autoFocus:!0}):e.jsx("div",{className:"wm-ctx-value",onClick:()=>{V("scene_goal"),ie(d?.scene_goal||"")},title:"Click to edit",children:d?.scene_goal||e.jsx("span",{className:"wm-ctx-empty",children:"What happens in this chapter?"})})]}),e.jsxs("div",{className:"wm-ctx-field",children:[e.jsx("label",{className:"wm-ctx-label",children:"Theme"}),Se==="theme"?e.jsx("input",{className:"wm-ctx-input",value:L,onChange:t=>ie(t.target.value),onBlur:()=>de("theme",L),onKeyDown:t=>{t.key==="Enter"&&de("theme",L),t.key==="Escape"&&V(null)},autoFocus:!0}):e.jsx("div",{className:"wm-ctx-value",onClick:()=>{V("theme"),ie(d?.theme||"")},children:d?.theme||e.jsx("span",{className:"wm-ctx-empty",children:"Central theme"})})]}),e.jsxs("div",{className:"wm-ctx-field",children:[e.jsx("label",{className:"wm-ctx-label",children:"Emotional Arc"}),e.jsxs("div",{className:"wm-ctx-arc",children:[Se==="emotional_state_start"?e.jsx("input",{className:"wm-ctx-input wm-ctx-input-sm",value:L,onChange:t=>ie(t.target.value),onBlur:()=>de("emotional_state_start",L),onKeyDown:t=>{t.key==="Enter"&&de("emotional_state_start",L),t.key==="Escape"&&V(null)},placeholder:"Start",autoFocus:!0}):e.jsx("span",{className:"wm-ctx-arc-point",onClick:()=>{V("emotional_state_start"),ie(d?.emotional_state_start||"")},children:d?.emotional_state_start||"Start"}),e.jsx("span",{className:"wm-ctx-arc-arrow",children:"→"}),Se==="emotional_state_end"?e.jsx("input",{className:"wm-ctx-input wm-ctx-input-sm",value:L,onChange:t=>ie(t.target.value),onBlur:()=>de("emotional_state_end",L),onKeyDown:t=>{t.key==="Enter"&&de("emotional_state_end",L),t.key==="Escape"&&V(null)},placeholder:"End",autoFocus:!0}):e.jsx("span",{className:"wm-ctx-arc-point",onClick:()=>{V("emotional_state_end"),ie(d?.emotional_state_end||"")},children:d?.emotional_state_end||"End"})]})]}),e.jsxs("div",{className:"wm-ctx-field",children:[e.jsx("label",{className:"wm-ctx-label",children:"POV"}),Se==="pov"?e.jsx("input",{className:"wm-ctx-input",value:L,onChange:t=>ie(t.target.value),onBlur:()=>de("pov",L),onKeyDown:t=>{t.key==="Enter"&&de("pov",L),t.key==="Escape"&&V(null)},autoFocus:!0}):e.jsx("div",{className:"wm-ctx-value",onClick:()=>{V("pov"),ie(d?.pov||"")},children:d?.pov||e.jsx("span",{className:"wm-ctx-empty",children:"Perspective"})})]}),e.jsxs("div",{className:"wm-ctx-field",children:[e.jsx("label",{className:"wm-ctx-label",children:"Notes"}),Se==="chapter_notes"?e.jsx("textarea",{className:"wm-ctx-input",value:L,onChange:t=>ie(t.target.value),onBlur:()=>de("chapter_notes",L),onKeyDown:t=>{t.key==="Enter"&&!t.shiftKey&&(t.preventDefault(),de("chapter_notes",L)),t.key==="Escape"&&V(null)},rows:4,autoFocus:!0}):e.jsx("div",{className:"wm-ctx-value wm-ctx-notes",onClick:()=>{V("chapter_notes"),ie(d?.chapter_notes||"")},children:d?.chapter_notes||e.jsx("span",{className:"wm-ctx-empty",children:"Reminders, ideas, references…"})})]}),Fe&&e.jsxs("div",{className:"wm-ctx-prev",children:[e.jsxs("label",{className:"wm-ctx-label",children:["Previous: ",Fe.title]}),e.jsxs("div",{className:"wm-ctx-prev-stats",children:[Fe.wordCount.toLocaleString()," words"]}),Fe.excerpt?e.jsxs("div",{className:"wm-ctx-prev-excerpt",children:["“",Fe.excerpt,"”"]}):e.jsx("div",{className:"wm-ctx-prev-excerpt wm-ctx-empty",children:"Not yet written"})]}),e.jsxs("button",{className:"wm-ctx-structure-link",onClick:()=>{j||P(!0),R(t=>{if(t!==c){const s=f.find(i=>i.id===c),n=s?.sections&&Array.isArray(s.sections)?s.sections.map(i=>({...i,id:i.id||Bt()})):[];O(n)}return c})},children:["☰"," Show Chapter Structure"]})]})]})]}),ws&&e.jsx("div",{className:"wm-modal-overlay",onClick:()=>ut(!1),children:e.jsxs("div",{className:"wm-modal",onClick:t=>t.stopPropagation(),children:[e.jsx("div",{className:"wm-modal-title",children:"Leave Write Mode?"}),e.jsx("div",{className:"wm-modal-sub",children:m?"Your draft is saved. You can come back.":"Nothing written yet."}),e.jsxs("div",{className:"wm-modal-btns",children:[e.jsx("button",{className:"wm-modal-cancel",onClick:()=>ut(!1),children:"Stay"}),e.jsx("button",{className:"wm-modal-leave",onClick:async()=>{m&&await ze(m),H(`/book/${b}`)},children:m?"Save & Leave":"Leave"})]})]})})]})}export{ga as default};
