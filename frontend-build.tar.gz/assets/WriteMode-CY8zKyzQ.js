import{j as e,L as Ys}from"./index-BMA0welq.js";import{b as a,k as Qs,u as Xs}from"./react-vendor-Bbt6Sxdk.js";import{W as Zs}from"./WriteModeAIWriter-DFHvvQ6F.js";import{M as ea,N as ps,C as ta,a as sa,L as aa,E as na}from"./ExportPanel-ClkT4QnU.js";import"./pdf-vendor-Btc3-hiy.js";const Ye="/api/v1",Qe=()=>{const $=localStorage.getItem("token")||sessionStorage.getItem("token");return{"Content-Type":"application/json",...$?{Authorization:`Bearer ${$}`}:{}}};function ra({bookId:$,chapters:A=[],onChaptersChange:w,book:g}){const[W,ve]=a.useState({}),[Ce,pe]=a.useState(null),[r,U]=a.useState(""),[v,me]=a.useState(null),[u,P]=a.useState(""),[E,X]=a.useState({}),[z,V]=a.useState({}),[Z,ne]=a.useState(!1),[J,je]=a.useState(null),[le,ee]=a.useState(null),he=i=>ve(b=>({...b,[i]:!b[i]})),ue=A.map(i=>{const b=Array.isArray(i.sections)?i.sections:[],p=b.filter(j=>j.type==="h3");return{...i,scenes:p,allSections:b}}),l=ue.reduce((i,b)=>i+b.scenes.length,0),d=a.useCallback(async(i,b)=>{const p=b||r;if(!p?.trim())return;const j=A.find(xe=>xe.id===i);if(!j)return;const f=Array.isArray(j.sections)?[...j.sections]:[],R={id:`sec_${Date.now()}_${Math.random().toString(36).slice(2,8)}`,type:"h3",content:p.trim(),prose:""};f.push(R);try{await fetch(`${Ye}/storyteller/chapters/${i}`,{method:"PUT",headers:Qe(),body:JSON.stringify({sections:f})}),w&&w()}catch(xe){console.error("Add scene error:",xe)}pe(null),U("")},[r,A,w]),C=a.useCallback(async(i,b,p)=>{const j=A.find(R=>R.id===i);if(!j)return;const f=(Array.isArray(j.sections)?j.sections:[]).map(R=>R.id===b?{...R,content:p}:R);try{await fetch(`${Ye}/storyteller/chapters/${i}`,{method:"PUT",headers:Qe(),body:JSON.stringify({sections:f})}),w&&w()}catch(R){console.error("Rename scene error:",R)}me(null)},[A,w]),I=a.useCallback(async(i,b)=>{const p=A.find(f=>f.id===i);if(!p)return;const j=(Array.isArray(p.sections)?p.sections:[]).filter(f=>f.id!==b);try{await fetch(`${Ye}/storyteller/chapters/${i}`,{method:"PUT",headers:Qe(),body:JSON.stringify({sections:j})}),w&&w()}catch(f){console.error("Delete scene error:",f)}},[A,w]),ce=a.useCallback(async i=>{X(b=>({...b,[i.id]:!0})),ee(null);try{const b=(Array.isArray(i.sections)?i.sections:[]).filter(f=>f.type==="h3").map(f=>({content:f.content,title:f.content})),p=await fetch(`${Ye}/memories/scene-planner`,{method:"POST",headers:Qe(),body:JSON.stringify({book_id:$,chapter_id:i.id,chapter_title:i.title,chapter_type:i.chapter_type||"chapter",existing_scenes:b,draft_prose:i.draft_prose||"",book_title:g?.title||"",book_description:g?.description||"",all_chapters:A.map(f=>({id:f.id,title:f.title,chapter_type:f.chapter_type,scenes:(Array.isArray(f.sections)?f.sections:[]).filter(R=>R.type==="h3")})),theme:i.theme||"",scene_goal:i.scene_goal||""})}),j=await p.json();if(!p.ok)throw new Error(j.error||"AI request failed");V(f=>({...f,[i.id]:j.suggestions||[]}))}catch(b){console.error("AI scene planner error:",b),ee(b.message)}finally{X(b=>({...b,[i.id]:!1}))}},[$,A,g,w]),Y=a.useCallback(async()=>{ne(!0),ee(null);try{const i=await fetch(`${Ye}/memories/books/${$}/scenes`,{headers:Qe()}),b=await i.json();if(!i.ok)throw new Error(b.error||"AI request failed");je(b.scenes||b)}catch(i){console.error("Book AI scenes error:",i),ee(i.message)}finally{ne(!1)}},[$]),k=a.useCallback(async(i,b)=>{await d(i,b.title),V(p=>({...p,[i]:(p[i]||[]).filter(j=>j.title!==b.title)}))},[d]),Ne=a.useCallback(async i=>{const b=i.chapter_id?A.find(p=>p.id===i.chapter_id):A[0];b&&(await d(b.id,i.title),je(p=>p?p.filter(j=>j.title!==i.title):null))},[A,d]),L=i=>i==="beginning"?"▶":i==="end"?"◀":"◆";return e.jsxs("div",{className:"scenes-panel",children:[e.jsxs("div",{className:"scenes-panel-header",children:[e.jsxs("div",{children:[e.jsx("h3",{className:"scenes-panel-title",children:"Scenes Overview"}),e.jsxs("span",{className:"scenes-panel-count",children:[l," scenes across ",A.length," chapters"]})]}),e.jsx("button",{className:"scenes-panel-ai-book-btn",onClick:Y,disabled:Z,title:"AI analyzes your entire book and suggests scenes that would strengthen the arc",children:Z?"⧖ Thinking…":"✨ AI Scene Architect"})]}),le&&e.jsxs("div",{className:"scenes-panel-ai-error",children:[e.jsxs("span",{children:["⚠"," ",le]}),e.jsx("button",{onClick:()=>ee(null),children:"×"})]}),J&&J.length>0&&e.jsxs("div",{className:"scenes-panel-ai-book-results",children:[e.jsxs("div",{className:"scenes-panel-ai-book-label",children:["✨"," AI Suggested Scenes for Your Book"]}),J.map((i,b)=>e.jsxs("div",{className:"scenes-panel-ai-card",children:[e.jsxs("div",{className:"scenes-panel-ai-card-head",children:[e.jsx("span",{className:"scenes-panel-ai-card-title",children:i.title}),i.chapter_hint&&e.jsx("span",{className:"scenes-panel-ai-card-ch",children:i.chapter_hint})]}),e.jsx("p",{className:"scenes-panel-ai-card-desc",children:i.description}),i.reason&&e.jsxs("p",{className:"scenes-panel-ai-card-reason",children:[e.jsx("span",{className:"scenes-panel-ai-card-reason-label",children:"Why:"})," ",i.reason]}),i.characters&&i.characters.length>0&&e.jsx("div",{className:"scenes-panel-ai-card-chars",children:i.characters.map(p=>e.jsx("span",{className:"scenes-panel-ai-char-tag",children:p},p))}),e.jsxs("div",{className:"scenes-panel-ai-card-actions",children:[e.jsxs("button",{className:"scenes-panel-ai-accept",onClick:()=>Ne(i),title:"Add this scene to the chapter",children:["✓"," Add Scene"]}),e.jsx("button",{className:"scenes-panel-ai-dismiss",onClick:()=>je(p=>p.filter((j,f)=>f!==b)),title:"Dismiss",children:"Dismiss"})]})]},b)),e.jsx("button",{className:"scenes-panel-ai-clear",onClick:()=>je(null),children:"Clear all suggestions"})]}),ue.length===0?e.jsx("div",{className:"scenes-panel-empty",children:e.jsx("p",{children:"No chapters yet. Create chapters to start adding scenes."})}):e.jsx("div",{className:"scenes-panel-list",children:ue.map((i,b)=>e.jsxs("div",{className:"scenes-panel-chapter",children:[e.jsxs("button",{className:`scenes-panel-chapter-btn${W[i.id]?" expanded":""}`,onClick:()=>he(i.id),children:[e.jsxs("span",{className:"scenes-panel-ch-num",children:["Ch. ",i.chapter_number||b+1]}),i.chapter_type&&i.chapter_type!=="chapter"&&e.jsx("span",{className:"scenes-panel-ch-type",children:i.chapter_type}),e.jsx("span",{className:"scenes-panel-ch-title",children:i.title||"Untitled"}),e.jsxs("span",{className:"scenes-panel-ch-count",children:[i.scenes.length," scene",i.scenes.length!==1?"s":""]}),e.jsx("span",{className:"scenes-panel-ch-arrow",children:W[i.id]?"▾":"▸"})]}),W[i.id]&&e.jsxs("div",{className:"scenes-panel-scenes",children:[i.scenes.length===0?e.jsx("div",{className:"scenes-panel-no-scenes",children:"No scenes defined"}):i.scenes.map((p,j)=>e.jsxs("div",{className:"scenes-panel-scene",children:[e.jsx("span",{className:"scenes-panel-scene-num",children:j+1}),e.jsx("span",{className:"scenes-panel-scene-dinkus",children:"✦"}),v&&v.chId===i.id&&v.secId===p.id?e.jsx("input",{className:"scenes-panel-scene-edit",value:u,onChange:f=>P(f.target.value),onBlur:()=>C(i.id,p.id,u),onKeyDown:f=>{f.key==="Enter"&&C(i.id,p.id,u),f.key==="Escape"&&me(null)},autoFocus:!0}):e.jsx("span",{className:"scenes-panel-scene-title",onDoubleClick:()=>{me({chId:i.id,secId:p.id}),P(p.content||"")},title:"Double-click to rename",children:p.content||"Untitled Scene"}),e.jsx("button",{className:"scenes-panel-scene-del",onClick:()=>I(i.id,p.id),title:"Delete scene",children:"×"})]},p.id||j)),Ce===i.id?e.jsxs("div",{className:"scenes-panel-add-row",children:[e.jsx("input",{className:"scenes-panel-add-input",value:r,onChange:p=>U(p.target.value),onKeyDown:p=>{p.key==="Enter"&&d(i.id),p.key==="Escape"&&(pe(null),U(""))},placeholder:"Scene title…",autoFocus:!0}),e.jsx("button",{className:"scenes-panel-add-confirm",onClick:()=>d(i.id),children:"✓"}),e.jsx("button",{className:"scenes-panel-add-cancel",onClick:()=>{pe(null),U("")},children:"×"})]}):e.jsxs("div",{className:"scenes-panel-add-row-buttons",children:[e.jsx("button",{className:"scenes-panel-add-btn",onClick:()=>{pe(i.id),U("")},children:"+ Add Scene"}),e.jsx("button",{className:"scenes-panel-ai-plan-btn",onClick:()=>ce(i),disabled:E[i.id],title:"AI reads your chapter and suggests scenes",children:E[i.id]?"⧖ Planning…":"✨ AI Plan Scenes"})]}),z[i.id]&&z[i.id].length>0&&e.jsxs("div",{className:"scenes-panel-ai-suggestions",children:[e.jsxs("div",{className:"scenes-panel-ai-label",children:["✨"," AI Suggestions"]}),z[i.id].map((p,j)=>e.jsxs("div",{className:"scenes-panel-ai-sug-card",children:[e.jsxs("div",{className:"scenes-panel-ai-sug-head",children:[e.jsx("span",{className:"scenes-panel-ai-sug-pos",title:p.suggested_position||"middle",children:L(p.suggested_position)}),e.jsx("span",{className:"scenes-panel-ai-sug-title",children:p.title}),p.emotional_beat&&e.jsx("span",{className:"scenes-panel-ai-sug-beat",children:p.emotional_beat})]}),e.jsx("p",{className:"scenes-panel-ai-sug-desc",children:p.description}),p.purpose&&e.jsxs("p",{className:"scenes-panel-ai-sug-purpose",children:[e.jsx("span",{className:"scenes-panel-ai-sug-purpose-label",children:"Purpose:"})," ",p.purpose]}),e.jsxs("div",{className:"scenes-panel-ai-sug-actions",children:[e.jsxs("button",{className:"scenes-panel-ai-accept",onClick:()=>k(i.id,p),children:["✓"," Add Scene"]}),e.jsx("button",{className:"scenes-panel-ai-dismiss",onClick:()=>V(f=>({...f,[i.id]:(f[i.id]||[]).filter((R,xe)=>xe!==j)})),children:"Dismiss"})]})]},j)),e.jsx("button",{className:"scenes-panel-ai-clear",onClick:()=>V(p=>({...p,[i.id]:[]})),children:"Clear suggestions"})]})]})]},i.id))}),e.jsx("style",{children:`
        .scenes-panel { padding: 24px; max-width: 760px; margin: 0 auto; }
        .scenes-panel-header {
          display: flex; align-items: flex-start; justify-content: space-between;
          margin-bottom: 24px; gap: 16px; flex-wrap: wrap;
        }
        .scenes-panel-title {
          font-family: 'Playfair Display', 'Lora', Georgia, serif;
          font-size: 20px; font-weight: 600; color: #1C1814; margin: 0 0 4px;
        }
        .scenes-panel-count {
          font-family: 'DM Mono', monospace; font-size: 10px;
          letter-spacing: 0.1em; color: rgba(28,24,20,0.4);
        }
        .scenes-panel-empty {
          text-align: center; padding: 48px 24px;
          font-family: 'Lora', Georgia, serif; font-style: italic;
          color: rgba(28,24,20,0.4); font-size: 14px;
        }

        /* ── Book-level AI button ── */
        .scenes-panel-ai-book-btn {
          background: linear-gradient(135deg, rgba(198,168,94,0.08), rgba(198,168,94,0.15));
          border: 1px solid rgba(198,168,94,0.25);
          border-radius: 6px; padding: 8px 16px;
          font-family: 'DM Mono', monospace; font-size: 10px;
          letter-spacing: 0.08em; color: #B8962E;
          cursor: pointer; transition: all 0.15s ease; white-space: nowrap;
        }
        .scenes-panel-ai-book-btn:hover:not(:disabled) {
          background: linear-gradient(135deg, rgba(198,168,94,0.15), rgba(198,168,94,0.25));
          border-color: rgba(198,168,94,0.4);
        }
        .scenes-panel-ai-book-btn:disabled { opacity: 0.6; cursor: wait; }

        /* ── AI error ── */
        .scenes-panel-ai-error {
          display: flex; align-items: center; justify-content: space-between;
          background: rgba(184,92,56,0.06); border: 1px solid rgba(184,92,56,0.15);
          border-radius: 6px; padding: 10px 14px; margin-bottom: 16px;
          font-family: 'DM Sans', sans-serif; font-size: 12px; color: #B85C38;
        }
        .scenes-panel-ai-error button {
          background: none; border: none; font-size: 16px;
          color: #B85C38; cursor: pointer;
        }

        /* ── Book-wide AI results ── */
        .scenes-panel-ai-book-results {
          background: rgba(198,168,94,0.03);
          border: 1px solid rgba(198,168,94,0.12);
          border-radius: 8px; padding: 16px; margin-bottom: 24px;
        }
        .scenes-panel-ai-book-label {
          font-family: 'DM Mono', monospace; font-size: 10px;
          letter-spacing: 0.12em; color: #B8962E; margin-bottom: 12px;
          text-transform: uppercase;
        }

        /* ── AI card (book-wide) ── */
        .scenes-panel-ai-card {
          background: rgba(250,248,245,0.8);
          border: 1px solid rgba(232,226,218,0.6);
          border-radius: 6px; padding: 12px 14px; margin-bottom: 10px;
        }
        .scenes-panel-ai-card-head {
          display: flex; align-items: baseline; gap: 8px; margin-bottom: 6px;
        }
        .scenes-panel-ai-card-title {
          font-family: 'Lora', Georgia, serif; font-size: 14px;
          font-weight: 600; color: #1C1814;
        }
        .scenes-panel-ai-card-ch {
          font-family: 'DM Mono', monospace; font-size: 9px;
          color: rgba(28,24,20,0.35); letter-spacing: 0.05em;
        }
        .scenes-panel-ai-card-desc {
          font-family: 'Lora', Georgia, serif; font-size: 12.5px;
          color: rgba(28,24,20,0.7); line-height: 1.5; margin: 0 0 6px;
        }
        .scenes-panel-ai-card-reason {
          font-family: 'DM Sans', sans-serif; font-size: 11px;
          color: rgba(28,24,20,0.45); margin: 0 0 6px; font-style: italic;
        }
        .scenes-panel-ai-card-reason-label {
          font-weight: 600; font-style: normal; color: rgba(28,24,20,0.5);
        }
        .scenes-panel-ai-card-chars {
          display: flex; gap: 4px; flex-wrap: wrap; margin-bottom: 8px;
        }
        .scenes-panel-ai-char-tag {
          font-family: 'DM Mono', monospace; font-size: 9px;
          background: rgba(198,168,94,0.1); color: #B8962E;
          border-radius: 3px; padding: 2px 6px;
        }
        .scenes-panel-ai-card-actions {
          display: flex; gap: 8px;
        }

        /* ── Per-chapter AI plan button ── */
        .scenes-panel-add-row-buttons {
          display: flex; align-items: center; gap: 12px; padding: 4px 0;
        }
        .scenes-panel-ai-plan-btn {
          background: none; border: none;
          font-family: 'DM Mono', monospace; font-size: 9px;
          letter-spacing: 0.08em; color: #B8962E;
          cursor: pointer; padding: 8px 0; transition: all 0.12s ease;
          opacity: 0.7;
        }
        .scenes-panel-ai-plan-btn:hover:not(:disabled) { opacity: 1; }
        .scenes-panel-ai-plan-btn:disabled { opacity: 0.5; cursor: wait; }

        /* ── AI suggestions per chapter ── */
        .scenes-panel-ai-suggestions {
          background: rgba(198,168,94,0.03);
          border: 1px solid rgba(198,168,94,0.1);
          border-radius: 6px; padding: 12px; margin-top: 8px;
        }
        .scenes-panel-ai-label {
          font-family: 'DM Mono', monospace; font-size: 9px;
          letter-spacing: 0.12em; color: #B8962E; margin-bottom: 10px;
          text-transform: uppercase;
        }
        .scenes-panel-ai-sug-card {
          background: rgba(250,248,245,0.8);
          border: 1px solid rgba(232,226,218,0.5);
          border-radius: 5px; padding: 10px 12px; margin-bottom: 8px;
        }
        .scenes-panel-ai-sug-head {
          display: flex; align-items: baseline; gap: 6px; margin-bottom: 4px;
        }
        .scenes-panel-ai-sug-pos {
          font-size: 8px; color: rgba(28,24,20,0.25);
        }
        .scenes-panel-ai-sug-title {
          font-family: 'Lora', Georgia, serif; font-size: 13px;
          font-weight: 600; color: #1C1814;
        }
        .scenes-panel-ai-sug-beat {
          font-family: 'DM Sans', sans-serif; font-size: 10px;
          color: #B8962E; font-style: italic; margin-left: auto;
        }
        .scenes-panel-ai-sug-desc {
          font-family: 'Lora', Georgia, serif; font-size: 12px;
          color: rgba(28,24,20,0.65); line-height: 1.45; margin: 0 0 4px;
        }
        .scenes-panel-ai-sug-purpose {
          font-family: 'DM Sans', sans-serif; font-size: 10.5px;
          color: rgba(28,24,20,0.4); margin: 0 0 6px; font-style: italic;
        }
        .scenes-panel-ai-sug-purpose-label {
          font-weight: 600; font-style: normal; color: rgba(28,24,20,0.45);
        }
        .scenes-panel-ai-sug-actions {
          display: flex; gap: 8px;
        }

        /* ── Shared AI action buttons ── */
        .scenes-panel-ai-accept {
          background: rgba(74,155,111,0.08); border: 1px solid rgba(74,155,111,0.2);
          border-radius: 4px; padding: 4px 10px;
          font-family: 'DM Mono', monospace; font-size: 9px;
          color: #4A9B6F; cursor: pointer; transition: all 0.12s ease;
        }
        .scenes-panel-ai-accept:hover {
          background: rgba(74,155,111,0.15); border-color: rgba(74,155,111,0.35);
        }
        .scenes-panel-ai-dismiss {
          background: none; border: none;
          font-family: 'DM Mono', monospace; font-size: 9px;
          color: rgba(28,24,20,0.3); cursor: pointer;
        }
        .scenes-panel-ai-dismiss:hover { color: rgba(28,24,20,0.5); }
        .scenes-panel-ai-clear {
          background: none; border: none;
          font-family: 'DM Mono', monospace; font-size: 9px;
          color: rgba(28,24,20,0.25); cursor: pointer;
          padding: 6px 0; margin-top: 4px;
        }
        .scenes-panel-ai-clear:hover { color: rgba(28,24,20,0.4); }

        /* ── Chapter type badge ── */
        .scenes-panel-ch-type {
          font-family: 'DM Mono', monospace; font-size: 8px;
          letter-spacing: 0.08em; text-transform: uppercase;
          color: #B8962E; background: rgba(198,168,94,0.08);
          border-radius: 3px; padding: 1px 5px;
        }

        /* ── Existing styles ── */
        .scenes-panel-chapter { margin-bottom: 2px; }
        .scenes-panel-chapter-btn {
          display: flex; align-items: center; gap: 10px; width: 100%;
          background: none; border: none; border-bottom: 1px solid rgba(28,24,20,0.06);
          padding: 12px 8px; cursor: pointer; text-align: left;
          transition: background 0.12s ease;
        }
        .scenes-panel-chapter-btn:hover { background: rgba(28,24,20,0.02); }
        .scenes-panel-ch-num {
          font-family: 'DM Mono', monospace; font-size: 10px;
          color: rgba(28,24,20,0.35); min-width: 40px;
        }
        .scenes-panel-ch-title {
          flex: 1; font-family: 'Lora', Georgia, serif; font-size: 14px; color: #1C1814;
        }
        .scenes-panel-ch-count {
          font-family: 'DM Mono', monospace; font-size: 9px;
          color: rgba(28,24,20,0.3); letter-spacing: 0.05em;
        }
        .scenes-panel-ch-arrow {
          font-size: 10px; color: rgba(28,24,20,0.3); min-width: 14px; text-align: center;
        }
        .scenes-panel-scenes {
          padding: 4px 0 12px 52px;
        }
        .scenes-panel-no-scenes {
          font-family: 'Lora', Georgia, serif; font-style: italic;
          font-size: 12px; color: rgba(28,24,20,0.3); padding: 8px 0;
        }
        .scenes-panel-scene {
          display: flex; align-items: center; gap: 8px;
          padding: 6px 0; font-family: 'Lora', Georgia, serif; font-size: 13px;
        }
        .scenes-panel-scene-num {
          font-family: 'DM Mono', monospace; font-size: 9px;
          color: rgba(28,24,20,0.25); min-width: 16px;
        }
        .scenes-panel-scene-dinkus {
          font-size: 8px; color: #B8962E; opacity: 0.6;
        }
        .scenes-panel-scene-title {
          color: #1C1814; cursor: default; flex: 1;
        }
        .scenes-panel-scene-title:hover { text-decoration: underline dotted rgba(28,24,20,0.2); }
        .scenes-panel-scene-edit {
          flex: 1; border: none; border-bottom: 1px solid rgba(184,150,46,0.4);
          background: none; font-family: 'Lora', Georgia, serif; font-size: 13px;
          color: #1C1814; padding: 2px 0; outline: none;
        }
        .scenes-panel-scene-del {
          background: none; border: none; font-size: 14px; color: rgba(28,24,20,0.2);
          cursor: pointer; padding: 2px 4px; opacity: 0; transition: opacity 0.1s ease;
        }
        .scenes-panel-scene:hover .scenes-panel-scene-del { opacity: 1; }
        .scenes-panel-scene-del:hover { color: #B85C38; }

        /* Add scene */
        .scenes-panel-add-btn {
          background: none; border: none; font-family: 'DM Mono', monospace;
          font-size: 9px; letter-spacing: 0.08em; color: rgba(28,24,20,0.35);
          cursor: pointer; padding: 8px 0; transition: color 0.12s ease;
        }
        .scenes-panel-add-btn:hover { color: #B8962E; }
        .scenes-panel-add-row {
          display: flex; align-items: center; gap: 6px; padding: 6px 0;
        }
        .scenes-panel-add-input {
          flex: 1; border: none; border-bottom: 1px solid rgba(28,24,20,0.12);
          background: none; font-family: 'Lora', Georgia, serif; font-size: 13px;
          color: #1C1814; padding: 4px 0; outline: none;
        }
        .scenes-panel-add-input:focus { border-bottom-color: rgba(184,150,46,0.4); }
        .scenes-panel-add-confirm,
        .scenes-panel-add-cancel {
          background: none; border: none; font-size: 14px;
          cursor: pointer; padding: 2px 4px; color: rgba(28,24,20,0.4);
        }
        .scenes-panel-add-confirm:hover { color: #4A9B6F; }
        .scenes-panel-add-cancel:hover { color: #B85C38; }

        @media (max-width: 480px) {
          .scenes-panel { padding: 16px 12px; }
          .scenes-panel-scenes { padding-left: 32px; }
          .scenes-panel-header { flex-direction: column; }
          .scenes-panel-ai-sug-head { flex-wrap: wrap; }
        }
      `})]})}const Pt="/api/v1",ms=[{value:"prologue",label:"Prologue",icon:"◈"},{value:"chapter",label:"Chapter",icon:"§"},{value:"interlude",label:"Interlude",icon:"~"},{value:"epilogue",label:"Epilogue",icon:"◇"},{value:"afterword",label:"Afterword",icon:"∗"}],Bt=$=>{const A=[10,9,5,4,1],w=["X","IX","V","IV","I"];let g="";return A.forEach((W,ve)=>{for(;$>=W;)g+=w[ve],$-=W}),g||""},Lt=()=>{const $=localStorage.getItem("token")||sessionStorage.getItem("token");return{"Content-Type":"application/json",...$?{Authorization:`Bearer ${$}`}:{}}};function ia({bookId:$,allChapters:A=[],onChapterUpdate:w,onReloadChapters:g}){const[W,ve]=a.useState(null),[Ce,pe]=a.useState(!0),[r,U]=a.useState("overview"),[v,me]=a.useState(!1),[u,P]=a.useState({dedication:"",epigraph:"",epigraph_attribution:"",foreword:"",preface:"",copyright:""}),[E,X]=a.useState({about_author:"",acknowledgments:"",glossary:"",appendix:"",bibliography:"",notes:""}),[z,V]=a.useState("");a.useEffect(()=>{$&&(pe(!0),fetch(`${Pt}/storyteller/books/${$}`,{headers:Lt()}).then(l=>l.json()).then(l=>{const d=l.book||l;ve(d),V(d.author_name||""),d.front_matter&&P(C=>({...C,...d.front_matter})),d.back_matter&&X(C=>({...C,...d.back_matter}))}).catch(console.error).finally(()=>pe(!1)))},[$]);const Z=a.useCallback(async()=>{if($){me(!0);try{await fetch(`${Pt}/storyteller/books/${$}`,{method:"PUT",headers:Lt(),body:JSON.stringify({author_name:z,front_matter:u,back_matter:E})})}catch(l){console.error("Save book meta error:",l)}finally{me(!1)}}},[$,z,u,E]),ne=a.useCallback(async(l,d)=>{try{await fetch(`${Pt}/storyteller/chapters/${l}`,{method:"PUT",headers:Lt(),body:JSON.stringify(d)}),w&&w(l,d)}catch(C){console.error("Save chapter meta error:",C)}},[w]),J=[...A].sort((l,d)=>(l.sort_order??l.chapter_number??0)-(d.sort_order??d.chapter_number??0)),je=J.reduce((l,d)=>{const C=d.part_number||0;return l[C]||(l[C]={number:C,title:d.part_title||"",chapters:[]}),l[C].chapters.push(d),l},{}),le=Object.values(je).sort((l,d)=>l.number-d.number),ee=J.reduce((l,d)=>{const C=d.draft_prose?d.draft_prose.split(/\s+/).filter(Boolean).length:0;return l+C},0),he=J.reduce((l,d)=>{const C=d.sections||[];return l+C.filter(I=>I.type==="h3").length},0),ue=[{id:"overview",label:"Overview",icon:"📖"},{id:"front",label:"Front Matter",icon:"◈"},{id:"structure",label:"Parts & Chapters",icon:"§"},{id:"back",label:"Back Matter",icon:"◇"}];return Ce?e.jsx("div",{className:"bsp-loading",children:e.jsx("span",{className:"bsp-loading-text",children:"Loading book structure…"})}):e.jsxs("div",{className:"bsp-panel",children:[e.jsx("div",{className:"bsp-nav",children:ue.map(l=>e.jsxs("button",{className:`bsp-nav-btn${r===l.id?" active":""}`,onClick:()=>U(l.id),children:[e.jsx("span",{className:"bsp-nav-icon",children:l.icon}),e.jsx("span",{className:"bsp-nav-label",children:l.label})]},l.id))}),r==="overview"&&e.jsxs("div",{className:"bsp-section",children:[e.jsxs("div",{className:"bsp-overview-header",children:[e.jsx("h2",{className:"bsp-title",children:W?.title||"Untitled"}),W?.subtitle&&e.jsx("p",{className:"bsp-subtitle",children:W.subtitle})]}),e.jsxs("div",{className:"bsp-stats-grid",children:[e.jsxs("div",{className:"bsp-stat",children:[e.jsx("span",{className:"bsp-stat-num",children:J.length}),e.jsx("span",{className:"bsp-stat-label",children:"Chapters"})]}),e.jsxs("div",{className:"bsp-stat",children:[e.jsx("span",{className:"bsp-stat-num",children:he}),e.jsx("span",{className:"bsp-stat-label",children:"Scenes"})]}),e.jsxs("div",{className:"bsp-stat",children:[e.jsx("span",{className:"bsp-stat-num",children:ee.toLocaleString()}),e.jsx("span",{className:"bsp-stat-label",children:"Words"})]}),e.jsxs("div",{className:"bsp-stat",children:[e.jsx("span",{className:"bsp-stat-num",children:Math.max(1,Math.round(ee/250))}),e.jsx("span",{className:"bsp-stat-label",children:"Min Read"})]})]}),e.jsxs("div",{className:"bsp-outline",children:[e.jsx("h3",{className:"bsp-outline-title",children:"Book Outline"}),e.jsxs("div",{className:"bsp-outline-group",children:[e.jsx("span",{className:"bsp-outline-group-label",children:"Front Matter"}),e.jsxs("div",{className:"bsp-outline-pills",children:[u.dedication&&e.jsx("span",{className:"bsp-pill filled",children:"Dedication"}),u.epigraph&&e.jsx("span",{className:"bsp-pill filled",children:"Epigraph"}),u.foreword&&e.jsx("span",{className:"bsp-pill filled",children:"Foreword"}),u.preface&&e.jsx("span",{className:"bsp-pill filled",children:"Preface"}),u.copyright&&e.jsx("span",{className:"bsp-pill filled",children:"Copyright"}),!u.dedication&&!u.epigraph&&!u.foreword&&!u.preface&&!u.copyright&&e.jsx("span",{className:"bsp-pill empty",children:"None added yet"})]})]}),le.map(l=>e.jsxs("div",{className:"bsp-outline-group",children:[l.number>0&&e.jsxs("span",{className:"bsp-outline-part-label",children:["Part ",Bt(l.number),l.title?` — ${l.title}`:""]}),l.number===0&&le.length>1&&e.jsx("span",{className:"bsp-outline-part-label bsp-outline-part-unassigned",children:"Unassigned"}),l.chapters.map((d,C)=>{const I=ms.find(k=>k.value===(d.chapter_type||"chapter")),ce=d.draft_prose?d.draft_prose.split(/\s+/).filter(Boolean).length:0,Y=(d.sections||[]).filter(k=>k.type==="h3").length;return e.jsxs("div",{className:"bsp-outline-chapter",children:[e.jsx("span",{className:"bsp-outline-ch-icon",children:I?.icon||"§"}),e.jsx("span",{className:"bsp-outline-ch-type",children:I?.label||"Chapter"}),e.jsx("span",{className:"bsp-outline-ch-title",children:d.title||"Untitled"}),e.jsxs("span",{className:"bsp-outline-ch-meta",children:[Y>0&&`${Y} scene${Y>1?"s":""}`,Y>0&&ce>0&&" · ",ce>0&&`${ce.toLocaleString()}w`]})]},d.id)})]},l.number)),e.jsxs("div",{className:"bsp-outline-group",children:[e.jsx("span",{className:"bsp-outline-group-label",children:"Back Matter"}),e.jsxs("div",{className:"bsp-outline-pills",children:[E.about_author&&e.jsx("span",{className:"bsp-pill filled",children:"About the Author"}),E.acknowledgments&&e.jsx("span",{className:"bsp-pill filled",children:"Acknowledgments"}),E.glossary&&e.jsx("span",{className:"bsp-pill filled",children:"Glossary"}),E.appendix&&e.jsx("span",{className:"bsp-pill filled",children:"Appendix"}),E.bibliography&&e.jsx("span",{className:"bsp-pill filled",children:"Bibliography"}),E.notes&&e.jsx("span",{className:"bsp-pill filled",children:"Notes"}),!E.about_author&&!E.acknowledgments&&!E.glossary&&!E.appendix&&!E.bibliography&&!E.notes&&e.jsx("span",{className:"bsp-pill empty",children:"None added yet"})]})]})]})]}),r==="front"&&e.jsxs("div",{className:"bsp-section",children:[e.jsxs("div",{className:"bsp-section-header",children:[e.jsx("h3",{className:"bsp-section-title",children:"Front Matter"}),e.jsx("p",{className:"bsp-section-desc",children:"These pages appear before Chapter 1 in your manuscript."})]}),e.jsxs("div",{className:"bsp-field",children:[e.jsx("label",{className:"bsp-field-label",children:"Author Name"}),e.jsx("input",{className:"bsp-input",value:z,onChange:l=>V(l.target.value),placeholder:"Your name as it appears on the title page"})]}),e.jsxs("div",{className:"bsp-field",children:[e.jsx("label",{className:"bsp-field-label",children:"Copyright Page"}),e.jsx("textarea",{className:"bsp-textarea",value:u.copyright,onChange:l=>P(d=>({...d,copyright:l.target.value})),placeholder:`© ${new Date().getFullYear()} ${z||"[Author Name]"}. All rights reserved.

No part of this publication may be reproduced...`,rows:4})]}),e.jsxs("div",{className:"bsp-field",children:[e.jsx("label",{className:"bsp-field-label",children:"Dedication"}),e.jsx("textarea",{className:"bsp-textarea bsp-textarea--short",value:u.dedication,onChange:l=>P(d=>({...d,dedication:l.target.value})),placeholder:"For those who dare to imagine…",rows:2})]}),e.jsxs("div",{className:"bsp-field",children:[e.jsx("label",{className:"bsp-field-label",children:"Epigraph"}),e.jsx("textarea",{className:"bsp-textarea bsp-textarea--short",value:u.epigraph,onChange:l=>P(d=>({...d,epigraph:l.target.value})),placeholder:"A quote that sets the tone for the entire work…",rows:2}),e.jsx("input",{className:"bsp-input bsp-input--secondary",value:u.epigraph_attribution,onChange:l=>P(d=>({...d,epigraph_attribution:l.target.value})),placeholder:"— Attribution (e.g., Virginia Woolf)"})]}),e.jsxs("div",{className:"bsp-field",children:[e.jsx("label",{className:"bsp-field-label",children:"Foreword"}),e.jsx("p",{className:"bsp-field-hint",children:"Written by someone other than the author — an endorsement or context-setting piece."}),e.jsx("textarea",{className:"bsp-textarea",value:u.foreword,onChange:l=>P(d=>({...d,foreword:l.target.value})),placeholder:"Press Enter to begin your foreword…",rows:6})]}),e.jsxs("div",{className:"bsp-field",children:[e.jsx("label",{className:"bsp-field-label",children:"Preface"}),e.jsx("p",{className:"bsp-field-hint",children:"Written by the author — explains why you wrote this book and how to read it."}),e.jsx("textarea",{className:"bsp-textarea",value:u.preface,onChange:l=>P(d=>({...d,preface:l.target.value})),placeholder:"Press Enter to begin your preface…",rows:6})]}),e.jsx("div",{className:"bsp-save-row",children:e.jsx("button",{className:"bsp-save-btn",onClick:Z,disabled:v,children:v?"Saving…":"Save Front Matter"})})]}),r==="structure"&&e.jsxs("div",{className:"bsp-section",children:[e.jsxs("div",{className:"bsp-section-header",children:[e.jsx("h3",{className:"bsp-section-title",children:"Parts & Chapters"}),e.jsx("p",{className:"bsp-section-desc",children:"Organize chapters into Parts/Acts and set chapter types (Prologue, Interlude, Epilogue, etc.)."})]}),J.map((l,d)=>{const C=l.chapter_type||"chapter",I=l.part_number||0,ce=d>0?J[d-1].part_number||0:-1,Y=I!==ce&&I>0;return e.jsxs("div",{children:[Y&&e.jsxs("div",{className:"bsp-part-header",children:[e.jsxs("span",{className:"bsp-part-numeral",children:["Part ",Bt(I)]}),e.jsx("input",{className:"bsp-part-title-input",value:l.part_title||"",onChange:k=>{const Ne=k.target.value;J.filter(L=>L.part_number===I).forEach(L=>{ne(L.id,{part_title:Ne})})},placeholder:"Part title (optional)"})]}),e.jsxs("div",{className:"bsp-chapter-row",children:[e.jsxs("div",{className:"bsp-ch-left",children:[e.jsx("span",{className:"bsp-ch-num",children:l.chapter_number||d+1}),e.jsx("span",{className:"bsp-ch-title",children:l.title||"Untitled"})]}),e.jsxs("div",{className:"bsp-ch-controls",children:[e.jsx("select",{className:"bsp-select",value:C,onChange:k=>ne(l.id,{chapter_type:k.target.value}),children:ms.map(k=>e.jsxs("option",{value:k.value,children:[k.icon," ",k.label]},k.value))}),e.jsxs("select",{className:"bsp-select bsp-select--part",value:I,onChange:k=>ne(l.id,{part_number:parseInt(k.target.value)||null,part_title:k.target.value==0?null:l.part_title}),children:[e.jsx("option",{value:0,children:"No Part"}),[1,2,3,4,5,6,7,8].map(k=>e.jsxs("option",{value:k,children:["Part ",Bt(k)]},k))]}),(()=>{const k=(l.sections||[]).filter(Ne=>Ne.type==="h3").length;return k>0?e.jsxs("span",{className:"bsp-scene-badge",children:[k," scene",k>1?"s":""]}):null})()]})]})]},l.id)}),J.length===0&&e.jsx("div",{className:"bsp-empty",children:"No chapters yet. Add chapters from the TOC sidebar."})]}),r==="back"&&e.jsxs("div",{className:"bsp-section",children:[e.jsxs("div",{className:"bsp-section-header",children:[e.jsx("h3",{className:"bsp-section-title",children:"Back Matter"}),e.jsx("p",{className:"bsp-section-desc",children:"These pages appear after the final chapter."})]}),e.jsxs("div",{className:"bsp-field",children:[e.jsx("label",{className:"bsp-field-label",children:"About the Author"}),e.jsx("textarea",{className:"bsp-textarea",value:E.about_author,onChange:l=>X(d=>({...d,about_author:l.target.value})),placeholder:"A short biography — who you are, what you write, where you live…",rows:5})]}),e.jsxs("div",{className:"bsp-field",children:[e.jsx("label",{className:"bsp-field-label",children:"Acknowledgments"}),e.jsx("textarea",{className:"bsp-textarea",value:E.acknowledgments,onChange:l=>X(d=>({...d,acknowledgments:l.target.value})),placeholder:"Thank the people and forces that made this book possible…",rows:5})]}),e.jsxs("div",{className:"bsp-field",children:[e.jsx("label",{className:"bsp-field-label",children:"Glossary"}),e.jsxs("p",{className:"bsp-field-hint",children:["Define specialized terms used in your book. One term per line: ",e.jsx("em",{children:"Term — Definition"})]}),e.jsx("textarea",{className:"bsp-textarea",value:E.glossary,onChange:l=>X(d=>({...d,glossary:l.target.value})),placeholder:"Chronoweave — The fabric of intersecting timelines…\\nEchostone — A memory artifact that replays…",rows:6})]}),e.jsxs("div",{className:"bsp-field",children:[e.jsx("label",{className:"bsp-field-label",children:"Appendix"}),e.jsx("textarea",{className:"bsp-textarea",value:E.appendix,onChange:l=>X(d=>({...d,appendix:l.target.value})),placeholder:"Supplementary material, tables, maps, or charts…",rows:5})]}),e.jsxs("div",{className:"bsp-field",children:[e.jsx("label",{className:"bsp-field-label",children:"Bibliography / References"}),e.jsx("textarea",{className:"bsp-textarea",value:E.bibliography,onChange:l=>X(d=>({...d,bibliography:l.target.value})),placeholder:"Sources, references, or further reading…",rows:4})]}),e.jsxs("div",{className:"bsp-field",children:[e.jsx("label",{className:"bsp-field-label",children:"Author's Notes / Endnotes"}),e.jsx("textarea",{className:"bsp-textarea",value:E.notes,onChange:l=>X(d=>({...d,notes:l.target.value})),placeholder:"Behind-the-scenes thoughts, research notes, or endnotes…",rows:4})]}),e.jsx("div",{className:"bsp-save-row",children:e.jsx("button",{className:"bsp-save-btn",onClick:Z,disabled:v,children:v?"Saving…":"Save Back Matter"})})]}),e.jsx("style",{children:`
/* ═══ BookStructurePanel Styles ═══ */
.bsp-panel {
  display: flex;
  flex-direction: column;
  height: 100%;
  overflow: hidden;
  background: #FAF7F0;
}
.bsp-loading {
  display: flex;
  align-items: center;
  justify-content: center;
  height: 300px;
  font-family: 'Lora', Georgia, serif;
  font-style: italic;
  color: rgba(28, 24, 20, 0.4);
  font-size: 14px;
}

/* ── Nav ── */
.bsp-nav {
  display: flex;
  gap: 0;
  border-bottom: 1px solid rgba(28, 24, 20, 0.08);
  padding: 0 12px;
  background: #FAF7F0;
  flex-shrink: 0;
  overflow-x: auto;
  -webkit-overflow-scrolling: touch;
}
.bsp-nav-btn {
  display: flex;
  align-items: center;
  gap: 6px;
  background: none;
  border: none;
  border-bottom: 2px solid transparent;
  padding: 10px 14px 8px;
  font-family: 'DM Mono', monospace;
  font-size: 10px;
  letter-spacing: 0.08em;
  color: rgba(28, 24, 20, 0.4);
  cursor: pointer;
  transition: all 0.12s ease;
  white-space: nowrap;
}
.bsp-nav-btn:hover { color: rgba(28, 24, 20, 0.7); }
.bsp-nav-btn.active {
  color: #1C1814;
  border-bottom-color: #B8962E;
}
.bsp-nav-icon { font-size: 12px; }

/* ── Section ── */
.bsp-section {
  flex: 1;
  overflow-y: auto;
  padding: 20px 24px 40px;
  max-width: 720px;
  margin: 0 auto;
  width: 100%;
}
.bsp-section-header { margin-bottom: 24px; }
.bsp-section-title {
  font-family: 'Lora', Georgia, serif;
  font-size: 18px;
  font-weight: 500;
  color: #1C1814;
  margin: 0 0 6px;
}
.bsp-section-desc {
  font-family: 'Spectral', Georgia, serif;
  font-size: 13px;
  color: rgba(28, 24, 20, 0.5);
  margin: 0;
  line-height: 1.6;
}

/* ── Overview ── */
.bsp-overview-header { text-align: center; padding: 16px 0 24px; }
.bsp-title {
  font-family: 'Lora', Georgia, serif;
  font-size: 24px;
  font-weight: 500;
  font-style: italic;
  color: #1C1814;
  margin: 0 0 4px;
}
.bsp-subtitle {
  font-family: 'Spectral', Georgia, serif;
  font-size: 14px;
  color: rgba(28, 24, 20, 0.5);
  margin: 0;
}

/* Stats grid */
.bsp-stats-grid {
  display: grid;
  grid-template-columns: repeat(4, 1fr);
  gap: 12px;
  margin-bottom: 28px;
}
.bsp-stat {
  display: flex;
  flex-direction: column;
  align-items: center;
  padding: 14px 8px;
  border: 1px solid rgba(28, 24, 20, 0.06);
  border-radius: 4px;
  background: #FFFDF9;
}
.bsp-stat-num {
  font-family: 'DM Mono', monospace;
  font-size: 20px;
  color: #1C1814;
  font-weight: 500;
}
.bsp-stat-label {
  font-family: 'DM Mono', monospace;
  font-size: 8px;
  letter-spacing: 0.15em;
  color: rgba(28, 24, 20, 0.35);
  text-transform: uppercase;
  margin-top: 4px;
}

/* Outline */
.bsp-outline { margin-top: 8px; }
.bsp-outline-title {
  font-family: 'DM Mono', monospace;
  font-size: 9px;
  letter-spacing: 0.15em;
  color: rgba(28, 24, 20, 0.3);
  text-transform: uppercase;
  margin: 0 0 16px;
  padding-bottom: 8px;
  border-bottom: 1px solid rgba(28, 24, 20, 0.06);
}
.bsp-outline-group { margin-bottom: 16px; }
.bsp-outline-group-label {
  font-family: 'DM Mono', monospace;
  font-size: 8px;
  letter-spacing: 0.12em;
  color: rgba(28, 24, 20, 0.35);
  text-transform: uppercase;
  display: block;
  margin-bottom: 8px;
}
.bsp-outline-part-label {
  font-family: 'Lora', Georgia, serif;
  font-size: 13px;
  font-weight: 600;
  color: #B8962E;
  display: block;
  margin-bottom: 8px;
  padding: 6px 0;
  border-bottom: 1px solid rgba(184, 150, 46, 0.15);
}
.bsp-outline-part-unassigned { color: rgba(28, 24, 20, 0.3); }
.bsp-outline-pills { display: flex; flex-wrap: wrap; gap: 6px; }
.bsp-pill {
  font-family: 'DM Mono', monospace;
  font-size: 9px;
  letter-spacing: 0.05em;
  padding: 4px 10px;
  border-radius: 3px;
  border: 1px solid rgba(28, 24, 20, 0.08);
}
.bsp-pill.filled { background: rgba(184, 150, 46, 0.08); color: #8A7434; border-color: rgba(184, 150, 46, 0.2); }
.bsp-pill.empty { color: rgba(28, 24, 20, 0.3); font-style: italic; }

.bsp-outline-chapter {
  display: flex;
  align-items: center;
  gap: 8px;
  padding: 6px 0 6px 8px;
  border-bottom: 1px solid rgba(28, 24, 20, 0.04);
}
.bsp-outline-ch-icon { font-size: 11px; color: rgba(28, 24, 20, 0.3); width: 16px; text-align: center; }
.bsp-outline-ch-type {
  font-family: 'DM Mono', monospace;
  font-size: 8px;
  letter-spacing: 0.08em;
  color: rgba(28, 24, 20, 0.35);
  text-transform: uppercase;
  min-width: 60px;
}
.bsp-outline-ch-title {
  font-family: 'Spectral', Georgia, serif;
  font-size: 14px;
  color: #1C1814;
  flex: 1;
  min-width: 0;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}
.bsp-outline-ch-meta {
  font-family: 'DM Mono', monospace;
  font-size: 9px;
  color: rgba(28, 24, 20, 0.3);
  white-space: nowrap;
}

/* ── Fields (Front/Back matter) ── */
.bsp-field { margin-bottom: 20px; }
.bsp-field-label {
  display: block;
  font-family: 'DM Mono', monospace;
  font-size: 10px;
  letter-spacing: 0.1em;
  color: rgba(28, 24, 20, 0.5);
  text-transform: uppercase;
  margin-bottom: 6px;
}
.bsp-field-hint {
  font-family: 'Spectral', Georgia, serif;
  font-size: 12px;
  color: rgba(28, 24, 20, 0.4);
  font-style: italic;
  margin: 0 0 8px;
  line-height: 1.5;
}
.bsp-input,
.bsp-textarea {
  width: 100%;
  border: 1px solid rgba(28, 24, 20, 0.1);
  border-radius: 3px;
  padding: 10px 14px;
  font-family: 'Spectral', Georgia, serif;
  font-size: 14px;
  line-height: 1.7;
  color: #1C1814;
  background: #FFFDF9;
  outline: none;
  transition: border-color 0.12s ease;
  box-sizing: border-box;
}
.bsp-input:focus,
.bsp-textarea:focus {
  border-color: rgba(184, 150, 46, 0.4);
}
.bsp-input--secondary {
  margin-top: 6px;
  font-style: italic;
  color: rgba(28, 24, 20, 0.6);
  font-size: 13px;
}
.bsp-textarea { resize: vertical; min-height: 60px; }
.bsp-textarea--short { min-height: 40px; }

.bsp-save-row {
  display: flex;
  justify-content: flex-end;
  margin-top: 24px;
  padding-top: 16px;
  border-top: 1px solid rgba(28, 24, 20, 0.06);
}
.bsp-save-btn {
  background: #1C1814;
  color: #FAF7F0;
  border: none;
  border-radius: 3px;
  padding: 10px 28px;
  font-family: 'DM Mono', monospace;
  font-size: 10px;
  letter-spacing: 0.1em;
  cursor: pointer;
  transition: opacity 0.12s ease;
}
.bsp-save-btn:hover { opacity: 0.85; }
.bsp-save-btn:disabled { opacity: 0.5; cursor: not-allowed; }

/* ── Parts & Chapters ── */
.bsp-part-header {
  display: flex;
  align-items: center;
  gap: 12px;
  padding: 14px 0 8px;
  border-top: 2px solid rgba(184, 150, 46, 0.2);
  margin-top: 16px;
}
.bsp-part-header:first-child { margin-top: 0; }
.bsp-part-numeral {
  font-family: 'Lora', Georgia, serif;
  font-size: 14px;
  font-weight: 600;
  color: #B8962E;
  white-space: nowrap;
}
.bsp-part-title-input {
  flex: 1;
  background: none;
  border: none;
  border-bottom: 1px solid rgba(28, 24, 20, 0.08);
  padding: 4px 0;
  font-family: 'Spectral', Georgia, serif;
  font-size: 14px;
  color: #1C1814;
  outline: none;
}
.bsp-part-title-input:focus { border-bottom-color: rgba(184, 150, 46, 0.4); }

.bsp-chapter-row {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 10px 0;
  border-bottom: 1px solid rgba(28, 24, 20, 0.04);
  gap: 12px;
  flex-wrap: wrap;
}
.bsp-ch-left {
  display: flex;
  align-items: center;
  gap: 10px;
  min-width: 0;
  flex: 1;
}
.bsp-ch-num {
  font-family: 'DM Mono', monospace;
  font-size: 11px;
  color: rgba(28, 24, 20, 0.3);
  width: 24px;
  text-align: right;
  flex-shrink: 0;
}
.bsp-ch-title {
  font-family: 'Spectral', Georgia, serif;
  font-size: 14px;
  color: #1C1814;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}
.bsp-ch-controls {
  display: flex;
  align-items: center;
  gap: 8px;
  flex-shrink: 0;
}
.bsp-select {
  background: #FFFDF9;
  border: 1px solid rgba(28, 24, 20, 0.1);
  border-radius: 3px;
  padding: 5px 8px;
  font-family: 'DM Mono', monospace;
  font-size: 9px;
  color: #1C1814;
  cursor: pointer;
  outline: none;
}
.bsp-select:focus { border-color: rgba(184, 150, 46, 0.4); }
.bsp-select--part { min-width: 85px; }
.bsp-scene-badge {
  font-family: 'DM Mono', monospace;
  font-size: 8px;
  letter-spacing: 0.08em;
  color: rgba(28, 24, 20, 0.35);
  background: rgba(28, 24, 20, 0.04);
  padding: 3px 8px;
  border-radius: 10px;
  white-space: nowrap;
}

.bsp-empty {
  text-align: center;
  padding: 32px 16px;
  font-family: 'Lora', Georgia, serif;
  font-style: italic;
  color: rgba(28, 24, 20, 0.35);
  font-size: 14px;
}

/* ── Mobile responsive ── */
@media (max-width: 480px) {
  .bsp-section { padding: 16px 12px 32px; }
  .bsp-stats-grid { grid-template-columns: repeat(2, 1fr); }
  .bsp-chapter-row { flex-direction: column; align-items: flex-start; gap: 8px; }
  .bsp-ch-controls { width: 100%; }
  .bsp-select { flex: 1; }
  .bsp-nav-btn { padding: 8px 10px 6px; font-size: 9px; }
  .bsp-outline-chapter { padding: 6px 0; }
}
@media (min-width: 481px) and (max-width: 768px) {
  .bsp-section { padding: 16px 16px 32px; }
  .bsp-stats-grid { grid-template-columns: repeat(4, 1fr); gap: 8px; }
}
      `})]})}const S="/api/v1",hs=[{type:"h2",label:"Chapter Title",icon:"H2"},{type:"h3",label:"Section",icon:"H3"},{type:"h4",label:"Subsection",icon:"H4"},{type:"body",label:"Body",icon:"¶"},{type:"quote",label:"Quote",icon:"“"},{type:"reflection",label:"Reflection",icon:"?"},{type:"divider",label:"Divider",icon:"─"}],oa=["h1","h2","h3","h4"];function zt(){return crypto.randomUUID?crypto.randomUUID():`${Date.now()}-${Math.random().toString(36).slice(2,9)}`}const us=[{id:"write",label:"Write"},{id:"review",label:"Review"},{id:"structure",label:"Structure"},{id:"scenes",label:"Scenes"},{id:"memory",label:"Memory"},{id:"lala",label:"Lala"},{id:"export",label:"Export"}];function ga({hideTopBar:$=!1,initialCenterTab:A="write"}){const{bookId:w,chapterId:g}=Qs(),W=Xs(),ve=767,[Ce,pe]=a.useState(()=>window.innerWidth<=ve);a.useEffect(()=>{const t=window.matchMedia(`(max-width: ${ve}px)`),s=n=>pe(n.matches);return t.addEventListener("change",s),()=>t.removeEventListener("change",s)},[]);const[r,U]=a.useState(null),[v,me]=a.useState(null),[u,P]=a.useState([]),[E,X]=a.useState(!0),[z,V]=a.useState(()=>{const t=localStorage.getItem("wm-show-toc");return t!==null?t==="true":!0}),[Z,ne]=a.useState(()=>{const t=localStorage.getItem("wm-show-context");return t!==null?t==="true":!0}),J=!Ce&&z,je=!Ce&&Z,[le,ee]=a.useState(null),[he,ue]=a.useState(null),[l,d]=a.useState(null),[C,I]=a.useState(""),[ce,Y]=a.useState(!1),[k,Ne]=a.useState(""),[L,i]=a.useState(null),[b,p]=a.useState([]),[j,f]=a.useState(null),[R,xe]=a.useState(""),[la,ca]=a.useState(null),[xs,Rt]=a.useState(!1),ct=a.useRef(null),[gs,It]=a.useState({}),dt=a.useRef({}),[_e,K]=a.useState(null),[B,te]=a.useState(""),[Ie,Ft]=a.useState(null),[Xe,pt]=a.useState("plan"),[m,H]=a.useState(""),[re,Q]=a.useState(0),[mt,ie]=a.useState(!0),[ht,Ze]=a.useState(!1),[ke,et]=a.useState(!1),[Ot,ut]=a.useState(""),[N,F]=a.useState(!1),[Gt,xt]=a.useState(null),[ge,bs]=a.useState(!1),[Me,gt]=a.useState(""),[fs,bt]=a.useState(!1),[Se,be]=a.useState(null),[Wt,Fe]=a.useState(null),[Oe,ft]=a.useState(null),[Ee,ws]=a.useState("paragraph"),[Ge,Te]=a.useState(""),[wt,ys]=a.useState([]),[D,We]=a.useState(null),[da,Ut]=a.useState(!1),[vs,yt]=a.useState(!1),[Jt,T]=a.useState(null),[Kt,js]=a.useState([]),[Ae,Ns]=a.useState(!1),vt=a.useRef({toc:!0,ctx:!0}),[Ht]=a.useState(()=>Date.now()),[tt,ks]=a.useState(0),[Pe,Ss]=a.useState(()=>{const t=localStorage.getItem("wm-word-goal");return t?parseInt(t,10):0}),[jt,Nt]=a.useState(!1),st=a.useRef(0),[O,fe]=a.useState(null),[qt,$e]=a.useState(null),[Be,Cs]=a.useState([]),[at,nt]=a.useState(!1),[rt,Le]=a.useState(!1),[oe,Ue]=a.useState(A||"write");a.useEffect(()=>{const t=s=>{s.detail&&us.some(n=>n.id===s.detail)&&Ue(s.detail)};return window.addEventListener("cj-set-tab",t),()=>window.removeEventListener("cj-set-tab",t)},[]),a.useEffect(()=>{const t=s=>{const n=s.detail?.tab;ne(o=>{const c=!o;return c&&n&&pt(n),c})};return window.addEventListener("cj-toggle-context",t),()=>window.removeEventListener("cj-toggle-context",t)},[]);const[de,it]=a.useState([]),[kt,St]=a.useState(null),[Je,Ct]=a.useState(""),[_s,Es]=a.useState(null),[Ts,Vt]=a.useState(!1),[Yt,$s]=a.useState([]),Qt=m.split(/\n\n+/).filter(t=>t.trim().length>20).length,Ds=Qt>=5&&oe==="write",Xt=a.useRef(null),Zt=a.useRef(null),De=a.useRef(null),_t=a.useRef(null),ot=a.useRef(null),Ke=a.useRef(""),He=a.useRef(""),es=a.useCallback(async()=>{try{const s=await(await fetch(`${S}/storyteller/books/${w}`)).json(),n=s?.book||s;me(n);const o=(n.chapters||[]).sort((c,h)=>(c.sort_order??c.chapter_number??0)-(h.sort_order??h.chapter_number??0));return P(o),o}catch{return null}},[w]);a.useEffect(()=>{async function t(){try{const n=await(await fetch(`${S}/storyteller/books/${w}`)).json(),o=n?.book||n;me(o);const c=(o.chapters||[]).sort((_,x)=>(_.sort_order??_.chapter_number??0)-(x.sort_order??x.chapter_number??0));P(c);const h=c.find(_=>_.id===g);if(U(h||{id:g,title:"Chapter"}),h?.draft_prose&&(H(h.draft_prose),Q(h.draft_prose.split(/\s+/).filter(Boolean).length)),h?.sections?.length>0){const _={};h.sections.forEach(y=>{y.id&&(_[y.id]=y.prose||"")}),It(_),dt.current=_;const x=h.sections.filter(y=>["h2","h3","h4"].includes(y.type)&&y.prose?.trim()).map(y=>y.prose).join(`

`);x.trim()&&(H(x),Q(x.split(/\s+/).filter(Boolean).length))}const M=c.findIndex(_=>_.id===g);if(M>0){const _=c[M-1],x=_.draft_prose?.trim();if(x){const y=x.split(/\n\n+/).filter(Boolean),G=y[y.length-1];Ft({title:_.title,excerpt:G.length>200?G.slice(0,200)+"…":G,wordCount:x.split(/\s+/).filter(Boolean).length})}else Ft({title:_.title,excerpt:null,wordCount:0})}}catch{U({id:g,title:"Chapter"})}finally{X(!1)}}t()},[w,g]),a.useEffect(()=>{async function t(){Ut(!0);try{const n=await(await fetch(`${S}/character-registry/registries`)).json(),o=n.registries||n||[],c=[];for(const h of o){const _=await(await fetch(`${S}/character-registry/registries/${h.id}`)).json();(_.characters||_.registry?.characters||[]).forEach(y=>c.push({...y,_registryTitle:h.title||h.book_tag}))}ys(c.filter(h=>h.status!=="declined"))}catch(s){console.error("Failed to load characters:",s)}Ut(!1)}t()},[]),a.useEffect(()=>{const t=setInterval(()=>{ks(Math.floor((Date.now()-Ht)/1e3))},1e3);return()=>clearInterval(t)},[Ht]),a.useEffect(()=>{st.current===0&&re>0&&(st.current=re)},[re]),a.useEffect(()=>{fetch(`${S}/character-registry/registries`).then(t=>t.json()).then(t=>{const s=t?.registries||t||[],n=Array.isArray(s)?s.flatMap(o=>o.characters||[]):[];$s(n)}).catch(()=>{})},[]),a.useEffect(()=>{oe!=="review"||!g||Dt()},[oe,g]),a.useEffect(()=>{const t=document.createElement("style");return t.textContent=ea,document.head.appendChild(t),()=>document.head.removeChild(t)},[]);const se=a.useCallback(t=>{m.trim()&&Cs(s=>[...s.slice(-19),{prose:m,label:t,timestamp:Date.now(),wordCount:re}])},[m,re]),Et=a.useCallback(async t=>{if(O===null||N)return;const s=m.split(/\n\n+/),n=s[O];if(n){if(t==="delete"){se("Before delete paragraph");const c=s.filter((h,M)=>M!==O).join(`

`);H(c),Q(c.split(/\s+/).filter(Boolean).length),ie(!1),fe(null),$e(null);return}se(`Before ${t} paragraph`),F(!0),$e(t);try{const c=await(await fetch(`${S}/memories/story-edit`,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({current_prose:n,edit_note:t==="rewrite"?"Rewrite this paragraph with better prose, keeping the same meaning and tone.":"Expand this paragraph with more sensory detail, interiority, and emotional depth. Keep the same voice.",pnos_act:r?.pnos_act||"act_1",chapter_title:r?.title,character_id:D?.id||null})})).json();if(c.prose){const h=[...s];h[O]=c.prose.trim();const M=h.join(`

`);H(M),Q(M.split(/\s+/).filter(Boolean).length),ie(!1)}}catch(o){console.error("paragraph action error:",o)}F(!1),fe(null),$e(null)}},[m,O,N,r,D,se]);a.useEffect(()=>{if(ot.current&&clearTimeout(ot.current),!(!m||mt))return ot.current=setTimeout(()=>ze(m),8e3),()=>clearTimeout(ot.current)},[m,mt]);const ze=a.useCallback(async t=>{if(t){Ze(!0);try{await fetch(`${S}/storyteller/chapters/${g}/save-draft`,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({draft_prose:t})});const s=dt.current;Object.keys(s).length>0&&U(n=>{if(n?.sections?.length>0){const o=n.sections.map(c=>({...c,prose:s[c.id]??c.prose??""}));return fetch(`${S}/storyteller/chapters/${g}`,{method:"PUT",headers:{"Content-Type":"application/json"},body:JSON.stringify({sections:o})}).catch(()=>{}),{...n,sections:o}}return n}),ie(!0)}catch{}Ze(!1)}},[g]),ts=a.useCallback(()=>{if(!("webkitSpeechRecognition"in window)&&!("SpeechRecognition"in window)){xt("Voice not supported on this browser. Try Chrome.");return}const t=window.SpeechRecognition||window.webkitSpeechRecognition,s=new t;s.continuous=!0,s.interimResults=!0,s.lang="en-US",Ke.current="",s.onresult=n=>{let o="",c=Ke.current;for(let h=n.resultIndex;h<n.results.length;h++)n.results[h].isFinal?c+=n.results[h][0].transcript+" ":o=n.results[h][0].transcript;Ke.current=c,ut(c+o)},s.onerror=n=>{n.error!=="no-speech"&&xt("Mic error — tap to retry"),et(!1)},s.onend=()=>et(!1),Xt.current=s,s.start(),et(!0),xt(null),ut(""),Ke.current=""},[]),ss=a.useCallback(async t=>{se("Before voice-to-story"),F(!0),Te("");try{const n=(await fetch(`${S}/memories/voice-to-story`,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({spoken:t,existing_prose:m,chapter_title:r?.title,chapter_brief:r?.scene_goal||r?.chapter_notes,pnos_act:r?.pnos_act||"act_1",book_character:v?.character||"JustAWoman",session_log:Kt.slice(-4),character_id:D?.id||null,gen_length:Ee,stream:!0})})).body.getReader(),o=new TextDecoder;let c="",h=null;for(;;){const{done:M,value:_}=await n.read();if(M)break;const y=o.decode(_,{stream:!0}).split(`
`);for(const G of y)if(G.startsWith("data: "))try{const ye=JSON.parse(G.slice(6));ye.type==="text"?(c+=ye.text,Te(c),De.current&&(De.current.scrollTop=De.current.scrollHeight)):ye.type==="done"?h=ye.hint||null:ye.type==="error"&&console.error("voice-to-story stream error:",ye.error)}catch{}}if(c){const M=m?m.trimEnd()+`

`+c:c;H(M),Q(M.split(/\s+/).filter(Boolean).length),ie(!1),js(_=>[..._,{spoken:t,generated:c}]),h&&(T(h),setTimeout(()=>T(null),6e3))}}catch(s){console.error("voice-to-story error:",s)}Te(""),F(!1)},[m,r,v,Kt,Ee,D,se]),Ms=a.useCallback(async()=>{if(ke){Xt.current?.stop(),et(!1);const t=Ke.current.trim();if(!t)return;ut(""),await ss(t)}else ts()},[ke,ts,ss]),As=a.useCallback(()=>{const t=window.SpeechRecognition||window.webkitSpeechRecognition;if(!t)return;const s=new t;s.continuous=!0,s.interimResults=!0,s.lang="en-US",He.current="",s.onresult=n=>{let o="",c=He.current;for(let h=n.resultIndex;h<n.results.length;h++)n.results[h].isFinal?c+=n.results[h][0].transcript+" ":o=n.results[h][0].transcript;He.current=c,gt(c+o)},s.onend=()=>bt(!1),Zt.current=s,s.start(),bt(!0),He.current=""},[]),Ps=a.useCallback(()=>{Zt.current?.stop(),bt(!1)},[]),Bs=a.useCallback(async()=>{if(Me.trim()){se("Before edit"),F(!0);try{const s=await(await fetch(`${S}/memories/story-edit`,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({current_prose:m,edit_note:Me.trim(),pnos_act:r?.pnos_act||"act_1",chapter_title:r?.title})})).json();s.prose&&(H(s.prose),Q(s.prose.split(/\s+/).filter(Boolean).length),ie(!1),gt(""),He.current="")}catch(t){console.error("story-edit error:",t)}F(!1)}},[m,Me,r,se]),Tt=a.useCallback(async()=>{if(!N){se("Before continue"),be("continue"),F(!0),ft(m),Fe(null),Te("");try{const t=await fetch(`${S}/memories/story-continue`,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({current_prose:m.trim()||`[Opening scene — ${r?.scene_goal||r?.chapter_notes||r?.title||"begin the chapter"}]`,chapter_title:r?.title||"Untitled Chapter",chapter_brief:r?.scene_goal||r?.chapter_notes||r?.title||"",pnos_act:r?.pnos_act||"act_1",book_character:v?.character||"JustAWoman",character_id:D?.id||null,gen_length:Ee,stream:!0,emotional_state_start:r?.emotional_state_start||"",emotional_state_end:r?.emotional_state_end||"",theme:r?.theme||v?.theme||"",pov:r?.pov||"",characters_present:r?.characters_present||"",sections:r?.sections||[],chapter_notes:r?.chapter_notes||"",tone:r?.tone||v?.tone||"",setting:r?.setting||v?.setting||"",conflict:r?.conflict||v?.conflict||"",stakes:r?.stakes||v?.stakes||"",hooks:r?.hooks||""})});if(!t.ok){try{const c=await t.json();T(c.error||`Server error (${t.status}) — please try again.`)}catch{T(`Server error (${t.status}) — please try again.`)}setTimeout(()=>T(null),5e3),Te(""),F(!1),be(null);return}const s=t.body.getReader(),n=new TextDecoder;let o="";for(;;){const{done:c,value:h}=await s.read();if(c)break;const _=n.decode(h,{stream:!0}).split(`
`);for(const x of _)if(x.startsWith("data: "))try{const y=JSON.parse(x.slice(6));y.type==="text"?(o+=y.text,Te(o),De.current&&(De.current.scrollTop=De.current.scrollHeight)):y.type==="error"&&(T(y.error),setTimeout(()=>T(null),5e3))}catch{}}if(o){const c=m.trim()?m.trimEnd()+`

`+o:o;H(c),Q(c.split(/\s+/).filter(Boolean).length),ie(!1)}else T("No text generated — try again or write a few words first."),setTimeout(()=>T(null),5e3)}catch(t){console.error("story-continue error:",t),T("Connection error — check your server and try again."),setTimeout(()=>T(null),5e3)}Te(""),F(!1),be(null)}},[m,r,v,N,Ee,D,se]),$t=a.useCallback(async()=>{if(!m.trim()||N){!m.trim()&&!N&&(T("Write some prose first — then Deepen will enrich it."),setTimeout(()=>T(null),4e3));return}se("Before deepen"),be("deepen"),F(!0),ft(m),Fe(null);try{const t=await fetch(`${S}/memories/story-deepen`,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({current_prose:m,pnos_act:r?.pnos_act||"act_1",chapter_title:r?.title,character_id:D?.id||null,chapter_brief:r?.scene_goal||r?.chapter_notes||"",emotional_state_start:r?.emotional_state_start||"",emotional_state_end:r?.emotional_state_end||"",theme:r?.theme||v?.theme||"",pov:r?.pov||"",characters_present:r?.characters_present||"",tone:r?.tone||v?.tone||"",setting:r?.setting||v?.setting||"",conflict:r?.conflict||v?.conflict||"",stakes:r?.stakes||v?.stakes||""})});if(!t.ok){T(`Deepen failed (${t.status}) — please try again.`),setTimeout(()=>T(null),5e3),F(!1),be(null);return}const s=await t.json();s.prose?(H(s.prose),Q(s.prose.split(/\s+/).filter(Boolean).length),ie(!1)):s.error&&(T(s.error),setTimeout(()=>T(null),5e3))}catch(t){console.error("story-deepen error:",t),T("Connection error — check your server and try again."),setTimeout(()=>T(null),5e3)}F(!1),be(null)},[m,r,N,D,se]),Ls=a.useCallback(async()=>{if(!N){be("nudge"),F(!0),Fe(null);try{const t=await fetch(`${S}/memories/story-nudge`,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({current_prose:m,chapter_title:r?.title,chapter_brief:r?.scene_goal||r?.chapter_notes,pnos_act:r?.pnos_act||"act_1",character_id:D?.id||null,emotional_state_start:r?.emotional_state_start||"",emotional_state_end:r?.emotional_state_end||"",theme:r?.theme||v?.theme||"",pov:r?.pov||"",characters_present:r?.characters_present||"",tone:r?.tone||v?.tone||"",setting:r?.setting||v?.setting||"",conflict:r?.conflict||v?.conflict||"",stakes:r?.stakes||v?.stakes||""})});if(!t.ok){T(`Nudge failed (${t.status}) — please try again.`),setTimeout(()=>T(null),5e3),F(!1),be(null);return}const s=await t.json();s.nudge&&Fe(s.nudge)}catch(t){console.error("story-nudge error:",t),T("Connection error — check your server and try again."),setTimeout(()=>T(null),5e3)}F(!1),be(null)}},[m,r,N,D]),zs=a.useCallback(()=>{Oe!==null&&(H(Oe),Q(Oe.split(/\s+/).filter(Boolean).length),ie(!1),ft(null))},[Oe]),Dt=a.useCallback(async()=>{Vt(!0);try{const s=await(await fetch(`${S}/storyteller/books/${w}`)).json(),o=((s?.book||s).chapters||[]).find(c=>c.id===g);it(o?.lines||[])}catch{}Vt(!1)},[w,g]),as=async t=>{try{await fetch(`${S}/storyteller/lines/${t}`,{method:"PUT",headers:{"Content-Type":"application/json"},body:JSON.stringify({status:"approved"})});const s=de.map(o=>o.id===t?{...o,status:"approved"}:o);it(s);const n=de.find(o=>o.id===t);n&&Es({...n,status:"approved"}),ns(s)}catch{}},Rs=async t=>{try{await fetch(`${S}/storyteller/lines/${t}`,{method:"DELETE"}),it(s=>s.filter(n=>n.id!==t))}catch{}},Is=t=>{St(t.id),Ct(t.text||t.content||"")},Fs=async()=>{try{await fetch(`${S}/storyteller/lines/${kt}`,{method:"PUT",headers:{"Content-Type":"application/json"},body:JSON.stringify({text:Je,content:Je,status:"edited"})});const t=de.map(s=>s.id===kt?{...s,text:Je,content:Je,status:"edited"}:s);it(t),St(null),Ct(""),ns(t)}catch{}},Os=async()=>{const t=de.filter(s=>s.status==="pending");for(const s of t)await as(s.id)},ns=a.useCallback(async t=>{const n=(t||de).filter(c=>c.status==="approved"||c.status==="edited").sort((c,h)=>(c.sort_order??0)-(h.sort_order??0));if(n.length===0)return;const o=n.map(c=>c.text||c.content||"").join(`

`);H(o),Q(o.split(/\s+/).filter(Boolean).length);try{await fetch(`${S}/storyteller/chapters/${g}/save-draft`,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({draft_prose:o})})}catch{}},[de,g]),Gs=a.useCallback(async()=>{Ze(!0);try{await fetch(`${S}/storyteller/chapters/${g}/save-draft`,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({draft_prose:m})});const s=await(await fetch(`${S}/storyteller/books/${w}`)).json(),c=((s?.book||s).chapters||[]).find(y=>y.id===g)?.lines||[],h=c.filter(y=>y.status==="approved"||y.status==="edited"),M=h.length>0?"append":"replace";if(h.length>0){const y=c.filter(G=>G.status==="pending"||G.status==="rejected");for(const G of y)try{await fetch(`${S}/storyteller/lines/${G.id}`,{method:"DELETE"})}catch{}}const x=m.split(/\n\n+/).map(y=>y.trim()).filter(Boolean).map((y,G)=>`LINE ${G+1}
${y}`).join(`

`);await fetch(`${S}/storyteller/chapters/${g}/import`,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({raw_text:x,mode:M})}),D?.id&&m&&fetch(`${S}/storyteller/chapters/${g}/emotional-impact`,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({prose:m,character_id:D.id})}).catch(()=>{}),Ue("review"),await Dt()}catch(t){console.error("sendToReview error:",t)}Ze(!1)},[m,g,w,D,Dt]),Ws=t=>{const s=t.target.value;H(s),Q(s.split(/\s+/).filter(Boolean).length),ie(!1),lt(t.target)},lt=a.useCallback(t=>{!t||window.innerWidth>767||(t.style.height="auto",t.style.height=t.scrollHeight+"px")},[]);a.useEffect(()=>{_t.current&&window.innerWidth<=767&&lt(_t.current)},[m,Ge,lt]);const Us=r?.sections?.length>0&&r.sections.some(t=>["h2","h3","h4"].includes(t.type)),Js=a.useCallback((t,s)=>{It(n=>{const o={...n,[t]:s};dt.current=o;const c=(r?.sections||[]).filter(h=>["h2","h3","h4"].includes(h.type)).map(h=>o[h.id]||"").filter(Boolean).join(`

`);return H(c),Q(c.split(/\s+/).filter(Boolean).length),ie(!1),o})},[r?.sections]),qe=a.useCallback(()=>{Ns(t=>(t?(V(vt.current.toc),ne(vt.current.ctx)):(vt.current={toc:z,ctx:Z},V(!1),ne(!1)),!t))},[z,Z]);a.useEffect(()=>{const t=s=>{if((s.ctrlKey||s.metaKey)&&s.key==="Enter"&&(s.preventDefault(),!ge&&m.trim()&&!N&&Tt()),(s.ctrlKey||s.metaKey)&&s.key==="d"&&(s.preventDefault(),!ge&&m.trim()&&!N&&$t()),(s.ctrlKey||s.metaKey)&&s.key==="s"&&(s.preventDefault(),m&&ze(m)),s.key==="Escape"){if(ge){bs(!1);return}if(at){nt(!1);return}if(jt){Nt(!1);return}if(Ae){qe();return}if(O!==null){fe(null),$e(null);return}if(l){d(null);return}if(ce){Y(!1);return}if(_e){K(null);return}}s.key==="F11"&&(s.preventDefault(),qe()),(s.ctrlKey||s.metaKey)&&s.key==="["&&(s.preventDefault(),Re(-1)),(s.ctrlKey||s.metaKey)&&s.key==="]"&&(s.preventDefault(),Re(1)),(s.ctrlKey||s.metaKey)&&s.key==="b"&&(s.preventDefault(),V(n=>!n))};return window.addEventListener("keydown",t),()=>window.removeEventListener("keydown",t)},[ge,m,N,Ae,at,jt,O,Tt,$t,ze,qe]),a.useEffect(()=>{localStorage.setItem("wm-show-toc",JSON.stringify(z))},[z]),a.useEffect(()=>{localStorage.setItem("wm-show-context",JSON.stringify(Z))},[Z]);const Mt=a.useCallback(async t=>{t!==g&&(m&&await ze(m),W(`/chapter/${w}/${t}`))},[g,w,m,ze,W]),Re=a.useCallback(t=>{const s=u.findIndex(o=>o.id===g);if(s<0)return;const n=u[s+t];n&&Mt(n.id)},[u,g,Mt]),Ks=a.useCallback(async()=>{if(le===null||he===null||le===he){ee(null),ue(null);return}const t=[...u],[s]=t.splice(le,1);t.splice(he,0,s),P(t),ee(null),ue(null);try{await Promise.all(t.map((n,o)=>fetch(`${S}/storyteller/chapters/${n.id}`,{method:"PUT",headers:{"Content-Type":"application/json"},body:JSON.stringify({sort_order:o+1})})))}catch(n){console.error("reorder error",n)}},[u,le,he]),rs=a.useCallback(async()=>{if(!l||!C.trim()){d(null);return}P(t=>t.map(s=>s.id===l?{...s,title:C.trim()}:s)),l===g&&U(t=>({...t,title:C.trim()})),d(null);try{await fetch(`${S}/storyteller/chapters/${l}`,{method:"PUT",headers:{"Content-Type":"application/json"},body:JSON.stringify({title:C.trim()})})}catch(t){console.error("rename error",t)}},[l,C,g]),Hs=a.useCallback(t=>{if(L===t){i(null),p([]);return}i(t);const s=u.find(o=>o.id===t),n=s?.sections&&Array.isArray(s.sections)?s.sections.map(o=>({...o,id:o.id||zt()})):[];p(n)},[L,u]),is=a.useCallback(async t=>{if(L)try{await fetch(`${S}/storyteller/chapters/${L}`,{method:"PUT",headers:{"Content-Type":"application/json"},body:JSON.stringify({sections:t})}),P(s=>s.map(n=>n.id===L?{...n,sections:t}:n)),L===g&&U(s=>({...s,sections:t}))}catch(s){console.error("save sections error",s)}},[L,g]);a.useEffect(()=>{if(!(!L||b.length===0))return clearTimeout(ct.current),ct.current=setTimeout(()=>is(b),1500),()=>clearTimeout(ct.current)},[b,L,is]);const qs=a.useCallback((t="body")=>{const s={id:zt(),type:t,content:""};p(n=>[...n,s]),Rt(!1),setTimeout(()=>{f(s.id),xe("")},50)},[]),os=a.useCallback(()=>{j&&(p(t=>t.map(s=>s.id===j?{...s,content:R}:s)),f(null))},[j,R]),Vs=a.useCallback(t=>{p(s=>s.filter(n=>n.id!==t))},[]),ls=a.useCallback((t,s)=>{p(n=>{const o=n.findIndex(M=>M.id===t);if(o<0)return n;const c=o+s;if(c<0||c>=n.length)return n;const h=[...n];return[h[o],h[c]]=[h[c],h[o]],h})},[]),cs=a.useCallback(async()=>{const t=k.trim()||`Chapter ${u.length+1}`;Y(!1),Ne("");try{const n=await(await fetch(`${S}/storyteller/books/${w}/chapters`,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({title:t,chapter_number:u.length+1,sort_order:u.length+1})})).json(),o=n.chapter||n;P(c=>[...c,o])}catch(s){console.error("add chapter error",s)}},[w,u.length,k]),ae=a.useCallback(async(t,s)=>{U(n=>({...n,[t]:s})),P(n=>n.map(o=>o.id===g?{...o,[t]:s}:o)),K(null);try{await fetch(`${S}/storyteller/chapters/${g}`,{method:"PUT",headers:{"Content-Type":"application/json"},body:JSON.stringify({[t]:s})})}catch(n){console.error("save context field error",n)}},[g]),At=a.useMemo(()=>{const t=u.length,s=u.filter(o=>o.draft_prose?.trim()).length,n=u.reduce((o,c)=>o+(c.draft_prose?c.draft_prose.split(/\s+/).filter(Boolean).length:0),0);return{total:t,written:s,totalWords:n}},[u]);if(E)return e.jsx("div",{className:"wm-load-screen",children:e.jsx(Ys,{variant:"editor"})});const Ve=de.filter(t=>t.status==="approved"||t.status==="edited"),we=de.filter(t=>t.status==="pending");function ds(t,s){const n=kt===t.id,o=t.text||t.content||"";return e.jsxs("div",{className:`wm-review-line wm-review-line--${t.status}${n?" editing":""}`,children:[e.jsx("div",{className:"wm-review-line-content",children:n?e.jsxs(e.Fragment,{children:[e.jsx("textarea",{className:"wm-review-line-edit",value:Je,onChange:c=>Ct(c.target.value),autoFocus:!0}),e.jsxs("div",{className:"wm-review-line-edit-actions",children:[e.jsx("button",{className:"wm-review-save",onClick:Fs,children:"Save"}),e.jsx("button",{className:"wm-review-cancel",onClick:()=>St(null),children:"Cancel"})]})]}):e.jsx("p",{className:`wm-review-line-text${s?" pending":""}`,children:o})}),!n&&e.jsxs("div",{className:"wm-review-line-actions",children:[s&&e.jsx("button",{className:"wm-line-approve",onClick:()=>as(t.id),title:"Approve",children:"✓"}),e.jsx("button",{className:"wm-line-edit",onClick:()=>Is(t),title:"Edit",children:"✎"}),s&&e.jsx("button",{className:"wm-line-reject",onClick:()=>Rs(t.id),title:"Reject",children:"✕"})]})]},t.id)}return e.jsxs("div",{className:`wm-root${Ae?" wm-focus-mode":""}`,children:[Ae&&e.jsx("button",{className:"wm-focus-exit",onClick:qe,title:"Exit focus mode (F11)",children:"✕"}),!$&&e.jsxs("header",{className:"wm-topbar",children:[e.jsx("button",{className:"wm-back-btn",onClick:()=>yt(!0),children:"←"}),e.jsx("button",{className:`wm-sidebar-toggle${z?" active":""}`,onClick:()=>V(t=>!t),title:"Table of Contents (Ctrl+B)",children:"☰"}),e.jsxs("div",{className:"wm-chapter-info",children:[e.jsx("div",{className:"wm-chapter-title",children:r?.title||"Untitled"}),e.jsx("div",{className:"wm-book-title",children:v?.title||v?.character||""})]}),e.jsxs("div",{className:"wm-session-timer",children:[e.jsx("span",{className:"wm-timer-icon",children:"⏱"}),e.jsxs("span",{className:"wm-timer-value",children:[Math.floor(tt/3600)>0&&`${Math.floor(tt/3600)}:`,String(Math.floor(tt%3600/60)).padStart(2,"0"),":",String(tt%60).padStart(2,"0")]})]}),e.jsxs("div",{className:"wm-top-right",children:[e.jsxs("div",{className:"wm-quick-char-wrap",children:[e.jsxs("button",{className:"wm-quick-char-btn",onClick:()=>Le(t=>!t),title:"Quick switch character",children:[e.jsx("span",{children:D?.icon||"👤"}),e.jsx("span",{className:"wm-quick-char-caret",children:rt?"▲":"▼"})]}),rt&&e.jsxs("div",{className:"wm-quick-char-dropdown",children:[e.jsxs("div",{className:`wm-quick-char-option${D?"":" selected"}`,onClick:()=>{We(null),Le(!1)},children:[e.jsx("span",{className:"wm-quick-char-option-icon",children:"—"}),e.jsx("span",{children:"Narrator"})]}),wt.map(t=>e.jsxs("div",{className:`wm-quick-char-option${D?.id===t.id?" selected":""}`,onClick:()=>{We(t),Le(!1)},children:[e.jsx("span",{className:"wm-quick-char-option-icon",children:t.icon||"👤"}),e.jsx("span",{children:t.display_name||t.selected_name})]},t.id))]})]}),re>0&&e.jsxs("div",{className:"wm-word-count",onClick:()=>Nt(t=>!t),title:"Click to set word goal",children:[re,"w",Pe>0&&e.jsxs("span",{className:"wm-goal-fraction",children:[" / ",Pe]})]}),e.jsx("div",{className:"wm-save-status",children:ht?"·· saving":mt?"":"· unsaved"}),e.jsxs("button",{className:`wm-history-btn${at?" active":""}`,onClick:()=>nt(t=>!t),title:`Snapshots (${Be.length})`,children:["📜",Be.length>0&&e.jsx("span",{className:"wm-history-badge",children:Be.length})]}),e.jsx("button",{className:`wm-focus-btn${Ae?" active":""}`,onClick:qe,title:"Focus mode (F11)",children:"⛶"}),e.jsx("button",{className:`wm-sidebar-toggle wm-ctx-toggle${Z?" active":""}`,onClick:()=>ne(t=>!t),title:"Chapter context panel",children:"ℹ"})]})]}),Pe>0&&e.jsxs("div",{className:"wm-goal-bar-wrap",children:[e.jsx("div",{className:"wm-goal-bar",children:e.jsx("div",{className:"wm-goal-fill",style:{width:`${Math.min(100,(re-st.current)/Pe*100)}%`}})}),e.jsxs("span",{className:"wm-goal-label",children:[Math.max(0,re-st.current)," / ",Pe," words this session"]})]}),jt&&e.jsxs("div",{className:"wm-goal-input-wrap",children:[e.jsx("label",{className:"wm-goal-input-label",children:"Session word goal:"}),e.jsx("input",{className:"wm-goal-input",type:"number",min:0,step:50,value:Pe,onChange:t=>{const s=parseInt(t.target.value)||0;Ss(s),localStorage.setItem("wm-word-goal",s)},placeholder:"e.g. 500"}),e.jsx("button",{className:"wm-goal-input-close",onClick:()=>Nt(!1),children:"✓"})]}),e.jsxs("div",{className:"wm-hub-layout",children:[J&&e.jsxs("aside",{className:"wm-toc-sidebar",children:[e.jsxs("div",{className:"wm-toc-header",children:[e.jsx("span",{className:"wm-toc-header-title",children:"Contents"}),e.jsxs("span",{className:"wm-toc-stats",children:[At.written,"/",At.total," · ",At.totalWords.toLocaleString(),"w"]})]}),e.jsx("div",{className:"wm-toc-list",children:u.map((t,s)=>{const n=t.id===g,o=t.draft_prose?t.draft_prose.split(/\s+/).filter(Boolean).length:0,c=L===t.id;t.sections&&Array.isArray(t.sections)&&t.sections.length>0;const h=t.chapter_type||"chapter",M=h==="prologue"?"◈":h==="epilogue"?"◇":h==="interlude"?"~":h==="afterword"?"∗":null,_=t.part_number&&(s===0||t.part_number!==u[s-1]?.part_number);return e.jsxs("div",{className:"wm-toc-chapter-group",children:[_&&e.jsx("div",{className:"wm-toc-part-divider",children:e.jsxs("span",{className:"wm-toc-part-label",children:["Part ",t.part_number,t.part_title?` — ${t.part_title}`:""]})}),e.jsxs("div",{className:`wm-toc-item${n?" current":""}${he===s?" drag-over":""}`,draggable:!0,onDragStart:()=>ee(s),onDragOver:x=>{x.preventDefault(),ue(s)},onDragEnd:Ks,onClick:()=>!l&&Mt(t.id),children:[e.jsx("span",{className:"wm-toc-drag",children:"≡"}),e.jsx("button",{className:`wm-toc-expand${c?" expanded":""}`,onClick:x=>{x.stopPropagation(),Hs(t.id)},title:c?"Collapse sections":"Show sections",children:"▸"}),e.jsx("span",{className:"wm-toc-num",children:t.chapter_number||s+1}),M&&e.jsx("span",{className:"wm-toc-type-badge",title:h,children:M}),l===t.id?e.jsx("input",{className:"wm-toc-edit-input",value:C,onChange:x=>I(x.target.value),onBlur:rs,onKeyDown:x=>{x.key==="Enter"&&rs(),x.key==="Escape"&&d(null)},autoFocus:!0,onClick:x=>x.stopPropagation()}):e.jsx("span",{className:"wm-toc-title",onDoubleClick:x=>{x.stopPropagation(),d(t.id),I(t.title||"")},children:t.title||"Untitled"}),e.jsx("span",{className:"wm-toc-words",children:o>0?`${o}w`:"—"})]}),c&&e.jsxs("div",{className:"wm-toc-sections",children:[b.length===0&&e.jsx("div",{className:"wm-toc-sec-empty",children:"No sections yet"}),b.map(x=>{const y=hs.find(q=>q.type===x.type)||{icon:"?",label:x.type},G=oa.includes(x.type),ye=x.type==="divider";return e.jsxs("div",{className:`wm-toc-sec-item${G?" is-header":""}${ye?" is-divider":""}`,children:[e.jsx("span",{className:"wm-toc-sec-icon",title:y.label,children:y.icon}),ye?e.jsx("span",{className:"wm-toc-sec-divider-line"}):j===x.id?e.jsx("input",{className:"wm-toc-sec-edit",value:R,onChange:q=>xe(q.target.value),onBlur:os,onKeyDown:q=>{q.key==="Enter"&&os(),q.key==="Escape"&&f(null)},placeholder:y.label+"…",autoFocus:!0}):e.jsx("span",{className:"wm-toc-sec-text",onClick:q=>{q.stopPropagation(),f(x.id),xe(x.content||"")},children:x.content||e.jsx("span",{className:"wm-toc-sec-placeholder",children:y.label})}),e.jsxs("div",{className:"wm-toc-sec-actions",children:[e.jsx("button",{onClick:q=>{q.stopPropagation(),ls(x.id,-1)},title:"Move up",children:"↑"}),e.jsx("button",{onClick:q=>{q.stopPropagation(),ls(x.id,1)},title:"Move down",children:"↓"}),e.jsx("button",{className:"wm-toc-sec-del",onClick:q=>{q.stopPropagation(),Vs(x.id)},title:"Delete",children:"×"})]})]},x.id)}),xs&&L===t.id?e.jsx("div",{className:"wm-toc-sec-type-menu",children:hs.map(x=>e.jsxs("button",{className:"wm-toc-sec-type-opt",onClick:()=>qs(x.type),children:[e.jsx("span",{className:"wm-toc-sec-type-icon",children:x.icon})," ",x.label]},x.type))}):e.jsx("button",{className:"wm-toc-sec-add",onClick:x=>{x.stopPropagation(),Rt(!0)},children:"+ Add Section"})]})]},t.id)})}),ce?e.jsx("div",{className:"wm-toc-add-row",children:e.jsx("input",{className:"wm-toc-add-input",value:k,onChange:t=>Ne(t.target.value),onBlur:cs,onKeyDown:t=>{t.key==="Enter"&&cs(),t.key==="Escape"&&Y(!1)},placeholder:`Chapter ${u.length+1}`,autoFocus:!0})}):e.jsx("button",{className:"wm-toc-add-btn",onClick:()=>Y(!0),children:"+ Add Chapter"}),e.jsxs("div",{className:"wm-toc-nav",children:[e.jsxs("button",{className:"wm-toc-nav-btn",disabled:u.findIndex(t=>t.id===g)<=0,onClick:()=>Re(-1),children:["←"," Prev"]}),e.jsxs("button",{className:"wm-toc-nav-btn",disabled:u.findIndex(t=>t.id===g)>=u.length-1,onClick:()=>Re(1),children:["Next ","→"]})]})]}),e.jsxs("div",{className:"wm-main-col",children:[e.jsx("div",{className:"wm-center-tabs",children:us.map(t=>e.jsxs("button",{className:`wm-center-tab${oe===t.id?" wm-center-tab--active":""}`,onClick:()=>Ue(t.id),children:[t.label,t.id==="review"&&we.length>0&&e.jsx("span",{className:"wm-tab-badge",children:we.length})]},t.id))}),Ce&&e.jsxs("div",{className:"wm-mobile-bar",children:[e.jsxs("div",{className:"wm-mob-char-wrap",children:[e.jsxs("button",{className:"wm-mob-char-btn",onClick:()=>Le(t=>!t),children:[e.jsx("span",{className:"wm-mob-char-icon",children:D?.icon||"👤"}),e.jsx("span",{className:"wm-mob-char-name",children:D?.display_name||D?.selected_name||"Narrator"}),e.jsx("span",{className:"wm-mob-char-caret",children:rt?"▲":"▼"})]}),rt&&e.jsxs("div",{className:"wm-mob-char-dropdown",children:[e.jsxs("button",{className:`wm-mob-char-option${D?"":" selected"}`,onClick:()=>{We(null),Le(!1)},children:[e.jsx("span",{className:"wm-mob-char-opt-icon",children:"—"}),"Narrator"]}),wt.map(t=>e.jsxs("button",{className:`wm-mob-char-option${D?.id===t.id?" selected":""}`,onClick:()=>{We(t),Le(!1)},children:[e.jsx("span",{className:"wm-mob-char-opt-icon",children:t.icon||"👤"}),t.display_name||t.selected_name]},t.id))]})]}),u.length>1&&e.jsxs("div",{className:"wm-mob-chapter-nav",children:[e.jsx("button",{className:"wm-mob-nav-btn",disabled:u.findIndex(t=>t.id===g)<=0,onClick:()=>Re(-1),children:"‹"}),e.jsx("span",{className:"wm-mob-nav-label",children:`${u.findIndex(s=>s.id===g)+1}/${u.length}`}),e.jsx("button",{className:"wm-mob-nav-btn",disabled:u.findIndex(t=>t.id===g)>=u.length-1,onClick:()=>Re(1),children:"›"})]}),re>0&&e.jsxs("span",{className:"wm-mob-wc",children:[re,"w"]})]}),oe==="write"&&e.jsxs(e.Fragment,{children:[e.jsx("div",{className:"wm-content-row",children:e.jsxs("div",{className:"wm-prose-wrap",ref:De,children:[e.jsxs("div",{className:"wm-manuscript-page",children:[e.jsx("div",{className:"wm-chapter-opening",children:e.jsx("h2",{className:"wm-chapter-heading",children:r?.title||"Untitled"})}),Us?e.jsx("div",{className:"wm-canvas-sections",children:r.sections.map((t,s)=>{const n=["h2","h3","h4"].includes(t.type),o=t.type==="h2"&&t.content?.trim().toLowerCase()===(r?.title||"").trim().toLowerCase();return e.jsxs("div",{className:"wm-cs-block",children:[t.type==="divider"&&e.jsx("div",{className:"wm-cs-divider",children:e.jsx("span",{className:"wm-cs-divider-line"})}),t.type==="h2"&&!o&&e.jsx("h2",{className:"wm-cs-h2",children:t.content||"Untitled Section"}),t.type==="h3"&&e.jsx("h3",{className:"wm-cs-h3",children:t.content||"Untitled Section"}),t.type==="h4"&&e.jsx("h4",{className:"wm-cs-h4",children:t.content||"Untitled"}),t.type==="quote"&&e.jsx("blockquote",{className:"wm-cs-quote",children:t.content}),t.type==="reflection"&&e.jsx("div",{className:"wm-cs-reflection",children:t.content}),t.type==="body"&&e.jsx("p",{className:"wm-cs-body",children:t.content}),n&&e.jsx("textarea",{className:"wm-prose-area wm-section-prose",value:gs[t.id]||"",onChange:c=>{Js(t.id,c.target.value),lt(c.target)},placeholder:`Write under ${t.content||"this section"}…`,spellCheck:!1,readOnly:N})]},t.id||s)})}):e.jsx("textarea",{className:"wm-prose-area",ref:_t,value:Ge?m?m.trimEnd()+`

`+Ge:Ge:m,onChange:Ws,placeholder:ge?"":"Begin writing…",spellCheck:!1,readOnly:N})]}),Ds&&e.jsxs("div",{className:"wm-ni-panel",children:[e.jsx("div",{className:"wm-ni-panel-header",children:e.jsx("span",{className:"wm-ni-label",children:"Narrative Intelligence"})}),e.jsx(ps,{chapter:r,lines:m.split(/\n\n+/).filter(t=>t.trim()).map((t,s)=>({id:`prose-${s}`,content:t,text:t,status:"approved"})),lineIndex:Qt-1,book:v,characters:Yt})]}),!ge&&m.trim()&&e.jsx("div",{className:`wm-para-float-hint${O!==null?" active":""}`,onClick:()=>{O!==null?(fe(null),$e(null)):fe(0)},title:"Paragraph actions",children:"¶"}),O!==null&&e.jsx("div",{className:"wm-para-overlay",children:m.split(/\n\n+/).map((t,s)=>e.jsxs("div",{className:`wm-para-block${s===O?" selected":""}`,onClick:()=>fe(s===O?null:s),children:[e.jsx("p",{children:t}),s===O&&e.jsxs("div",{className:"wm-para-actions",children:[e.jsx("button",{onClick:n=>{n.stopPropagation(),Et("rewrite")},disabled:N,children:N&&qt==="rewrite"?"Rewriting…":"✎ Rewrite"}),e.jsx("button",{onClick:n=>{n.stopPropagation(),Et("expand")},disabled:N,children:N&&qt==="expand"?"Expanding…":"↔ Expand"}),e.jsx("button",{className:"wm-para-delete",onClick:n=>{n.stopPropagation(),Et("delete")},disabled:N,children:"✗ Delete"}),e.jsx("button",{className:"wm-para-cancel",onClick:n=>{n.stopPropagation(),fe(null),$e(null)},children:"✕"})]})]},s))}),N&&!Ge&&e.jsxs("div",{className:"wm-generating",children:[e.jsxs("div",{className:"wm-generating-dots",children:[e.jsx("span",{className:"wm-generating-dot"}),e.jsx("span",{className:"wm-generating-dot"}),e.jsx("span",{className:"wm-generating-dot"})]}),e.jsx("div",{className:"wm-generating-label",children:Se==="continue"?"continuing your story":Se==="deepen"?"deepening the moment":Se==="nudge"?"thinking":"writing"})]}),Jt&&!N&&e.jsxs("div",{className:"wm-hint",children:[e.jsx("div",{className:"wm-hint-dot"}),e.jsx("div",{className:"wm-hint-text",children:Jt})]})]})}),ke&&Ot&&e.jsx("div",{className:"wm-transcript",children:e.jsx("div",{className:"wm-transcript-text",children:Ot})}),Wt&&!N&&e.jsxs("div",{className:"wm-nudge",children:[e.jsx("div",{className:"wm-nudge-icon",children:"💡"}),e.jsx("div",{className:"wm-nudge-text",children:Wt}),e.jsx("button",{className:"wm-nudge-close",onClick:()=>Fe(null),children:"×"})]}),!ge&&e.jsxs("div",{className:"wm-ai-toolbar",children:[e.jsxs("button",{className:`wm-ai-btn${Se==="continue"?" active":""}`,onClick:Tt,disabled:N,title:m.trim()?"Continue writing":"Generate an opening for this chapter",children:[e.jsx("span",{className:"wm-ai-icon",children:"✨"})," Continue"]}),e.jsxs("button",{className:`wm-ai-btn${Se==="deepen"?" active":""}`,onClick:$t,disabled:N||!m.trim(),title:m.trim()?"Deepen the prose":"Write something first — then Deepen will enrich your text",children:[e.jsx("span",{className:"wm-ai-icon",children:"🔍"})," Deepen"]}),e.jsxs("button",{className:`wm-ai-btn${Se==="nudge"?" active":""}`,onClick:Ls,disabled:N,title:"Get a creative writing prompt",children:[e.jsx("span",{className:"wm-ai-icon",children:"💡"})," Nudge"]}),Oe!==null&&!N&&e.jsxs("button",{className:"wm-ai-btn wm-undo-ai",onClick:zs,children:[e.jsx("span",{className:"wm-ai-icon",children:"↩"})," Undo"]}),e.jsx("button",{className:`wm-len-toggle${Ee==="sentence"?" sentence":""}`,onClick:()=>{ws(t=>{const s=t==="paragraph"?"sentence":"paragraph";return T(s==="sentence"?"Continue will generate 1-2 sentences":"Continue will generate full paragraphs"),setTimeout(()=>T(null),3e3),s})},title:Ee==="sentence"?"Generating one sentence at a time":"Generating full paragraphs",children:Ee==="sentence"?"1 line":"¶ full"}),m.trim()&&e.jsxs("button",{className:`wm-ai-btn wm-para-mode-btn${O!==null?" active":""}`,onClick:()=>{O!==null?(fe(null),$e(null)):fe(0)},title:"Paragraph-level actions",children:[e.jsx("span",{className:"wm-ai-icon",children:"¶"})," Paragraphs"]}),!m.trim()&&e.jsxs("span",{className:"wm-ai-hint",children:["Tap ",e.jsx("strong",{children:"Continue"})," to start writing — or ",e.jsx("strong",{children:"Nudge"})," for a creative prompt"]})]}),at&&e.jsxs("div",{className:"wm-history-panel",children:[e.jsxs("div",{className:"wm-history-header",children:[e.jsx("span",{className:"wm-history-title",children:"Snapshots"}),e.jsx("button",{className:"wm-history-close",onClick:()=>nt(!1),children:"×"})]}),Be.length===0?e.jsx("div",{className:"wm-history-empty",children:"No snapshots yet. Snapshots are taken automatically before each AI action."}):e.jsx("div",{className:"wm-history-list",children:[...Be].reverse().map((t,s)=>{Be.length-1-s;const n=new Date(t.timestamp),o=`${n.getHours()}:${String(n.getMinutes()).padStart(2,"0")}`;return e.jsxs("div",{className:"wm-history-item",children:[e.jsxs("div",{className:"wm-history-item-header",children:[e.jsx("span",{className:"wm-history-item-label",children:t.label}),e.jsxs("span",{className:"wm-history-item-meta",children:[o," · ",t.wordCount,"w"]})]}),e.jsx("div",{className:"wm-history-item-preview",children:t.prose.length>200?t.prose.slice(0,200)+"…":t.prose}),e.jsx("button",{className:"wm-history-restore",onClick:()=>{se("Before restore"),H(t.prose),Q(t.prose.split(/\s+/).filter(Boolean).length),ie(!1),nt(!1)},children:"Restore this version"})]},s)})})]}),ge&&e.jsxs("div",{className:"wm-edit-panel",children:[e.jsx("div",{className:"wm-edit-label",children:"What needs to change?"}),e.jsxs("div",{className:"wm-edit-row",children:[e.jsx("textarea",{className:"wm-edit-input",value:Me,onChange:t=>gt(t.target.value),placeholder:"That part is right but she wouldn't say it that way...",rows:3}),e.jsx("button",{className:"wm-edit-mic-btn",onPointerDown:As,onPointerUp:Ps,children:fs?e.jsx("span",{className:"wm-mic-active-ring",children:"🎙"}):"🎙"})]}),e.jsx("button",{className:"wm-apply-btn",style:{opacity:Me.trim()?1:.35},onClick:Bs,disabled:!Me.trim()||N,children:N?"Rewriting…":"Apply →"})]}),Gt&&e.jsx("div",{className:"wm-mic-error",children:Gt}),!ge&&e.jsxs("div",{className:"wm-bottom-bar",children:[e.jsx("button",{className:`wm-mic-btn${ke?" listening":""}`,onClick:Ms,disabled:N,children:e.jsxs("svg",{width:"20",height:"20",viewBox:"0 0 28 28",fill:"none",children:[e.jsx("rect",{x:"9",y:"3",width:"10",height:"16",rx:"5",fill:ke?"#F5F0E8":"#1a1a1a"}),e.jsx("path",{d:"M5 14c0 5 3.5 9 9 9s9-4 9-9",stroke:ke?"#F5F0E8":"#1a1a1a",strokeWidth:"2",strokeLinecap:"round",fill:"none"}),e.jsx("line",{x1:"14",y1:"23",x2:"14",y2:"26",stroke:ke?"#F5F0E8":"#1a1a1a",strokeWidth:"2",strokeLinecap:"round"})]})}),e.jsx("div",{className:"wm-bottom-hint",children:ke?"Tap mic to stop & write":N?Se==="continue"?"Continuing…":Se==="deepen"?"Deepening…":"Writing your story…":m?"Tap mic to speak — or use AI tools above":"Tap mic to speak, or type and use AI tools"}),m.length>20&&e.jsx("button",{className:"wm-send-btn",onClick:Gs,disabled:ht,children:ht?"…":"→ Review"})]})]}),oe==="review"&&e.jsxs("div",{className:"wm-review-tab",children:[e.jsxs("div",{className:"wm-review-header",children:[e.jsxs("button",{className:"wm-review-back-btn",onClick:()=>Ue("write"),children:["←"," Back to Write"]}),e.jsxs("div",{className:"wm-review-stats",children:[e.jsxs("span",{className:"wm-review-stat approved",children:[Ve.length," approved"]}),we.length>0&&e.jsxs("span",{className:"wm-review-stat pending",children:[we.length," pending"]}),e.jsxs("span",{className:"wm-review-stat total",children:[de.length," total"]})]}),we.length>0&&e.jsxs("button",{className:"wm-approve-all-btn",onClick:Os,children:["Approve all (",we.length,")"]})]}),Ts?e.jsxs("div",{className:"wm-review-loading",children:["Loading lines","…"]}):de.length===0?e.jsxs("div",{className:"wm-review-empty",children:[e.jsx("div",{className:"wm-review-empty-icon",children:"◌"}),e.jsxs("div",{className:"wm-review-empty-text",children:["No lines yet. Write in the Write tab and click ","→"," Review to send them here."]}),e.jsxs("button",{className:"wm-review-go-write",onClick:()=>Ue("write"),children:["Go to Write tab ","→"]})]}):e.jsxs("div",{className:"wm-review-manuscript",children:[Ve.map((t,s)=>e.jsxs("div",{children:[ds(t,!1),(s+1)%5===0&&s<Ve.length-1&&e.jsx("div",{className:"wm-ni-inline",children:e.jsx(ps,{chapter:r,lines:Ve.slice(Math.max(0,s-4),s+1),lineIndex:s,book:v,characters:Yt})})]},t.id)),e.jsx(ta,{chapter:r,lines:Ve,book:v,triggerLine:_s}),we.length>0&&e.jsxs("div",{className:"wm-pending-section",children:[e.jsxs("div",{className:"wm-pending-label",children:[we.length," pending"]}),we.map(t=>ds(t,!0))]})]})]}),oe==="structure"&&e.jsx("div",{className:"wm-panel-tab",children:e.jsx(ia,{bookId:w,allChapters:u,onChapterUpdate:(t,s)=>{P(n=>n.map(o=>o.id===t?{...o,...s}:o))},onReloadChapters:es})}),oe==="scenes"&&e.jsx("div",{className:"wm-panel-tab",children:e.jsx(ra,{bookId:w,chapters:u,onChaptersChange:es,book:v})}),oe==="memory"&&e.jsx("div",{className:"wm-panel-tab",children:e.jsx(sa,{bookId:w})}),oe==="lala"&&e.jsx("div",{className:"wm-panel-tab",children:e.jsx(aa,{bookId:w})}),oe==="export"&&e.jsx("div",{className:"wm-panel-tab",children:e.jsx(na,{bookId:w})})]}),je&&e.jsxs("aside",{className:"wm-context-panel",children:[e.jsx("div",{className:"wm-ctx-header",children:e.jsxs("div",{className:"wm-ctx-tabs",children:[e.jsx("button",{className:`wm-ctx-tab${Xe==="plan"?" wm-ctx-tab--active":""}`,onClick:()=>pt("plan"),children:"Chapter Plan"}),e.jsxs("button",{className:`wm-ctx-tab${Xe==="ai-writer"?" wm-ctx-tab--active":""}`,onClick:()=>pt("ai-writer"),children:["✦"," Write"]})]})}),Xe==="ai-writer"&&e.jsx(Zs,{chapterId:g,bookId:w,selectedCharacter:D,characters:wt,onSelectCharacter:We,currentProse:m,chapterContext:{scene_goal:r?.scene_goal,theme:r?.theme,emotional_arc_start:r?.emotional_state_start,emotional_arc_end:r?.emotional_state_end,pov:r?.pov},onInsert:t=>{H(s=>s?s+`

`+t:t)}}),Xe==="plan"&&e.jsxs(e.Fragment,{children:[e.jsxs("div",{className:"wm-ctx-field",children:[e.jsx("label",{className:"wm-ctx-label",children:"Scene Goal"}),_e==="scene_goal"?e.jsx("textarea",{className:"wm-ctx-input",value:B,onChange:t=>te(t.target.value),onBlur:()=>ae("scene_goal",B),onKeyDown:t=>{t.key==="Enter"&&!t.shiftKey&&(t.preventDefault(),ae("scene_goal",B)),t.key==="Escape"&&K(null)},rows:3,autoFocus:!0}):e.jsx("div",{className:"wm-ctx-value",onClick:()=>{K("scene_goal"),te(r?.scene_goal||"")},title:"Click to edit",children:r?.scene_goal||e.jsx("span",{className:"wm-ctx-empty",children:"What happens in this chapter?"})})]}),e.jsxs("div",{className:"wm-ctx-field",children:[e.jsx("label",{className:"wm-ctx-label",children:"Theme"}),_e==="theme"?e.jsx("input",{className:"wm-ctx-input",value:B,onChange:t=>te(t.target.value),onBlur:()=>ae("theme",B),onKeyDown:t=>{t.key==="Enter"&&ae("theme",B),t.key==="Escape"&&K(null)},autoFocus:!0}):e.jsx("div",{className:"wm-ctx-value",onClick:()=>{K("theme"),te(r?.theme||"")},children:r?.theme||e.jsx("span",{className:"wm-ctx-empty",children:"Central theme"})})]}),e.jsxs("div",{className:"wm-ctx-field",children:[e.jsx("label",{className:"wm-ctx-label",children:"Emotional Arc"}),e.jsxs("div",{className:"wm-ctx-arc",children:[_e==="emotional_state_start"?e.jsx("input",{className:"wm-ctx-input wm-ctx-input-sm",value:B,onChange:t=>te(t.target.value),onBlur:()=>ae("emotional_state_start",B),onKeyDown:t=>{t.key==="Enter"&&ae("emotional_state_start",B),t.key==="Escape"&&K(null)},placeholder:"Start",autoFocus:!0}):e.jsx("span",{className:"wm-ctx-arc-point",onClick:()=>{K("emotional_state_start"),te(r?.emotional_state_start||"")},children:r?.emotional_state_start||"Start"}),e.jsx("span",{className:"wm-ctx-arc-arrow",children:"→"}),_e==="emotional_state_end"?e.jsx("input",{className:"wm-ctx-input wm-ctx-input-sm",value:B,onChange:t=>te(t.target.value),onBlur:()=>ae("emotional_state_end",B),onKeyDown:t=>{t.key==="Enter"&&ae("emotional_state_end",B),t.key==="Escape"&&K(null)},placeholder:"End",autoFocus:!0}):e.jsx("span",{className:"wm-ctx-arc-point",onClick:()=>{K("emotional_state_end"),te(r?.emotional_state_end||"")},children:r?.emotional_state_end||"End"})]})]}),e.jsxs("div",{className:"wm-ctx-field",children:[e.jsx("label",{className:"wm-ctx-label",children:"POV"}),_e==="pov"?e.jsx("input",{className:"wm-ctx-input",value:B,onChange:t=>te(t.target.value),onBlur:()=>ae("pov",B),onKeyDown:t=>{t.key==="Enter"&&ae("pov",B),t.key==="Escape"&&K(null)},autoFocus:!0}):e.jsx("div",{className:"wm-ctx-value",onClick:()=>{K("pov"),te(r?.pov||"")},children:r?.pov||e.jsx("span",{className:"wm-ctx-empty",children:"Perspective"})})]}),e.jsxs("div",{className:"wm-ctx-field",children:[e.jsx("label",{className:"wm-ctx-label",children:"Notes"}),_e==="chapter_notes"?e.jsx("textarea",{className:"wm-ctx-input",value:B,onChange:t=>te(t.target.value),onBlur:()=>ae("chapter_notes",B),onKeyDown:t=>{t.key==="Enter"&&!t.shiftKey&&(t.preventDefault(),ae("chapter_notes",B)),t.key==="Escape"&&K(null)},rows:4,autoFocus:!0}):e.jsx("div",{className:"wm-ctx-value wm-ctx-notes",onClick:()=>{K("chapter_notes"),te(r?.chapter_notes||"")},children:r?.chapter_notes||e.jsx("span",{className:"wm-ctx-empty",children:"Reminders, ideas, references…"})})]}),Ie&&e.jsxs("div",{className:"wm-ctx-prev",children:[e.jsxs("label",{className:"wm-ctx-label",children:["Previous: ",Ie.title]}),e.jsxs("div",{className:"wm-ctx-prev-stats",children:[Ie.wordCount.toLocaleString()," words"]}),Ie.excerpt?e.jsxs("div",{className:"wm-ctx-prev-excerpt",children:["“",Ie.excerpt,"”"]}):e.jsx("div",{className:"wm-ctx-prev-excerpt wm-ctx-empty",children:"Not yet written"})]}),e.jsxs("button",{className:"wm-ctx-structure-link",onClick:()=>{z||V(!0),i(t=>{if(t!==g){const s=u.find(o=>o.id===g),n=s?.sections&&Array.isArray(s.sections)?s.sections.map(o=>({...o,id:o.id||zt()})):[];p(n)}return g})},children:["☰"," Show Chapter Structure"]})]})]})]}),vs&&e.jsx("div",{className:"wm-modal-overlay",onClick:()=>yt(!1),children:e.jsxs("div",{className:"wm-modal",onClick:t=>t.stopPropagation(),children:[e.jsx("div",{className:"wm-modal-title",children:"Leave Write Mode?"}),e.jsx("div",{className:"wm-modal-sub",children:m?"Your draft is saved. You can come back.":"Nothing written yet."}),e.jsxs("div",{className:"wm-modal-btns",children:[e.jsx("button",{className:"wm-modal-cancel",onClick:()=>yt(!1),children:"Stay"}),e.jsx("button",{className:"wm-modal-leave",onClick:async()=>{m&&await ze(m),W(`/book/${w}`)},children:m?"Save & Leave":"Leave"})]})]})})]})}export{ga as default};
