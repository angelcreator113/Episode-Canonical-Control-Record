import{j as e,L as ta}from"./index-nYtRUF3W.js";import{b as a,k as sa,u as aa}from"./react-vendor-Bbt6Sxdk.js";import{M as na,N as xs,C as ra,a as ia,L as oa,E as la}from"./ExportPanel-2OWugANJ.js";import"./pdf-vendor-Btc3-hiy.js";const ca=[{id:"continue",icon:"→",label:"Continue",sub:"Write what happens next in their voice",endpoint:"/api/v1/memories/ai-writer-action",action:"continue"},{id:"dialogue",icon:"“",label:"Their next line",sub:"What would they say right now",endpoint:"/api/v1/memories/ai-writer-action",action:"dialogue"},{id:"interior",icon:"◌",label:"Interior monologue",sub:"What they are thinking but not saying",endpoint:"/api/v1/memories/ai-writer-action",action:"interior"},{id:"reaction",icon:"↯",label:"Their reaction",sub:"How they respond to what just happened",endpoint:"/api/v1/memories/ai-writer-action",action:"reaction"},{id:"lala",icon:"✦",label:"Lala moment",sub:"The intrusive thought she would never post",endpoint:"/api/v1/memories/ai-writer-action",action:"lala",onlyFor:["special"]}],gs={pressure:"#B85C38",mirror:"#9B7FD4",support:"#4A9B6F",shadow:"#E08C3A",special:"#B8962E"};function da({chapterId:A,bookId:B,selectedCharacter:g,currentProse:f,chapterContext:H,onInsert:fe,characters:be=[],onSelectCharacter:oe}){const[r,F]=a.useState(null),[w,W]=a.useState(null),[x,E]=a.useState(null),[j,Y]=a.useState(!1),[I,R]=a.useState(null),[te,U]=a.useState(!1),O=a.useRef(!1),V=gs[g?.type]||"#B8962E",re=g?.selected_name||g?.name;a.useEffect(()=>{W(null),E(null),F(null),R(null),U(!1)},[g?.id]);const J=ca.filter(p=>!p.onlyFor||p.onlyFor.includes(g?.type));async function le(p,P=!1){if(!g)return;F(p.id),P||W(null),O.current=P,E(null),R(null),Y(!0),U(!1);const ce=f?f.slice(-600):"",Q={chapter_id:A,book_id:B,character_id:g.id,character:{name:re,type:g.type,role:g.role,belief_pressured:g.belief_pressured,emotional_function:g.emotional_function,writer_notes:g.writer_notes},recent_prose:ce,chapter_context:H,action:p.action||p.id,length:"paragraph",...P&&{retry_hint:`v${Date.now()}-${Math.random().toString(36).slice(2,8)}`}};try{const K=await(await fetch(p.endpoint,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(Q)})).json(),L=K.content||K.prose||K.nudge||K.continuation||K.text||K.result||K.suggestion||"";L?(W(L),E(L)):(O.current||W(null),R("No content returned — try a different action or add more prose first."))}catch{O.current||W(null),R("Generation failed. Check your connection and try again.")}Y(!1)}function he(){const p=x||w;p&&(fe?.(p),W(null),E(null),F(null))}function l(){W(null),E(null),F(null)}function d(){const p=x||w;p&&navigator.clipboard.writeText(p).then(()=>{U(!0),setTimeout(()=>U(!1),1800)})}return g?e.jsxs("div",{style:k.root,children:[e.jsxs("div",{style:k.charHeader,children:[e.jsxs("div",{style:k.charHeaderTop,children:[e.jsxs("div",{children:[e.jsx("div",{style:{...k.charType,color:V},children:g.type}),e.jsx("div",{style:k.charName,children:re})]}),e.jsx("button",{style:k.changeCharBtn,onClick:()=>oe?.(null),title:"Switch to a different character",children:"↻ Change"})]}),g.belief_pressured&&e.jsxs("div",{style:k.charBelief,children:["“",g.belief_pressured,"”"]})]}),!w&&e.jsx("div",{style:k.actions,children:J.map(p=>e.jsxs("button",{style:{...k.actionBtn,background:r===p.id&&j?`${V}10`:"transparent",borderColor:r===p.id?V:"rgba(28,24,20,0.1)",opacity:j&&r!==p.id?.4:1},onClick:()=>le(p),disabled:j,children:[e.jsx("span",{style:{...k.actionIcon,color:V},children:p.icon}),e.jsxs("div",{style:k.actionText,children:[e.jsxs("div",{style:k.actionLabel,children:[p.label,j&&r===p.id&&e.jsxs("span",{style:k.spinner,children:[" ","◌"]})]}),e.jsx("div",{style:k.actionSub,children:p.sub})]})]},p.id))}),w&&e.jsxs("div",{style:k.resultPanel,children:[e.jsxs("div",{style:k.resultHeader,children:[e.jsx("div",{style:{...k.resultAction,color:V},children:J.find(p=>p.id===r)?.label||"Generated"}),e.jsx("button",{style:k.discardBtn,onClick:l,children:"✕"})]}),e.jsx("textarea",{style:k.resultText,value:x??w??"",onChange:p=>E(p.target.value),rows:6,placeholder:"Edit before inserting…"}),j&&e.jsx("div",{style:k.retryLoading,children:"Generating new version…"}),e.jsxs("div",{style:k.resultActions,children:[e.jsx("button",{style:{...k.insertBtn,background:V,opacity:j?.5:1},onClick:he,disabled:j,children:"Insert into manuscript"}),e.jsxs("div",{style:k.resultRow,children:[e.jsx("button",{style:{...k.tryAgainBtn,opacity:j?.5:1},disabled:j,onClick:()=>{const p=J.find(P=>P.id===r);p&&le(p,!0)},children:j?"◌ Generating…":"↻ Try again"}),e.jsx("button",{style:k.copyBtn,onClick:d,children:te?"✓ Copied":"📋 Copy"})]})]})]}),I&&e.jsx("div",{style:k.error,children:I})]}):e.jsxs("div",{style:k.empty,children:[e.jsx("div",{style:k.emptyIcon,children:"◈"}),e.jsx("div",{style:k.emptyText,children:"Pick a character to write in their voice."}),be.length>0?e.jsx("div",{style:k.charList,children:be.map(p=>e.jsxs("button",{style:k.charOption,onClick:()=>oe?.(p),children:[e.jsx("span",{style:k.charOptionIcon,children:p.icon||"👤"}),e.jsx("span",{style:k.charOptionName,children:p.display_name||p.selected_name||p.name}),p.type&&e.jsx("span",{style:{...k.charOptionType,color:gs[p.type]||"#B8962E"},children:p.type})]},p.id))}):e.jsx("div",{style:k.emptyHint,children:"No characters loaded yet."})]})}const pt="#1C1814",$e="rgba(28,24,20,0.5)",zt="rgba(28,24,20,0.25)",pa="#FAF7F0",k={root:{display:"flex",flexDirection:"column",flex:1,minHeight:0,overflow:"hidden"},empty:{display:"flex",flexDirection:"column",alignItems:"center",justifyContent:"flex-start",padding:"18px 12px",gap:10,textAlign:"center",flex:1,overflowY:"auto"},emptyIcon:{fontSize:22,color:zt},emptyText:{fontFamily:"'Lora', Georgia, serif",fontStyle:"italic",fontSize:12,color:$e,lineHeight:1.6,maxWidth:200},emptyHint:{fontFamily:"'DM Mono', monospace",fontSize:9,color:zt,letterSpacing:"0.06em"},charList:{display:"flex",flexDirection:"column",gap:4,width:"100%",overflowY:"auto",marginTop:4,flex:1,minHeight:0},charOption:{display:"flex",alignItems:"center",gap:8,padding:"8px 12px",background:"transparent",border:"1px solid rgba(28,24,20,0.1)",borderRadius:6,cursor:"pointer",textAlign:"left",transition:"background 0.15s, border-color 0.15s"},charOptionIcon:{fontSize:16,flexShrink:0},charOptionName:{flex:1,fontFamily:"'DM Mono', monospace",fontSize:11,color:pt,letterSpacing:"0.02em"},charOptionType:{fontSize:7,letterSpacing:"0.12em",textTransform:"uppercase",fontFamily:"'DM Mono', monospace"},charHeader:{padding:"10px 14px",borderBottom:"1px solid rgba(28,24,20,0.08)"},charHeaderTop:{display:"flex",justifyContent:"space-between",alignItems:"flex-start",gap:8},changeCharBtn:{background:"none",border:"1px solid rgba(28,24,20,0.12)",borderRadius:4,padding:"3px 8px",fontSize:9,color:$e,cursor:"pointer",fontFamily:"'DM Mono', monospace",letterSpacing:"0.04em",whiteSpace:"nowrap",flexShrink:0,marginTop:2,transition:"color 0.15s, border-color 0.15s"},charType:{fontSize:8,letterSpacing:"0.12em",marginBottom:3,fontFamily:"'DM Mono', monospace",textTransform:"uppercase"},charName:{fontFamily:"'Cormorant Garamond', Georgia, serif",fontSize:15,color:pt,marginBottom:3},charBelief:{fontFamily:"'Lora', Georgia, serif",fontStyle:"italic",fontSize:10,color:$e,lineHeight:1.5},actions:{display:"flex",flexDirection:"column",padding:"8px 0",overflowY:"auto",flex:1},actionBtn:{display:"flex",gap:10,padding:"10px 14px",border:"none",borderLeft:"2px solid",cursor:"pointer",textAlign:"left",transition:"all 0.12s ease",marginBottom:1},actionIcon:{fontSize:16,lineHeight:1,flexShrink:0,marginTop:2,fontFamily:"'Cormorant Garamond', Georgia, serif",width:18,textAlign:"center"},actionText:{flex:1},actionLabel:{fontSize:11,color:pt,letterSpacing:"0.02em",marginBottom:2,fontFamily:"'DM Mono', monospace"},actionSub:{fontSize:9,color:$e,lineHeight:1.4,fontFamily:"'Lora', Georgia, serif",fontStyle:"italic"},spinner:{opacity:.5},resultPanel:{flex:1,display:"flex",flexDirection:"column",padding:"12px 14px",gap:10,overflowY:"auto"},resultHeader:{display:"flex",justifyContent:"space-between",alignItems:"center"},resultAction:{fontSize:8,letterSpacing:"0.15em",fontFamily:"'DM Mono', monospace"},discardBtn:{background:"none",border:"none",color:zt,fontSize:12,cursor:"pointer",padding:"2px 4px"},resultText:{fontFamily:"'Lora', Georgia, serif",fontStyle:"italic",fontSize:13,color:pt,lineHeight:1.8,flex:1,padding:"10px 12px",background:"rgba(28,24,20,0.03)",borderRadius:3,border:"1px solid rgba(28,24,20,0.08)",resize:"vertical",minHeight:80,outline:"none",width:"100%",boxSizing:"border-box"},retryLoading:{fontFamily:"'DM Mono', monospace",fontSize:9,color:$e,letterSpacing:"0.06em",fontStyle:"italic",padding:"2px 0"},resultActions:{display:"flex",flexDirection:"column",gap:6},insertBtn:{border:"none",borderRadius:3,padding:"10px",color:pa,fontSize:9,letterSpacing:"0.1em",cursor:"pointer",fontFamily:"'DM Mono', monospace"},tryAgainBtn:{background:"none",border:"1px solid rgba(28,24,20,0.1)",borderRadius:3,padding:"8px",color:$e,fontSize:9,letterSpacing:"0.08em",cursor:"pointer",fontFamily:"'DM Mono', monospace",flex:1},resultRow:{display:"flex",gap:6},copyBtn:{background:"none",border:"1px solid rgba(28,24,20,0.1)",borderRadius:3,padding:"8px 10px",color:$e,fontSize:9,letterSpacing:"0.08em",cursor:"pointer",fontFamily:"'DM Mono', monospace",whiteSpace:"nowrap"},error:{padding:"10px 14px",fontSize:10,color:"#B85C38",fontStyle:"italic",fontFamily:"'Lora', Georgia, serif"}},Xe="/api/v1",Ze=()=>{const A=localStorage.getItem("token")||sessionStorage.getItem("token");return{"Content-Type":"application/json",...A?{Authorization:`Bearer ${A}`}:{}}};function ma({bookId:A,chapters:B=[],onChaptersChange:g,book:f}){const[H,fe]=a.useState({}),[be,oe]=a.useState(null),[r,F]=a.useState(""),[w,W]=a.useState(null),[x,E]=a.useState(""),[j,Y]=a.useState({}),[I,R]=a.useState({}),[te,U]=a.useState(!1),[O,V]=a.useState(null),[re,J]=a.useState(null),le=i=>fe(y=>({...y,[i]:!y[i]})),he=B.map(i=>{const y=Array.isArray(i.sections)?i.sections:[],m=y.filter(C=>C.type==="h3");return{...i,scenes:m,allSections:y}}),l=he.reduce((i,y)=>i+y.scenes.length,0),d=a.useCallback(async(i,y)=>{const m=y||r;if(!m?.trim())return;const C=B.find(we=>we.id===i);if(!C)return;const v=Array.isArray(C.sections)?[...C.sections]:[],q={id:`sec_${Date.now()}_${Math.random().toString(36).slice(2,8)}`,type:"h3",content:m.trim(),prose:""};v.push(q);try{await fetch(`${Xe}/storyteller/chapters/${i}`,{method:"PUT",headers:Ze(),body:JSON.stringify({sections:v})}),g&&g()}catch(we){console.error("Add scene error:",we)}oe(null),F("")},[r,B,g]),p=a.useCallback(async(i,y,m)=>{const C=B.find(q=>q.id===i);if(!C)return;const v=(Array.isArray(C.sections)?C.sections:[]).map(q=>q.id===y?{...q,content:m}:q);try{await fetch(`${Xe}/storyteller/chapters/${i}`,{method:"PUT",headers:Ze(),body:JSON.stringify({sections:v})}),g&&g()}catch(q){console.error("Rename scene error:",q)}W(null)},[B,g]),P=a.useCallback(async(i,y)=>{const m=B.find(v=>v.id===i);if(!m)return;const C=(Array.isArray(m.sections)?m.sections:[]).filter(v=>v.id!==y);try{await fetch(`${Xe}/storyteller/chapters/${i}`,{method:"PUT",headers:Ze(),body:JSON.stringify({sections:C})}),g&&g()}catch(v){console.error("Delete scene error:",v)}},[B,g]),ce=a.useCallback(async i=>{Y(y=>({...y,[i.id]:!0})),J(null);try{const y=(Array.isArray(i.sections)?i.sections:[]).filter(v=>v.type==="h3").map(v=>({content:v.content,title:v.content})),m=await fetch(`${Xe}/memories/scene-planner`,{method:"POST",headers:Ze(),body:JSON.stringify({book_id:A,chapter_id:i.id,chapter_title:i.title,chapter_type:i.chapter_type||"chapter",existing_scenes:y,draft_prose:i.draft_prose||"",book_title:f?.title||"",book_description:f?.description||"",all_chapters:B.map(v=>({id:v.id,title:v.title,chapter_type:v.chapter_type,scenes:(Array.isArray(v.sections)?v.sections:[]).filter(q=>q.type==="h3")})),theme:i.theme||"",scene_goal:i.scene_goal||""})}),C=await m.json();if(!m.ok)throw new Error(C.error||"AI request failed");R(v=>({...v,[i.id]:C.suggestions||[]}))}catch(y){console.error("AI scene planner error:",y),J(y.message)}finally{Y(y=>({...y,[i.id]:!1}))}},[A,B,f,g]),Q=a.useCallback(async()=>{U(!0),J(null);try{const i=await fetch(`${Xe}/memories/books/${A}/scenes`,{headers:Ze()}),y=await i.json();if(!i.ok)throw new Error(y.error||"AI request failed");V(y.scenes||y)}catch(i){console.error("Book AI scenes error:",i),J(i.message)}finally{U(!1)}},[A]),S=a.useCallback(async(i,y)=>{await d(i,y.title),R(m=>({...m,[i]:(m[i]||[]).filter(C=>C.title!==y.title)}))},[d]),K=a.useCallback(async i=>{const y=i.chapter_id?B.find(m=>m.id===i.chapter_id):B[0];y&&(await d(y.id,i.title),V(m=>m?m.filter(C=>C.title!==i.title):null))},[B,d]),L=i=>i==="beginning"?"▶":i==="end"?"◀":"◆";return e.jsxs("div",{className:"scenes-panel",children:[e.jsxs("div",{className:"scenes-panel-header",children:[e.jsxs("div",{children:[e.jsx("h3",{className:"scenes-panel-title",children:"Scenes Overview"}),e.jsxs("span",{className:"scenes-panel-count",children:[l," scenes across ",B.length," chapters"]})]}),e.jsx("button",{className:"scenes-panel-ai-book-btn",onClick:Q,disabled:te,title:"AI analyzes your entire book and suggests scenes that would strengthen the arc",children:te?"⧖ Thinking…":"✨ AI Scene Architect"})]}),re&&e.jsxs("div",{className:"scenes-panel-ai-error",children:[e.jsxs("span",{children:["⚠"," ",re]}),e.jsx("button",{onClick:()=>J(null),children:"×"})]}),O&&O.length>0&&e.jsxs("div",{className:"scenes-panel-ai-book-results",children:[e.jsxs("div",{className:"scenes-panel-ai-book-label",children:["✨"," AI Suggested Scenes for Your Book"]}),O.map((i,y)=>e.jsxs("div",{className:"scenes-panel-ai-card",children:[e.jsxs("div",{className:"scenes-panel-ai-card-head",children:[e.jsx("span",{className:"scenes-panel-ai-card-title",children:i.title}),i.chapter_hint&&e.jsx("span",{className:"scenes-panel-ai-card-ch",children:i.chapter_hint})]}),e.jsx("p",{className:"scenes-panel-ai-card-desc",children:i.description}),i.reason&&e.jsxs("p",{className:"scenes-panel-ai-card-reason",children:[e.jsx("span",{className:"scenes-panel-ai-card-reason-label",children:"Why:"})," ",i.reason]}),i.characters&&i.characters.length>0&&e.jsx("div",{className:"scenes-panel-ai-card-chars",children:i.characters.map(m=>e.jsx("span",{className:"scenes-panel-ai-char-tag",children:m},m))}),e.jsxs("div",{className:"scenes-panel-ai-card-actions",children:[e.jsxs("button",{className:"scenes-panel-ai-accept",onClick:()=>K(i),title:"Add this scene to the chapter",children:["✓"," Add Scene"]}),e.jsx("button",{className:"scenes-panel-ai-dismiss",onClick:()=>V(m=>m.filter((C,v)=>v!==y)),title:"Dismiss",children:"Dismiss"})]})]},y)),e.jsx("button",{className:"scenes-panel-ai-clear",onClick:()=>V(null),children:"Clear all suggestions"})]}),he.length===0?e.jsx("div",{className:"scenes-panel-empty",children:e.jsx("p",{children:"No chapters yet. Create chapters to start adding scenes."})}):e.jsx("div",{className:"scenes-panel-list",children:he.map((i,y)=>e.jsxs("div",{className:"scenes-panel-chapter",children:[e.jsxs("button",{className:`scenes-panel-chapter-btn${H[i.id]?" expanded":""}`,onClick:()=>le(i.id),children:[e.jsxs("span",{className:"scenes-panel-ch-num",children:["Ch. ",i.chapter_number||y+1]}),i.chapter_type&&i.chapter_type!=="chapter"&&e.jsx("span",{className:"scenes-panel-ch-type",children:i.chapter_type}),e.jsx("span",{className:"scenes-panel-ch-title",children:i.title||"Untitled"}),e.jsxs("span",{className:"scenes-panel-ch-count",children:[i.scenes.length," scene",i.scenes.length!==1?"s":""]}),e.jsx("span",{className:"scenes-panel-ch-arrow",children:H[i.id]?"▾":"▸"})]}),H[i.id]&&e.jsxs("div",{className:"scenes-panel-scenes",children:[i.scenes.length===0?e.jsx("div",{className:"scenes-panel-no-scenes",children:"No scenes defined"}):i.scenes.map((m,C)=>e.jsxs("div",{className:"scenes-panel-scene",children:[e.jsx("span",{className:"scenes-panel-scene-num",children:C+1}),e.jsx("span",{className:"scenes-panel-scene-dinkus",children:"✦"}),w&&w.chId===i.id&&w.secId===m.id?e.jsx("input",{className:"scenes-panel-scene-edit",value:x,onChange:v=>E(v.target.value),onBlur:()=>p(i.id,m.id,x),onKeyDown:v=>{v.key==="Enter"&&p(i.id,m.id,x),v.key==="Escape"&&W(null)},autoFocus:!0}):e.jsx("span",{className:"scenes-panel-scene-title",onDoubleClick:()=>{W({chId:i.id,secId:m.id}),E(m.content||"")},title:"Double-click to rename",children:m.content||"Untitled Scene"}),e.jsx("button",{className:"scenes-panel-scene-del",onClick:()=>P(i.id,m.id),title:"Delete scene",children:"×"})]},m.id||C)),be===i.id?e.jsxs("div",{className:"scenes-panel-add-row",children:[e.jsx("input",{className:"scenes-panel-add-input",value:r,onChange:m=>F(m.target.value),onKeyDown:m=>{m.key==="Enter"&&d(i.id),m.key==="Escape"&&(oe(null),F(""))},placeholder:"Scene title…",autoFocus:!0}),e.jsx("button",{className:"scenes-panel-add-confirm",onClick:()=>d(i.id),children:"✓"}),e.jsx("button",{className:"scenes-panel-add-cancel",onClick:()=>{oe(null),F("")},children:"×"})]}):e.jsxs("div",{className:"scenes-panel-add-row-buttons",children:[e.jsx("button",{className:"scenes-panel-add-btn",onClick:()=>{oe(i.id),F("")},children:"+ Add Scene"}),e.jsx("button",{className:"scenes-panel-ai-plan-btn",onClick:()=>ce(i),disabled:j[i.id],title:"AI reads your chapter and suggests scenes",children:j[i.id]?"⧖ Planning…":"✨ AI Plan Scenes"})]}),I[i.id]&&I[i.id].length>0&&e.jsxs("div",{className:"scenes-panel-ai-suggestions",children:[e.jsxs("div",{className:"scenes-panel-ai-label",children:["✨"," AI Suggestions"]}),I[i.id].map((m,C)=>e.jsxs("div",{className:"scenes-panel-ai-sug-card",children:[e.jsxs("div",{className:"scenes-panel-ai-sug-head",children:[e.jsx("span",{className:"scenes-panel-ai-sug-pos",title:m.suggested_position||"middle",children:L(m.suggested_position)}),e.jsx("span",{className:"scenes-panel-ai-sug-title",children:m.title}),m.emotional_beat&&e.jsx("span",{className:"scenes-panel-ai-sug-beat",children:m.emotional_beat})]}),e.jsx("p",{className:"scenes-panel-ai-sug-desc",children:m.description}),m.purpose&&e.jsxs("p",{className:"scenes-panel-ai-sug-purpose",children:[e.jsx("span",{className:"scenes-panel-ai-sug-purpose-label",children:"Purpose:"})," ",m.purpose]}),e.jsxs("div",{className:"scenes-panel-ai-sug-actions",children:[e.jsxs("button",{className:"scenes-panel-ai-accept",onClick:()=>S(i.id,m),children:["✓"," Add Scene"]}),e.jsx("button",{className:"scenes-panel-ai-dismiss",onClick:()=>R(v=>({...v,[i.id]:(v[i.id]||[]).filter((q,we)=>we!==C)})),children:"Dismiss"})]})]},C)),e.jsx("button",{className:"scenes-panel-ai-clear",onClick:()=>R(m=>({...m,[i.id]:[]})),children:"Clear suggestions"})]})]})]},i.id))}),e.jsx("style",{children:`
        .scenes-panel { padding: 24px; max-width: 760px; margin: 0 auto; }
        .scenes-panel-header {
          display: flex; align-items: flex-start; justify-content: space-between;
          margin-bottom: 24px; gap: 16px; flex-wrap: wrap;
        }
        .scenes-panel-title {
          font-family: 'Playfair Display', 'Lora', Georgia, serif;
          font-size: 20px; font-weight: 600; color: #1C1814; margin: 0 0 4px;
        }
        .scenes-panel-count {
          font-family: 'DM Mono', monospace; font-size: 10px;
          letter-spacing: 0.1em; color: rgba(28,24,20,0.4);
        }
        .scenes-panel-empty {
          text-align: center; padding: 48px 24px;
          font-family: 'Lora', Georgia, serif; font-style: italic;
          color: rgba(28,24,20,0.4); font-size: 14px;
        }

        /* ── Book-level AI button ── */
        .scenes-panel-ai-book-btn {
          background: linear-gradient(135deg, rgba(198,168,94,0.08), rgba(198,168,94,0.15));
          border: 1px solid rgba(198,168,94,0.25);
          border-radius: 6px; padding: 8px 16px;
          font-family: 'DM Mono', monospace; font-size: 10px;
          letter-spacing: 0.08em; color: #B8962E;
          cursor: pointer; transition: all 0.15s ease; white-space: nowrap;
        }
        .scenes-panel-ai-book-btn:hover:not(:disabled) {
          background: linear-gradient(135deg, rgba(198,168,94,0.15), rgba(198,168,94,0.25));
          border-color: rgba(198,168,94,0.4);
        }
        .scenes-panel-ai-book-btn:disabled { opacity: 0.6; cursor: wait; }

        /* ── AI error ── */
        .scenes-panel-ai-error {
          display: flex; align-items: center; justify-content: space-between;
          background: rgba(184,92,56,0.06); border: 1px solid rgba(184,92,56,0.15);
          border-radius: 6px; padding: 10px 14px; margin-bottom: 16px;
          font-family: 'DM Sans', sans-serif; font-size: 12px; color: #B85C38;
        }
        .scenes-panel-ai-error button {
          background: none; border: none; font-size: 16px;
          color: #B85C38; cursor: pointer;
        }

        /* ── Book-wide AI results ── */
        .scenes-panel-ai-book-results {
          background: rgba(198,168,94,0.03);
          border: 1px solid rgba(198,168,94,0.12);
          border-radius: 8px; padding: 16px; margin-bottom: 24px;
        }
        .scenes-panel-ai-book-label {
          font-family: 'DM Mono', monospace; font-size: 10px;
          letter-spacing: 0.12em; color: #B8962E; margin-bottom: 12px;
          text-transform: uppercase;
        }

        /* ── AI card (book-wide) ── */
        .scenes-panel-ai-card {
          background: rgba(250,248,245,0.8);
          border: 1px solid rgba(232,226,218,0.6);
          border-radius: 6px; padding: 12px 14px; margin-bottom: 10px;
        }
        .scenes-panel-ai-card-head {
          display: flex; align-items: baseline; gap: 8px; margin-bottom: 6px;
        }
        .scenes-panel-ai-card-title {
          font-family: 'Lora', Georgia, serif; font-size: 14px;
          font-weight: 600; color: #1C1814;
        }
        .scenes-panel-ai-card-ch {
          font-family: 'DM Mono', monospace; font-size: 9px;
          color: rgba(28,24,20,0.35); letter-spacing: 0.05em;
        }
        .scenes-panel-ai-card-desc {
          font-family: 'Lora', Georgia, serif; font-size: 12.5px;
          color: rgba(28,24,20,0.7); line-height: 1.5; margin: 0 0 6px;
        }
        .scenes-panel-ai-card-reason {
          font-family: 'DM Sans', sans-serif; font-size: 11px;
          color: rgba(28,24,20,0.45); margin: 0 0 6px; font-style: italic;
        }
        .scenes-panel-ai-card-reason-label {
          font-weight: 600; font-style: normal; color: rgba(28,24,20,0.5);
        }
        .scenes-panel-ai-card-chars {
          display: flex; gap: 4px; flex-wrap: wrap; margin-bottom: 8px;
        }
        .scenes-panel-ai-char-tag {
          font-family: 'DM Mono', monospace; font-size: 9px;
          background: rgba(198,168,94,0.1); color: #B8962E;
          border-radius: 3px; padding: 2px 6px;
        }
        .scenes-panel-ai-card-actions {
          display: flex; gap: 8px;
        }

        /* ── Per-chapter AI plan button ── */
        .scenes-panel-add-row-buttons {
          display: flex; align-items: center; gap: 12px; padding: 4px 0;
        }
        .scenes-panel-ai-plan-btn {
          background: none; border: none;
          font-family: 'DM Mono', monospace; font-size: 9px;
          letter-spacing: 0.08em; color: #B8962E;
          cursor: pointer; padding: 8px 0; transition: all 0.12s ease;
          opacity: 0.7;
        }
        .scenes-panel-ai-plan-btn:hover:not(:disabled) { opacity: 1; }
        .scenes-panel-ai-plan-btn:disabled { opacity: 0.5; cursor: wait; }

        /* ── AI suggestions per chapter ── */
        .scenes-panel-ai-suggestions {
          background: rgba(198,168,94,0.03);
          border: 1px solid rgba(198,168,94,0.1);
          border-radius: 6px; padding: 12px; margin-top: 8px;
        }
        .scenes-panel-ai-label {
          font-family: 'DM Mono', monospace; font-size: 9px;
          letter-spacing: 0.12em; color: #B8962E; margin-bottom: 10px;
          text-transform: uppercase;
        }
        .scenes-panel-ai-sug-card {
          background: rgba(250,248,245,0.8);
          border: 1px solid rgba(232,226,218,0.5);
          border-radius: 5px; padding: 10px 12px; margin-bottom: 8px;
        }
        .scenes-panel-ai-sug-head {
          display: flex; align-items: baseline; gap: 6px; margin-bottom: 4px;
        }
        .scenes-panel-ai-sug-pos {
          font-size: 8px; color: rgba(28,24,20,0.25);
        }
        .scenes-panel-ai-sug-title {
          font-family: 'Lora', Georgia, serif; font-size: 13px;
          font-weight: 600; color: #1C1814;
        }
        .scenes-panel-ai-sug-beat {
          font-family: 'DM Sans', sans-serif; font-size: 10px;
          color: #B8962E; font-style: italic; margin-left: auto;
        }
        .scenes-panel-ai-sug-desc {
          font-family: 'Lora', Georgia, serif; font-size: 12px;
          color: rgba(28,24,20,0.65); line-height: 1.45; margin: 0 0 4px;
        }
        .scenes-panel-ai-sug-purpose {
          font-family: 'DM Sans', sans-serif; font-size: 10.5px;
          color: rgba(28,24,20,0.4); margin: 0 0 6px; font-style: italic;
        }
        .scenes-panel-ai-sug-purpose-label {
          font-weight: 600; font-style: normal; color: rgba(28,24,20,0.45);
        }
        .scenes-panel-ai-sug-actions {
          display: flex; gap: 8px;
        }

        /* ── Shared AI action buttons ── */
        .scenes-panel-ai-accept {
          background: rgba(74,155,111,0.08); border: 1px solid rgba(74,155,111,0.2);
          border-radius: 4px; padding: 4px 10px;
          font-family: 'DM Mono', monospace; font-size: 9px;
          color: #4A9B6F; cursor: pointer; transition: all 0.12s ease;
        }
        .scenes-panel-ai-accept:hover {
          background: rgba(74,155,111,0.15); border-color: rgba(74,155,111,0.35);
        }
        .scenes-panel-ai-dismiss {
          background: none; border: none;
          font-family: 'DM Mono', monospace; font-size: 9px;
          color: rgba(28,24,20,0.3); cursor: pointer;
        }
        .scenes-panel-ai-dismiss:hover { color: rgba(28,24,20,0.5); }
        .scenes-panel-ai-clear {
          background: none; border: none;
          font-family: 'DM Mono', monospace; font-size: 9px;
          color: rgba(28,24,20,0.25); cursor: pointer;
          padding: 6px 0; margin-top: 4px;
        }
        .scenes-panel-ai-clear:hover { color: rgba(28,24,20,0.4); }

        /* ── Chapter type badge ── */
        .scenes-panel-ch-type {
          font-family: 'DM Mono', monospace; font-size: 8px;
          letter-spacing: 0.08em; text-transform: uppercase;
          color: #B8962E; background: rgba(198,168,94,0.08);
          border-radius: 3px; padding: 1px 5px;
        }

        /* ── Existing styles ── */
        .scenes-panel-chapter { margin-bottom: 2px; }
        .scenes-panel-chapter-btn {
          display: flex; align-items: center; gap: 10px; width: 100%;
          background: none; border: none; border-bottom: 1px solid rgba(28,24,20,0.06);
          padding: 12px 8px; cursor: pointer; text-align: left;
          transition: background 0.12s ease;
        }
        .scenes-panel-chapter-btn:hover { background: rgba(28,24,20,0.02); }
        .scenes-panel-ch-num {
          font-family: 'DM Mono', monospace; font-size: 10px;
          color: rgba(28,24,20,0.35); min-width: 40px;
        }
        .scenes-panel-ch-title {
          flex: 1; font-family: 'Lora', Georgia, serif; font-size: 14px; color: #1C1814;
        }
        .scenes-panel-ch-count {
          font-family: 'DM Mono', monospace; font-size: 9px;
          color: rgba(28,24,20,0.3); letter-spacing: 0.05em;
        }
        .scenes-panel-ch-arrow {
          font-size: 10px; color: rgba(28,24,20,0.3); min-width: 14px; text-align: center;
        }
        .scenes-panel-scenes {
          padding: 4px 0 12px 52px;
        }
        .scenes-panel-no-scenes {
          font-family: 'Lora', Georgia, serif; font-style: italic;
          font-size: 12px; color: rgba(28,24,20,0.3); padding: 8px 0;
        }
        .scenes-panel-scene {
          display: flex; align-items: center; gap: 8px;
          padding: 6px 0; font-family: 'Lora', Georgia, serif; font-size: 13px;
        }
        .scenes-panel-scene-num {
          font-family: 'DM Mono', monospace; font-size: 9px;
          color: rgba(28,24,20,0.25); min-width: 16px;
        }
        .scenes-panel-scene-dinkus {
          font-size: 8px; color: #B8962E; opacity: 0.6;
        }
        .scenes-panel-scene-title {
          color: #1C1814; cursor: default; flex: 1;
        }
        .scenes-panel-scene-title:hover { text-decoration: underline dotted rgba(28,24,20,0.2); }
        .scenes-panel-scene-edit {
          flex: 1; border: none; border-bottom: 1px solid rgba(184,150,46,0.4);
          background: none; font-family: 'Lora', Georgia, serif; font-size: 13px;
          color: #1C1814; padding: 2px 0; outline: none;
        }
        .scenes-panel-scene-del {
          background: none; border: none; font-size: 14px; color: rgba(28,24,20,0.2);
          cursor: pointer; padding: 2px 4px; opacity: 0; transition: opacity 0.1s ease;
        }
        .scenes-panel-scene:hover .scenes-panel-scene-del { opacity: 1; }
        .scenes-panel-scene-del:hover { color: #B85C38; }

        /* Add scene */
        .scenes-panel-add-btn {
          background: none; border: none; font-family: 'DM Mono', monospace;
          font-size: 9px; letter-spacing: 0.08em; color: rgba(28,24,20,0.35);
          cursor: pointer; padding: 8px 0; transition: color 0.12s ease;
        }
        .scenes-panel-add-btn:hover { color: #B8962E; }
        .scenes-panel-add-row {
          display: flex; align-items: center; gap: 6px; padding: 6px 0;
        }
        .scenes-panel-add-input {
          flex: 1; border: none; border-bottom: 1px solid rgba(28,24,20,0.12);
          background: none; font-family: 'Lora', Georgia, serif; font-size: 13px;
          color: #1C1814; padding: 4px 0; outline: none;
        }
        .scenes-panel-add-input:focus { border-bottom-color: rgba(184,150,46,0.4); }
        .scenes-panel-add-confirm,
        .scenes-panel-add-cancel {
          background: none; border: none; font-size: 14px;
          cursor: pointer; padding: 2px 4px; color: rgba(28,24,20,0.4);
        }
        .scenes-panel-add-confirm:hover { color: #4A9B6F; }
        .scenes-panel-add-cancel:hover { color: #B85C38; }

        @media (max-width: 480px) {
          .scenes-panel { padding: 16px 12px; }
          .scenes-panel-scenes { padding-left: 32px; }
          .scenes-panel-header { flex-direction: column; }
          .scenes-panel-ai-sug-head { flex-wrap: wrap; }
        }
      `})]})}const Ft="/api/v1",fs=[{value:"prologue",label:"Prologue",icon:"◈"},{value:"chapter",label:"Chapter",icon:"§"},{value:"interlude",label:"Interlude",icon:"~"},{value:"epilogue",label:"Epilogue",icon:"◇"},{value:"afterword",label:"Afterword",icon:"∗"}],It=A=>{const B=[10,9,5,4,1],g=["X","IX","V","IV","I"];let f="";return B.forEach((H,fe)=>{for(;A>=H;)f+=g[fe],A-=H}),f||""},Rt=()=>{const A=localStorage.getItem("token")||sessionStorage.getItem("token");return{"Content-Type":"application/json",...A?{Authorization:`Bearer ${A}`}:{}}};function ha({bookId:A,allChapters:B=[],onChapterUpdate:g,onReloadChapters:f}){const[H,fe]=a.useState(null),[be,oe]=a.useState(!0),[r,F]=a.useState("overview"),[w,W]=a.useState(!1),[x,E]=a.useState({dedication:"",epigraph:"",epigraph_attribution:"",foreword:"",preface:"",copyright:""}),[j,Y]=a.useState({about_author:"",acknowledgments:"",glossary:"",appendix:"",bibliography:"",notes:""}),[I,R]=a.useState("");a.useEffect(()=>{A&&(oe(!0),fetch(`${Ft}/storyteller/books/${A}`,{headers:Rt()}).then(l=>l.json()).then(l=>{const d=l.book||l;fe(d),R(d.author_name||""),d.front_matter&&E(p=>({...p,...d.front_matter})),d.back_matter&&Y(p=>({...p,...d.back_matter}))}).catch(console.error).finally(()=>oe(!1)))},[A]);const te=a.useCallback(async()=>{if(A){W(!0);try{await fetch(`${Ft}/storyteller/books/${A}`,{method:"PUT",headers:Rt(),body:JSON.stringify({author_name:I,front_matter:x,back_matter:j})})}catch(l){console.error("Save book meta error:",l)}finally{W(!1)}}},[A,I,x,j]),U=a.useCallback(async(l,d)=>{try{await fetch(`${Ft}/storyteller/chapters/${l}`,{method:"PUT",headers:Rt(),body:JSON.stringify(d)}),g&&g(l,d)}catch(p){console.error("Save chapter meta error:",p)}},[g]),O=[...B].sort((l,d)=>(l.sort_order??l.chapter_number??0)-(d.sort_order??d.chapter_number??0)),V=O.reduce((l,d)=>{const p=d.part_number||0;return l[p]||(l[p]={number:p,title:d.part_title||"",chapters:[]}),l[p].chapters.push(d),l},{}),re=Object.values(V).sort((l,d)=>l.number-d.number),J=O.reduce((l,d)=>{const p=d.draft_prose?d.draft_prose.split(/\s+/).filter(Boolean).length:0;return l+p},0),le=O.reduce((l,d)=>{const p=d.sections||[];return l+p.filter(P=>P.type==="h3").length},0),he=[{id:"overview",label:"Overview",icon:"📖"},{id:"front",label:"Front Matter",icon:"◈"},{id:"structure",label:"Parts & Chapters",icon:"§"},{id:"back",label:"Back Matter",icon:"◇"}];return be?e.jsx("div",{className:"bsp-loading",children:e.jsx("span",{className:"bsp-loading-text",children:"Loading book structure…"})}):e.jsxs("div",{className:"bsp-panel",children:[e.jsx("div",{className:"bsp-nav",children:he.map(l=>e.jsxs("button",{className:`bsp-nav-btn${r===l.id?" active":""}`,onClick:()=>F(l.id),children:[e.jsx("span",{className:"bsp-nav-icon",children:l.icon}),e.jsx("span",{className:"bsp-nav-label",children:l.label})]},l.id))}),r==="overview"&&e.jsxs("div",{className:"bsp-section",children:[e.jsxs("div",{className:"bsp-overview-header",children:[e.jsx("h2",{className:"bsp-title",children:H?.title||"Untitled"}),H?.subtitle&&e.jsx("p",{className:"bsp-subtitle",children:H.subtitle})]}),e.jsxs("div",{className:"bsp-stats-grid",children:[e.jsxs("div",{className:"bsp-stat",children:[e.jsx("span",{className:"bsp-stat-num",children:O.length}),e.jsx("span",{className:"bsp-stat-label",children:"Chapters"})]}),e.jsxs("div",{className:"bsp-stat",children:[e.jsx("span",{className:"bsp-stat-num",children:le}),e.jsx("span",{className:"bsp-stat-label",children:"Scenes"})]}),e.jsxs("div",{className:"bsp-stat",children:[e.jsx("span",{className:"bsp-stat-num",children:J.toLocaleString()}),e.jsx("span",{className:"bsp-stat-label",children:"Words"})]}),e.jsxs("div",{className:"bsp-stat",children:[e.jsx("span",{className:"bsp-stat-num",children:Math.max(1,Math.round(J/250))}),e.jsx("span",{className:"bsp-stat-label",children:"Min Read"})]})]}),e.jsxs("div",{className:"bsp-outline",children:[e.jsx("h3",{className:"bsp-outline-title",children:"Book Outline"}),e.jsxs("div",{className:"bsp-outline-group",children:[e.jsx("span",{className:"bsp-outline-group-label",children:"Front Matter"}),e.jsxs("div",{className:"bsp-outline-pills",children:[x.dedication&&e.jsx("span",{className:"bsp-pill filled",children:"Dedication"}),x.epigraph&&e.jsx("span",{className:"bsp-pill filled",children:"Epigraph"}),x.foreword&&e.jsx("span",{className:"bsp-pill filled",children:"Foreword"}),x.preface&&e.jsx("span",{className:"bsp-pill filled",children:"Preface"}),x.copyright&&e.jsx("span",{className:"bsp-pill filled",children:"Copyright"}),!x.dedication&&!x.epigraph&&!x.foreword&&!x.preface&&!x.copyright&&e.jsx("span",{className:"bsp-pill empty",children:"None added yet"})]})]}),re.map(l=>e.jsxs("div",{className:"bsp-outline-group",children:[l.number>0&&e.jsxs("span",{className:"bsp-outline-part-label",children:["Part ",It(l.number),l.title?` — ${l.title}`:""]}),l.number===0&&re.length>1&&e.jsx("span",{className:"bsp-outline-part-label bsp-outline-part-unassigned",children:"Unassigned"}),l.chapters.map((d,p)=>{const P=fs.find(S=>S.value===(d.chapter_type||"chapter")),ce=d.draft_prose?d.draft_prose.split(/\s+/).filter(Boolean).length:0,Q=(d.sections||[]).filter(S=>S.type==="h3").length;return e.jsxs("div",{className:"bsp-outline-chapter",children:[e.jsx("span",{className:"bsp-outline-ch-icon",children:P?.icon||"§"}),e.jsx("span",{className:"bsp-outline-ch-type",children:P?.label||"Chapter"}),e.jsx("span",{className:"bsp-outline-ch-title",children:d.title||"Untitled"}),e.jsxs("span",{className:"bsp-outline-ch-meta",children:[Q>0&&`${Q} scene${Q>1?"s":""}`,Q>0&&ce>0&&" · ",ce>0&&`${ce.toLocaleString()}w`]})]},d.id)})]},l.number)),e.jsxs("div",{className:"bsp-outline-group",children:[e.jsx("span",{className:"bsp-outline-group-label",children:"Back Matter"}),e.jsxs("div",{className:"bsp-outline-pills",children:[j.about_author&&e.jsx("span",{className:"bsp-pill filled",children:"About the Author"}),j.acknowledgments&&e.jsx("span",{className:"bsp-pill filled",children:"Acknowledgments"}),j.glossary&&e.jsx("span",{className:"bsp-pill filled",children:"Glossary"}),j.appendix&&e.jsx("span",{className:"bsp-pill filled",children:"Appendix"}),j.bibliography&&e.jsx("span",{className:"bsp-pill filled",children:"Bibliography"}),j.notes&&e.jsx("span",{className:"bsp-pill filled",children:"Notes"}),!j.about_author&&!j.acknowledgments&&!j.glossary&&!j.appendix&&!j.bibliography&&!j.notes&&e.jsx("span",{className:"bsp-pill empty",children:"None added yet"})]})]})]})]}),r==="front"&&e.jsxs("div",{className:"bsp-section",children:[e.jsxs("div",{className:"bsp-section-header",children:[e.jsx("h3",{className:"bsp-section-title",children:"Front Matter"}),e.jsx("p",{className:"bsp-section-desc",children:"These pages appear before Chapter 1 in your manuscript."})]}),e.jsxs("div",{className:"bsp-field",children:[e.jsx("label",{className:"bsp-field-label",children:"Author Name"}),e.jsx("input",{className:"bsp-input",value:I,onChange:l=>R(l.target.value),placeholder:"Your name as it appears on the title page"})]}),e.jsxs("div",{className:"bsp-field",children:[e.jsx("label",{className:"bsp-field-label",children:"Copyright Page"}),e.jsx("textarea",{className:"bsp-textarea",value:x.copyright,onChange:l=>E(d=>({...d,copyright:l.target.value})),placeholder:`© ${new Date().getFullYear()} ${I||"[Author Name]"}. All rights reserved.

No part of this publication may be reproduced...`,rows:4})]}),e.jsxs("div",{className:"bsp-field",children:[e.jsx("label",{className:"bsp-field-label",children:"Dedication"}),e.jsx("textarea",{className:"bsp-textarea bsp-textarea--short",value:x.dedication,onChange:l=>E(d=>({...d,dedication:l.target.value})),placeholder:"For those who dare to imagine…",rows:2})]}),e.jsxs("div",{className:"bsp-field",children:[e.jsx("label",{className:"bsp-field-label",children:"Epigraph"}),e.jsx("textarea",{className:"bsp-textarea bsp-textarea--short",value:x.epigraph,onChange:l=>E(d=>({...d,epigraph:l.target.value})),placeholder:"A quote that sets the tone for the entire work…",rows:2}),e.jsx("input",{className:"bsp-input bsp-input--secondary",value:x.epigraph_attribution,onChange:l=>E(d=>({...d,epigraph_attribution:l.target.value})),placeholder:"— Attribution (e.g., Virginia Woolf)"})]}),e.jsxs("div",{className:"bsp-field",children:[e.jsx("label",{className:"bsp-field-label",children:"Foreword"}),e.jsx("p",{className:"bsp-field-hint",children:"Written by someone other than the author — an endorsement or context-setting piece."}),e.jsx("textarea",{className:"bsp-textarea",value:x.foreword,onChange:l=>E(d=>({...d,foreword:l.target.value})),placeholder:"Press Enter to begin your foreword…",rows:6})]}),e.jsxs("div",{className:"bsp-field",children:[e.jsx("label",{className:"bsp-field-label",children:"Preface"}),e.jsx("p",{className:"bsp-field-hint",children:"Written by the author — explains why you wrote this book and how to read it."}),e.jsx("textarea",{className:"bsp-textarea",value:x.preface,onChange:l=>E(d=>({...d,preface:l.target.value})),placeholder:"Press Enter to begin your preface…",rows:6})]}),e.jsx("div",{className:"bsp-save-row",children:e.jsx("button",{className:"bsp-save-btn",onClick:te,disabled:w,children:w?"Saving…":"Save Front Matter"})})]}),r==="structure"&&e.jsxs("div",{className:"bsp-section",children:[e.jsxs("div",{className:"bsp-section-header",children:[e.jsx("h3",{className:"bsp-section-title",children:"Parts & Chapters"}),e.jsx("p",{className:"bsp-section-desc",children:"Organize chapters into Parts/Acts and set chapter types (Prologue, Interlude, Epilogue, etc.)."})]}),O.map((l,d)=>{const p=l.chapter_type||"chapter",P=l.part_number||0,ce=d>0?O[d-1].part_number||0:-1,Q=P!==ce&&P>0;return e.jsxs("div",{children:[Q&&e.jsxs("div",{className:"bsp-part-header",children:[e.jsxs("span",{className:"bsp-part-numeral",children:["Part ",It(P)]}),e.jsx("input",{className:"bsp-part-title-input",value:l.part_title||"",onChange:S=>{const K=S.target.value;O.filter(L=>L.part_number===P).forEach(L=>{U(L.id,{part_title:K})})},placeholder:"Part title (optional)"})]}),e.jsxs("div",{className:"bsp-chapter-row",children:[e.jsxs("div",{className:"bsp-ch-left",children:[e.jsx("span",{className:"bsp-ch-num",children:l.chapter_number||d+1}),e.jsx("span",{className:"bsp-ch-title",children:l.title||"Untitled"})]}),e.jsxs("div",{className:"bsp-ch-controls",children:[e.jsx("select",{className:"bsp-select",value:p,onChange:S=>U(l.id,{chapter_type:S.target.value}),children:fs.map(S=>e.jsxs("option",{value:S.value,children:[S.icon," ",S.label]},S.value))}),e.jsxs("select",{className:"bsp-select bsp-select--part",value:P,onChange:S=>U(l.id,{part_number:parseInt(S.target.value)||null,part_title:S.target.value==0?null:l.part_title}),children:[e.jsx("option",{value:0,children:"No Part"}),[1,2,3,4,5,6,7,8].map(S=>e.jsxs("option",{value:S,children:["Part ",It(S)]},S))]}),(()=>{const S=(l.sections||[]).filter(K=>K.type==="h3").length;return S>0?e.jsxs("span",{className:"bsp-scene-badge",children:[S," scene",S>1?"s":""]}):null})()]})]})]},l.id)}),O.length===0&&e.jsx("div",{className:"bsp-empty",children:"No chapters yet. Add chapters from the TOC sidebar."})]}),r==="back"&&e.jsxs("div",{className:"bsp-section",children:[e.jsxs("div",{className:"bsp-section-header",children:[e.jsx("h3",{className:"bsp-section-title",children:"Back Matter"}),e.jsx("p",{className:"bsp-section-desc",children:"These pages appear after the final chapter."})]}),e.jsxs("div",{className:"bsp-field",children:[e.jsx("label",{className:"bsp-field-label",children:"About the Author"}),e.jsx("textarea",{className:"bsp-textarea",value:j.about_author,onChange:l=>Y(d=>({...d,about_author:l.target.value})),placeholder:"A short biography — who you are, what you write, where you live…",rows:5})]}),e.jsxs("div",{className:"bsp-field",children:[e.jsx("label",{className:"bsp-field-label",children:"Acknowledgments"}),e.jsx("textarea",{className:"bsp-textarea",value:j.acknowledgments,onChange:l=>Y(d=>({...d,acknowledgments:l.target.value})),placeholder:"Thank the people and forces that made this book possible…",rows:5})]}),e.jsxs("div",{className:"bsp-field",children:[e.jsx("label",{className:"bsp-field-label",children:"Glossary"}),e.jsxs("p",{className:"bsp-field-hint",children:["Define specialized terms used in your book. One term per line: ",e.jsx("em",{children:"Term — Definition"})]}),e.jsx("textarea",{className:"bsp-textarea",value:j.glossary,onChange:l=>Y(d=>({...d,glossary:l.target.value})),placeholder:"Chronoweave — The fabric of intersecting timelines…\\nEchostone — A memory artifact that replays…",rows:6})]}),e.jsxs("div",{className:"bsp-field",children:[e.jsx("label",{className:"bsp-field-label",children:"Appendix"}),e.jsx("textarea",{className:"bsp-textarea",value:j.appendix,onChange:l=>Y(d=>({...d,appendix:l.target.value})),placeholder:"Supplementary material, tables, maps, or charts…",rows:5})]}),e.jsxs("div",{className:"bsp-field",children:[e.jsx("label",{className:"bsp-field-label",children:"Bibliography / References"}),e.jsx("textarea",{className:"bsp-textarea",value:j.bibliography,onChange:l=>Y(d=>({...d,bibliography:l.target.value})),placeholder:"Sources, references, or further reading…",rows:4})]}),e.jsxs("div",{className:"bsp-field",children:[e.jsx("label",{className:"bsp-field-label",children:"Author's Notes / Endnotes"}),e.jsx("textarea",{className:"bsp-textarea",value:j.notes,onChange:l=>Y(d=>({...d,notes:l.target.value})),placeholder:"Behind-the-scenes thoughts, research notes, or endnotes…",rows:4})]}),e.jsx("div",{className:"bsp-save-row",children:e.jsx("button",{className:"bsp-save-btn",onClick:te,disabled:w,children:w?"Saving…":"Save Back Matter"})})]}),e.jsx("style",{children:`
/* ═══ BookStructurePanel Styles ═══ */
.bsp-panel {
  display: flex;
  flex-direction: column;
  height: 100%;
  overflow: hidden;
  background: #FAF7F0;
}
.bsp-loading {
  display: flex;
  align-items: center;
  justify-content: center;
  height: 300px;
  font-family: 'Lora', Georgia, serif;
  font-style: italic;
  color: rgba(28, 24, 20, 0.4);
  font-size: 14px;
}

/* ── Nav ── */
.bsp-nav {
  display: flex;
  gap: 0;
  border-bottom: 1px solid rgba(28, 24, 20, 0.08);
  padding: 0 12px;
  background: #FAF7F0;
  flex-shrink: 0;
  overflow-x: auto;
  -webkit-overflow-scrolling: touch;
}
.bsp-nav-btn {
  display: flex;
  align-items: center;
  gap: 6px;
  background: none;
  border: none;
  border-bottom: 2px solid transparent;
  padding: 10px 14px 8px;
  font-family: 'DM Mono', monospace;
  font-size: 10px;
  letter-spacing: 0.08em;
  color: rgba(28, 24, 20, 0.4);
  cursor: pointer;
  transition: all 0.12s ease;
  white-space: nowrap;
}
.bsp-nav-btn:hover { color: rgba(28, 24, 20, 0.7); }
.bsp-nav-btn.active {
  color: #1C1814;
  border-bottom-color: #B8962E;
}
.bsp-nav-icon { font-size: 12px; }

/* ── Section ── */
.bsp-section {
  flex: 1;
  overflow-y: auto;
  padding: 20px 24px 40px;
  max-width: 720px;
  margin: 0 auto;
  width: 100%;
}
.bsp-section-header { margin-bottom: 24px; }
.bsp-section-title {
  font-family: 'Lora', Georgia, serif;
  font-size: 18px;
  font-weight: 500;
  color: #1C1814;
  margin: 0 0 6px;
}
.bsp-section-desc {
  font-family: 'Spectral', Georgia, serif;
  font-size: 13px;
  color: rgba(28, 24, 20, 0.5);
  margin: 0;
  line-height: 1.6;
}

/* ── Overview ── */
.bsp-overview-header { text-align: center; padding: 16px 0 24px; }
.bsp-title {
  font-family: 'Lora', Georgia, serif;
  font-size: 24px;
  font-weight: 500;
  font-style: italic;
  color: #1C1814;
  margin: 0 0 4px;
}
.bsp-subtitle {
  font-family: 'Spectral', Georgia, serif;
  font-size: 14px;
  color: rgba(28, 24, 20, 0.5);
  margin: 0;
}

/* Stats grid */
.bsp-stats-grid {
  display: grid;
  grid-template-columns: repeat(4, 1fr);
  gap: 12px;
  margin-bottom: 28px;
}
.bsp-stat {
  display: flex;
  flex-direction: column;
  align-items: center;
  padding: 14px 8px;
  border: 1px solid rgba(28, 24, 20, 0.06);
  border-radius: 4px;
  background: #FFFDF9;
}
.bsp-stat-num {
  font-family: 'DM Mono', monospace;
  font-size: 20px;
  color: #1C1814;
  font-weight: 500;
}
.bsp-stat-label {
  font-family: 'DM Mono', monospace;
  font-size: 8px;
  letter-spacing: 0.15em;
  color: rgba(28, 24, 20, 0.35);
  text-transform: uppercase;
  margin-top: 4px;
}

/* Outline */
.bsp-outline { margin-top: 8px; }
.bsp-outline-title {
  font-family: 'DM Mono', monospace;
  font-size: 9px;
  letter-spacing: 0.15em;
  color: rgba(28, 24, 20, 0.3);
  text-transform: uppercase;
  margin: 0 0 16px;
  padding-bottom: 8px;
  border-bottom: 1px solid rgba(28, 24, 20, 0.06);
}
.bsp-outline-group { margin-bottom: 16px; }
.bsp-outline-group-label {
  font-family: 'DM Mono', monospace;
  font-size: 8px;
  letter-spacing: 0.12em;
  color: rgba(28, 24, 20, 0.35);
  text-transform: uppercase;
  display: block;
  margin-bottom: 8px;
}
.bsp-outline-part-label {
  font-family: 'Lora', Georgia, serif;
  font-size: 13px;
  font-weight: 600;
  color: #B8962E;
  display: block;
  margin-bottom: 8px;
  padding: 6px 0;
  border-bottom: 1px solid rgba(184, 150, 46, 0.15);
}
.bsp-outline-part-unassigned { color: rgba(28, 24, 20, 0.3); }
.bsp-outline-pills { display: flex; flex-wrap: wrap; gap: 6px; }
.bsp-pill {
  font-family: 'DM Mono', monospace;
  font-size: 9px;
  letter-spacing: 0.05em;
  padding: 4px 10px;
  border-radius: 3px;
  border: 1px solid rgba(28, 24, 20, 0.08);
}
.bsp-pill.filled { background: rgba(184, 150, 46, 0.08); color: #8A7434; border-color: rgba(184, 150, 46, 0.2); }
.bsp-pill.empty { color: rgba(28, 24, 20, 0.3); font-style: italic; }

.bsp-outline-chapter {
  display: flex;
  align-items: center;
  gap: 8px;
  padding: 6px 0 6px 8px;
  border-bottom: 1px solid rgba(28, 24, 20, 0.04);
}
.bsp-outline-ch-icon { font-size: 11px; color: rgba(28, 24, 20, 0.3); width: 16px; text-align: center; }
.bsp-outline-ch-type {
  font-family: 'DM Mono', monospace;
  font-size: 8px;
  letter-spacing: 0.08em;
  color: rgba(28, 24, 20, 0.35);
  text-transform: uppercase;
  min-width: 60px;
}
.bsp-outline-ch-title {
  font-family: 'Spectral', Georgia, serif;
  font-size: 14px;
  color: #1C1814;
  flex: 1;
  min-width: 0;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}
.bsp-outline-ch-meta {
  font-family: 'DM Mono', monospace;
  font-size: 9px;
  color: rgba(28, 24, 20, 0.3);
  white-space: nowrap;
}

/* ── Fields (Front/Back matter) ── */
.bsp-field { margin-bottom: 20px; }
.bsp-field-label {
  display: block;
  font-family: 'DM Mono', monospace;
  font-size: 10px;
  letter-spacing: 0.1em;
  color: rgba(28, 24, 20, 0.5);
  text-transform: uppercase;
  margin-bottom: 6px;
}
.bsp-field-hint {
  font-family: 'Spectral', Georgia, serif;
  font-size: 12px;
  color: rgba(28, 24, 20, 0.4);
  font-style: italic;
  margin: 0 0 8px;
  line-height: 1.5;
}
.bsp-input,
.bsp-textarea {
  width: 100%;
  border: 1px solid rgba(28, 24, 20, 0.1);
  border-radius: 3px;
  padding: 10px 14px;
  font-family: 'Spectral', Georgia, serif;
  font-size: 14px;
  line-height: 1.7;
  color: #1C1814;
  background: #FFFDF9;
  outline: none;
  transition: border-color 0.12s ease;
  box-sizing: border-box;
}
.bsp-input:focus,
.bsp-textarea:focus {
  border-color: rgba(184, 150, 46, 0.4);
}
.bsp-input--secondary {
  margin-top: 6px;
  font-style: italic;
  color: rgba(28, 24, 20, 0.6);
  font-size: 13px;
}
.bsp-textarea { resize: vertical; min-height: 60px; }
.bsp-textarea--short { min-height: 40px; }

.bsp-save-row {
  display: flex;
  justify-content: flex-end;
  margin-top: 24px;
  padding-top: 16px;
  border-top: 1px solid rgba(28, 24, 20, 0.06);
}
.bsp-save-btn {
  background: #1C1814;
  color: #FAF7F0;
  border: none;
  border-radius: 3px;
  padding: 10px 28px;
  font-family: 'DM Mono', monospace;
  font-size: 10px;
  letter-spacing: 0.1em;
  cursor: pointer;
  transition: opacity 0.12s ease;
}
.bsp-save-btn:hover { opacity: 0.85; }
.bsp-save-btn:disabled { opacity: 0.5; cursor: not-allowed; }

/* ── Parts & Chapters ── */
.bsp-part-header {
  display: flex;
  align-items: center;
  gap: 12px;
  padding: 14px 0 8px;
  border-top: 2px solid rgba(184, 150, 46, 0.2);
  margin-top: 16px;
}
.bsp-part-header:first-child { margin-top: 0; }
.bsp-part-numeral {
  font-family: 'Lora', Georgia, serif;
  font-size: 14px;
  font-weight: 600;
  color: #B8962E;
  white-space: nowrap;
}
.bsp-part-title-input {
  flex: 1;
  background: none;
  border: none;
  border-bottom: 1px solid rgba(28, 24, 20, 0.08);
  padding: 4px 0;
  font-family: 'Spectral', Georgia, serif;
  font-size: 14px;
  color: #1C1814;
  outline: none;
}
.bsp-part-title-input:focus { border-bottom-color: rgba(184, 150, 46, 0.4); }

.bsp-chapter-row {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 10px 0;
  border-bottom: 1px solid rgba(28, 24, 20, 0.04);
  gap: 12px;
  flex-wrap: wrap;
}
.bsp-ch-left {
  display: flex;
  align-items: center;
  gap: 10px;
  min-width: 0;
  flex: 1;
}
.bsp-ch-num {
  font-family: 'DM Mono', monospace;
  font-size: 11px;
  color: rgba(28, 24, 20, 0.3);
  width: 24px;
  text-align: right;
  flex-shrink: 0;
}
.bsp-ch-title {
  font-family: 'Spectral', Georgia, serif;
  font-size: 14px;
  color: #1C1814;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}
.bsp-ch-controls {
  display: flex;
  align-items: center;
  gap: 8px;
  flex-shrink: 0;
}
.bsp-select {
  background: #FFFDF9;
  border: 1px solid rgba(28, 24, 20, 0.1);
  border-radius: 3px;
  padding: 5px 8px;
  font-family: 'DM Mono', monospace;
  font-size: 9px;
  color: #1C1814;
  cursor: pointer;
  outline: none;
}
.bsp-select:focus { border-color: rgba(184, 150, 46, 0.4); }
.bsp-select--part { min-width: 85px; }
.bsp-scene-badge {
  font-family: 'DM Mono', monospace;
  font-size: 8px;
  letter-spacing: 0.08em;
  color: rgba(28, 24, 20, 0.35);
  background: rgba(28, 24, 20, 0.04);
  padding: 3px 8px;
  border-radius: 10px;
  white-space: nowrap;
}

.bsp-empty {
  text-align: center;
  padding: 32px 16px;
  font-family: 'Lora', Georgia, serif;
  font-style: italic;
  color: rgba(28, 24, 20, 0.35);
  font-size: 14px;
}

/* ── Mobile responsive ── */
@media (max-width: 480px) {
  .bsp-section { padding: 16px 12px 32px; }
  .bsp-stats-grid { grid-template-columns: repeat(2, 1fr); }
  .bsp-chapter-row { flex-direction: column; align-items: flex-start; gap: 8px; }
  .bsp-ch-controls { width: 100%; }
  .bsp-select { flex: 1; }
  .bsp-nav-btn { padding: 8px 10px 6px; font-size: 9px; }
  .bsp-outline-chapter { padding: 6px 0; }
}
@media (min-width: 481px) and (max-width: 768px) {
  .bsp-section { padding: 16px 16px 32px; }
  .bsp-stats-grid { grid-template-columns: repeat(4, 1fr); gap: 8px; }
}
      `})]})}const T="/api/v1",bs=[{type:"h2",label:"Chapter Title",icon:"H2"},{type:"h3",label:"Section",icon:"H3"},{type:"h4",label:"Subsection",icon:"H4"},{type:"body",label:"Body",icon:"¶"},{type:"quote",label:"Quote",icon:"“"},{type:"reflection",label:"Reflection",icon:"?"},{type:"divider",label:"Divider",icon:"─"}],ua=["h1","h2","h3","h4"];function Ot(){return crypto.randomUUID?crypto.randomUUID():`${Date.now()}-${Math.random().toString(36).slice(2,9)}`}const ys=[{id:"write",label:"Write"},{id:"review",label:"Review"},{id:"structure",label:"Structure"},{id:"scenes",label:"Scenes"},{id:"memory",label:"Memory"},{id:"lala",label:"Lala"},{id:"export",label:"Export"}];function ja({hideTopBar:A=!1,initialCenterTab:B="write"}){const{bookId:g,chapterId:f}=sa(),H=aa(),fe=767,[be,oe]=a.useState(()=>window.innerWidth<=fe);a.useEffect(()=>{const t=window.matchMedia(`(max-width: ${fe}px)`),s=n=>oe(n.matches);return t.addEventListener("change",s),()=>t.removeEventListener("change",s)},[]);const[r,F]=a.useState(null),[w,W]=a.useState(null),[x,E]=a.useState([]),[j,Y]=a.useState(!0),[I,R]=a.useState(()=>{const t=localStorage.getItem("wm-show-toc");return t!==null?t==="true":!0}),[te,U]=a.useState(()=>{const t=localStorage.getItem("wm-show-context");return t!==null?t==="true":!0}),O=!be&&I,V=!be&&te,[re,J]=a.useState(null),[le,he]=a.useState(null),[l,d]=a.useState(null),[p,P]=a.useState(""),[ce,Q]=a.useState(!1),[S,K]=a.useState(""),[L,i]=a.useState(null),[y,m]=a.useState([]),[C,v]=a.useState(null),[q,we]=a.useState(""),[xa,ga]=a.useState(null),[ws,Gt]=a.useState(!1),mt=a.useRef(null),[vs,Wt]=a.useState({}),ht=a.useRef({}),[Te,se]=a.useState(null),[G,de]=a.useState(""),[Oe,Ht]=a.useState(null),[et,ut]=a.useState("plan"),[h,ae]=a.useState(""),[ue,ie]=a.useState(0),[xt,xe]=a.useState(!0),[gt,tt]=a.useState(!1),[Ce,st]=a.useState(!1),[Ut,ft]=a.useState(""),[_,X]=a.useState(!1),[Jt,bt]=a.useState(null),[ve,js]=a.useState(!1),[Be,yt]=a.useState(""),[Ns,wt]=a.useState(!1),[_e,je]=a.useState(null),[Kt,Ge]=a.useState(null),[We,vt]=a.useState(null),[Ee,ks]=a.useState("paragraph"),[He,Me]=a.useState(""),[jt,Ss]=a.useState([]),[$,Ue]=a.useState(null),[fa,qt]=a.useState(!1),[Cs,Nt]=a.useState(!1),[Yt,D]=a.useState(null),[Vt,_s]=a.useState([]),[Pe,Ts]=a.useState(!1),kt=a.useRef({toc:!0,ctx:!0}),[Qt]=a.useState(()=>Date.now()),[at,Es]=a.useState(0),[Le,Ms]=a.useState(()=>{const t=localStorage.getItem("wm-word-goal");return t?parseInt(t,10):0}),[St,Ct]=a.useState(!1),nt=a.useRef(0),[Z,Ne]=a.useState(null),[Xt,De]=a.useState(null),[ze,Ds]=a.useState([]),[rt,it]=a.useState(!1),[ot,Fe]=a.useState(!1),[ge,Je]=a.useState(B||"write");a.useEffect(()=>{const t=s=>{s.detail&&ys.some(n=>n.id===s.detail)&&Je(s.detail)};return window.addEventListener("cj-set-tab",t),()=>window.removeEventListener("cj-set-tab",t)},[]),a.useEffect(()=>{const t=s=>{const n=s.detail?.tab;U(o=>{const c=!o;return c&&n&&ut(n),c})};return window.addEventListener("cj-toggle-context",t),()=>window.removeEventListener("cj-toggle-context",t)},[]);const[ye,lt]=a.useState([]),[_t,Tt]=a.useState(null),[Ke,Et]=a.useState(""),[As,$s]=a.useState(null),[Bs,Zt]=a.useState(!1),[es,Ps]=a.useState([]),ts=h.split(/\n\n+/).filter(t=>t.trim().length>20).length,Ls=ts>=5&&ge==="write",ss=a.useRef(null),as=a.useRef(null),Ae=a.useRef(null),Mt=a.useRef(null),ct=a.useRef(null),qe=a.useRef(""),Ye=a.useRef(""),ns=a.useCallback(async()=>{try{const s=await(await fetch(`${T}/storyteller/books/${g}`)).json(),n=s?.book||s;W(n);const o=(n.chapters||[]).sort((c,u)=>(c.sort_order??c.chapter_number??0)-(u.sort_order??u.chapter_number??0));return E(o),o}catch{return null}},[g]);a.useEffect(()=>{async function t(){try{const n=await(await fetch(`${T}/storyteller/books/${g}`)).json(),o=n?.book||n;W(o);const c=(o.chapters||[]).sort((M,b)=>(M.sort_order??M.chapter_number??0)-(b.sort_order??b.chapter_number??0));E(c);const u=c.find(M=>M.id===f);if(F(u||{id:f,title:"Chapter"}),u?.draft_prose&&(ae(u.draft_prose),ie(u.draft_prose.split(/\s+/).filter(Boolean).length)),u?.sections?.length>0){const M={};u.sections.forEach(N=>{N.id&&(M[N.id]=N.prose||"")}),Wt(M),ht.current=M;const b=u.sections.filter(N=>["h2","h3","h4"].includes(N.type)&&N.prose?.trim()).map(N=>N.prose).join(`

`);b.trim()&&(ae(b),ie(b.split(/\s+/).filter(Boolean).length))}const z=c.findIndex(M=>M.id===f);if(z>0){const M=c[z-1],b=M.draft_prose?.trim();if(b){const N=b.split(/\n\n+/).filter(Boolean),ee=N[N.length-1];Ht({title:M.title,excerpt:ee.length>200?ee.slice(0,200)+"…":ee,wordCount:b.split(/\s+/).filter(Boolean).length})}else Ht({title:M.title,excerpt:null,wordCount:0})}}catch{F({id:f,title:"Chapter"})}finally{Y(!1)}}t()},[g,f]),a.useEffect(()=>{async function t(){qt(!0);try{const n=await(await fetch(`${T}/character-registry/registries`)).json(),o=n.registries||n||[],c=[];for(const u of o){const M=await(await fetch(`${T}/character-registry/registries/${u.id}`)).json();(M.characters||M.registry?.characters||[]).forEach(N=>c.push({...N,_registryTitle:u.title||u.book_tag}))}Ss(c.filter(u=>u.status!=="declined"))}catch(s){console.error("Failed to load characters:",s)}qt(!1)}t()},[]),a.useEffect(()=>{const t=setInterval(()=>{Es(Math.floor((Date.now()-Qt)/1e3))},1e3);return()=>clearInterval(t)},[Qt]),a.useEffect(()=>{nt.current===0&&ue>0&&(nt.current=ue)},[ue]),a.useEffect(()=>{fetch(`${T}/character-registry/registries`).then(t=>t.json()).then(t=>{const s=t?.registries||t||[],n=Array.isArray(s)?s.flatMap(o=>o.characters||[]):[];Ps(n)}).catch(()=>{})},[]),a.useEffect(()=>{ge!=="review"||!f||Bt()},[ge,f]),a.useEffect(()=>{const t=document.createElement("style");return t.textContent=na,document.head.appendChild(t),()=>document.head.removeChild(t)},[]);const pe=a.useCallback(t=>{h.trim()&&Ds(s=>[...s.slice(-19),{prose:h,label:t,timestamp:Date.now(),wordCount:ue}])},[h,ue]),Dt=a.useCallback(async t=>{if(Z===null||_)return;const s=h.split(/\n\n+/),n=s[Z];if(n){if(t==="delete"){pe("Before delete paragraph");const c=s.filter((u,z)=>z!==Z).join(`

`);ae(c),ie(c.split(/\s+/).filter(Boolean).length),xe(!1),Ne(null),De(null);return}pe(`Before ${t} paragraph`),X(!0),De(t);try{const c=await(await fetch(`${T}/memories/story-edit`,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({current_prose:n,edit_note:t==="rewrite"?"Rewrite this paragraph with better prose, keeping the same meaning and tone.":"Expand this paragraph with more sensory detail, interiority, and emotional depth. Keep the same voice.",pnos_act:r?.pnos_act||"act_1",chapter_title:r?.title,character_id:$?.id||null})})).json();if(c.prose){const u=[...s];u[Z]=c.prose.trim();const z=u.join(`

`);ae(z),ie(z.split(/\s+/).filter(Boolean).length),xe(!1)}}catch(o){console.error("paragraph action error:",o)}X(!1),Ne(null),De(null)}},[h,Z,_,r,$,pe]);a.useEffect(()=>{if(ct.current&&clearTimeout(ct.current),!(!h||xt))return ct.current=setTimeout(()=>Ie(h),8e3),()=>clearTimeout(ct.current)},[h,xt]);const Ie=a.useCallback(async t=>{if(t){tt(!0);try{await fetch(`${T}/storyteller/chapters/${f}/save-draft`,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({draft_prose:t})});const s=ht.current;Object.keys(s).length>0&&F(n=>{if(n?.sections?.length>0){const o=n.sections.map(c=>({...c,prose:s[c.id]??c.prose??""}));return fetch(`${T}/storyteller/chapters/${f}`,{method:"PUT",headers:{"Content-Type":"application/json"},body:JSON.stringify({sections:o})}).catch(()=>{}),{...n,sections:o}}return n}),xe(!0)}catch{}tt(!1)}},[f]),rs=a.useCallback(()=>{if(!("webkitSpeechRecognition"in window)&&!("SpeechRecognition"in window)){bt("Voice not supported on this browser. Try Chrome.");return}const t=window.SpeechRecognition||window.webkitSpeechRecognition,s=new t;s.continuous=!0,s.interimResults=!0,s.lang="en-US",qe.current="",s.onresult=n=>{let o="",c=qe.current;for(let u=n.resultIndex;u<n.results.length;u++)n.results[u].isFinal?c+=n.results[u][0].transcript+" ":o=n.results[u][0].transcript;qe.current=c,ft(c+o)},s.onerror=n=>{n.error!=="no-speech"&&bt("Mic error — tap to retry"),st(!1)},s.onend=()=>st(!1),ss.current=s,s.start(),st(!0),bt(null),ft(""),qe.current=""},[]),is=a.useCallback(async t=>{pe("Before voice-to-story"),X(!0),Me("");try{const n=(await fetch(`${T}/memories/voice-to-story`,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({spoken:t,existing_prose:h,chapter_title:r?.title,chapter_brief:r?.scene_goal||r?.chapter_notes,pnos_act:r?.pnos_act||"act_1",book_character:w?.character||"JustAWoman",session_log:Vt.slice(-4),character_id:$?.id||null,gen_length:Ee,stream:!0})})).body.getReader(),o=new TextDecoder;let c="",u=null;for(;;){const{done:z,value:M}=await n.read();if(z)break;const N=o.decode(M,{stream:!0}).split(`
`);for(const ee of N)if(ee.startsWith("data: "))try{const Se=JSON.parse(ee.slice(6));Se.type==="text"?(c+=Se.text,Me(c),Ae.current&&(Ae.current.scrollTop=Ae.current.scrollHeight)):Se.type==="done"?u=Se.hint||null:Se.type==="error"&&console.error("voice-to-story stream error:",Se.error)}catch{}}if(c){const z=h?h.trimEnd()+`

`+c:c;ae(z),ie(z.split(/\s+/).filter(Boolean).length),xe(!1),_s(M=>[...M,{spoken:t,generated:c}]),u&&(D(u),setTimeout(()=>D(null),6e3))}}catch(s){console.error("voice-to-story error:",s)}Me(""),X(!1)},[h,r,w,Vt,Ee,$,pe]),zs=a.useCallback(async()=>{if(Ce){ss.current?.stop(),st(!1);const t=qe.current.trim();if(!t)return;ft(""),await is(t)}else rs()},[Ce,rs,is]),Fs=a.useCallback(()=>{const t=window.SpeechRecognition||window.webkitSpeechRecognition;if(!t)return;const s=new t;s.continuous=!0,s.interimResults=!0,s.lang="en-US",Ye.current="",s.onresult=n=>{let o="",c=Ye.current;for(let u=n.resultIndex;u<n.results.length;u++)n.results[u].isFinal?c+=n.results[u][0].transcript+" ":o=n.results[u][0].transcript;Ye.current=c,yt(c+o)},s.onend=()=>wt(!1),as.current=s,s.start(),wt(!0),Ye.current=""},[]),Is=a.useCallback(()=>{as.current?.stop(),wt(!1)},[]),Rs=a.useCallback(async()=>{if(Be.trim()){pe("Before edit"),X(!0);try{const s=await(await fetch(`${T}/memories/story-edit`,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({current_prose:h,edit_note:Be.trim(),pnos_act:r?.pnos_act||"act_1",chapter_title:r?.title})})).json();s.prose&&(ae(s.prose),ie(s.prose.split(/\s+/).filter(Boolean).length),xe(!1),yt(""),Ye.current="")}catch(t){console.error("story-edit error:",t)}X(!1)}},[h,Be,r,pe]),At=a.useCallback(async()=>{if(!_){pe("Before continue"),je("continue"),X(!0),vt(h),Ge(null),Me("");try{const t=await fetch(`${T}/memories/story-continue`,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({current_prose:h.trim()||`[Opening scene — ${r?.scene_goal||r?.chapter_notes||r?.title||"begin the chapter"}]`,chapter_title:r?.title||"Untitled Chapter",chapter_brief:r?.scene_goal||r?.chapter_notes||r?.title||"",pnos_act:r?.pnos_act||"act_1",book_character:w?.character||"JustAWoman",character_id:$?.id||null,gen_length:Ee,stream:!0,emotional_state_start:r?.emotional_state_start||"",emotional_state_end:r?.emotional_state_end||"",theme:r?.theme||w?.theme||"",pov:r?.pov||"",characters_present:r?.characters_present||"",sections:r?.sections||[],chapter_notes:r?.chapter_notes||"",tone:r?.tone||w?.tone||"",setting:r?.setting||w?.setting||"",conflict:r?.conflict||w?.conflict||"",stakes:r?.stakes||w?.stakes||"",hooks:r?.hooks||""})});if(!t.ok){try{const c=await t.json();D(c.error||`Server error (${t.status}) — please try again.`)}catch{D(`Server error (${t.status}) — please try again.`)}setTimeout(()=>D(null),5e3),Me(""),X(!1),je(null);return}const s=t.body.getReader(),n=new TextDecoder;let o="";for(;;){const{done:c,value:u}=await s.read();if(c)break;const M=n.decode(u,{stream:!0}).split(`
`);for(const b of M)if(b.startsWith("data: "))try{const N=JSON.parse(b.slice(6));N.type==="text"?(o+=N.text,Me(o),Ae.current&&(Ae.current.scrollTop=Ae.current.scrollHeight)):N.type==="error"&&(D(N.error),setTimeout(()=>D(null),5e3))}catch{}}if(o){const c=h.trim()?h.trimEnd()+`

`+o:o;ae(c),ie(c.split(/\s+/).filter(Boolean).length),xe(!1)}else D("No text generated — try again or write a few words first."),setTimeout(()=>D(null),5e3)}catch(t){console.error("story-continue error:",t),D("Connection error — check your server and try again."),setTimeout(()=>D(null),5e3)}Me(""),X(!1),je(null)}},[h,r,w,_,Ee,$,pe]),$t=a.useCallback(async()=>{if(!h.trim()||_){!h.trim()&&!_&&(D("Write some prose first — then Deepen will enrich it."),setTimeout(()=>D(null),4e3));return}pe("Before deepen"),je("deepen"),X(!0),vt(h),Ge(null);try{const t=await fetch(`${T}/memories/story-deepen`,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({current_prose:h,pnos_act:r?.pnos_act||"act_1",chapter_title:r?.title,character_id:$?.id||null,chapter_brief:r?.scene_goal||r?.chapter_notes||"",emotional_state_start:r?.emotional_state_start||"",emotional_state_end:r?.emotional_state_end||"",theme:r?.theme||w?.theme||"",pov:r?.pov||"",characters_present:r?.characters_present||"",tone:r?.tone||w?.tone||"",setting:r?.setting||w?.setting||"",conflict:r?.conflict||w?.conflict||"",stakes:r?.stakes||w?.stakes||""})});if(!t.ok){D(`Deepen failed (${t.status}) — please try again.`),setTimeout(()=>D(null),5e3),X(!1),je(null);return}const s=await t.json();s.prose?(ae(s.prose),ie(s.prose.split(/\s+/).filter(Boolean).length),xe(!1)):s.error&&(D(s.error),setTimeout(()=>D(null),5e3))}catch(t){console.error("story-deepen error:",t),D("Connection error — check your server and try again."),setTimeout(()=>D(null),5e3)}X(!1),je(null)},[h,r,_,$,pe]),Os=a.useCallback(async()=>{if(!_){je("nudge"),X(!0),Ge(null);try{const t=await fetch(`${T}/memories/story-nudge`,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({current_prose:h,chapter_title:r?.title,chapter_brief:r?.scene_goal||r?.chapter_notes,pnos_act:r?.pnos_act||"act_1",character_id:$?.id||null,emotional_state_start:r?.emotional_state_start||"",emotional_state_end:r?.emotional_state_end||"",theme:r?.theme||w?.theme||"",pov:r?.pov||"",characters_present:r?.characters_present||"",tone:r?.tone||w?.tone||"",setting:r?.setting||w?.setting||"",conflict:r?.conflict||w?.conflict||"",stakes:r?.stakes||w?.stakes||""})});if(!t.ok){D(`Nudge failed (${t.status}) — please try again.`),setTimeout(()=>D(null),5e3),X(!1),je(null);return}const s=await t.json();s.nudge&&Ge(s.nudge)}catch(t){console.error("story-nudge error:",t),D("Connection error — check your server and try again."),setTimeout(()=>D(null),5e3)}X(!1),je(null)}},[h,r,_,$]),Gs=a.useCallback(()=>{We!==null&&(ae(We),ie(We.split(/\s+/).filter(Boolean).length),xe(!1),vt(null))},[We]),Bt=a.useCallback(async()=>{Zt(!0);try{const s=await(await fetch(`${T}/storyteller/books/${g}`)).json(),o=((s?.book||s).chapters||[]).find(c=>c.id===f);lt(o?.lines||[])}catch{}Zt(!1)},[g,f]),os=async t=>{try{await fetch(`${T}/storyteller/lines/${t}`,{method:"PUT",headers:{"Content-Type":"application/json"},body:JSON.stringify({status:"approved"})});const s=ye.map(o=>o.id===t?{...o,status:"approved"}:o);lt(s);const n=ye.find(o=>o.id===t);n&&$s({...n,status:"approved"}),ls(s)}catch{}},Ws=async t=>{try{await fetch(`${T}/storyteller/lines/${t}`,{method:"DELETE"}),lt(s=>s.filter(n=>n.id!==t))}catch{}},Hs=t=>{Tt(t.id),Et(t.text||t.content||"")},Us=async()=>{try{await fetch(`${T}/storyteller/lines/${_t}`,{method:"PUT",headers:{"Content-Type":"application/json"},body:JSON.stringify({text:Ke,content:Ke,status:"edited"})});const t=ye.map(s=>s.id===_t?{...s,text:Ke,content:Ke,status:"edited"}:s);lt(t),Tt(null),Et(""),ls(t)}catch{}},Js=async()=>{const t=ye.filter(s=>s.status==="pending");for(const s of t)await os(s.id)},ls=a.useCallback(async t=>{const n=(t||ye).filter(c=>c.status==="approved"||c.status==="edited").sort((c,u)=>(c.sort_order??0)-(u.sort_order??0));if(n.length===0)return;const o=n.map(c=>c.text||c.content||"").join(`

`);ae(o),ie(o.split(/\s+/).filter(Boolean).length);try{await fetch(`${T}/storyteller/chapters/${f}/save-draft`,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({draft_prose:o})})}catch{}},[ye,f]),Ks=a.useCallback(async()=>{tt(!0);try{await fetch(`${T}/storyteller/chapters/${f}/save-draft`,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({draft_prose:h})});const s=await(await fetch(`${T}/storyteller/books/${g}`)).json(),c=((s?.book||s).chapters||[]).find(N=>N.id===f)?.lines||[],u=c.filter(N=>N.status==="approved"||N.status==="edited"),z=u.length>0?"append":"replace";if(u.length>0){const N=c.filter(ee=>ee.status==="pending"||ee.status==="rejected");for(const ee of N)try{await fetch(`${T}/storyteller/lines/${ee.id}`,{method:"DELETE"})}catch{}}const b=h.split(/\n\n+/).map(N=>N.trim()).filter(Boolean).map((N,ee)=>`LINE ${ee+1}
${N}`).join(`

`);await fetch(`${T}/storyteller/chapters/${f}/import`,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({raw_text:b,mode:z})}),$?.id&&h&&fetch(`${T}/storyteller/chapters/${f}/emotional-impact`,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({prose:h,character_id:$.id})}).catch(()=>{}),Je("review"),await Bt()}catch(t){console.error("sendToReview error:",t)}tt(!1)},[h,f,g,$,Bt]),qs=t=>{const s=t.target.value;ae(s),ie(s.split(/\s+/).filter(Boolean).length),xe(!1),dt(t.target)},dt=a.useCallback(t=>{!t||window.innerWidth>767||(t.style.height="auto",t.style.height=t.scrollHeight+"px")},[]);a.useEffect(()=>{Mt.current&&window.innerWidth<=767&&dt(Mt.current)},[h,He,dt]);const Ys=r?.sections?.length>0&&r.sections.some(t=>["h2","h3","h4"].includes(t.type)),Vs=a.useCallback((t,s)=>{Wt(n=>{const o={...n,[t]:s};ht.current=o;const c=(r?.sections||[]).filter(u=>["h2","h3","h4"].includes(u.type)).map(u=>o[u.id]||"").filter(Boolean).join(`

`);return ae(c),ie(c.split(/\s+/).filter(Boolean).length),xe(!1),o})},[r?.sections]),Ve=a.useCallback(()=>{Ts(t=>(t?(R(kt.current.toc),U(kt.current.ctx)):(kt.current={toc:I,ctx:te},R(!1),U(!1)),!t))},[I,te]);a.useEffect(()=>{const t=s=>{if((s.ctrlKey||s.metaKey)&&s.key==="Enter"&&(s.preventDefault(),!ve&&h.trim()&&!_&&At()),(s.ctrlKey||s.metaKey)&&s.key==="d"&&(s.preventDefault(),!ve&&h.trim()&&!_&&$t()),(s.ctrlKey||s.metaKey)&&s.key==="s"&&(s.preventDefault(),h&&Ie(h)),s.key==="Escape"){if(ve){js(!1);return}if(rt){it(!1);return}if(St){Ct(!1);return}if(Pe){Ve();return}if(Z!==null){Ne(null),De(null);return}if(l){d(null);return}if(ce){Q(!1);return}if(Te){se(null);return}}s.key==="F11"&&(s.preventDefault(),Ve()),(s.ctrlKey||s.metaKey)&&s.key==="["&&(s.preventDefault(),Re(-1)),(s.ctrlKey||s.metaKey)&&s.key==="]"&&(s.preventDefault(),Re(1)),(s.ctrlKey||s.metaKey)&&s.key==="b"&&(s.preventDefault(),R(n=>!n))};return window.addEventListener("keydown",t),()=>window.removeEventListener("keydown",t)},[ve,h,_,Pe,rt,St,Z,At,$t,Ie,Ve]),a.useEffect(()=>{localStorage.setItem("wm-show-toc",JSON.stringify(I))},[I]),a.useEffect(()=>{localStorage.setItem("wm-show-context",JSON.stringify(te))},[te]);const Pt=a.useCallback(async t=>{t!==f&&(h&&await Ie(h),H(`/chapter/${g}/${t}`))},[f,g,h,Ie,H]),Re=a.useCallback(t=>{const s=x.findIndex(o=>o.id===f);if(s<0)return;const n=x[s+t];n&&Pt(n.id)},[x,f,Pt]),Qs=a.useCallback(async()=>{if(re===null||le===null||re===le){J(null),he(null);return}const t=[...x],[s]=t.splice(re,1);t.splice(le,0,s),E(t),J(null),he(null);try{await Promise.all(t.map((n,o)=>fetch(`${T}/storyteller/chapters/${n.id}`,{method:"PUT",headers:{"Content-Type":"application/json"},body:JSON.stringify({sort_order:o+1})})))}catch(n){console.error("reorder error",n)}},[x,re,le]),cs=a.useCallback(async()=>{if(!l||!p.trim()){d(null);return}E(t=>t.map(s=>s.id===l?{...s,title:p.trim()}:s)),l===f&&F(t=>({...t,title:p.trim()})),d(null);try{await fetch(`${T}/storyteller/chapters/${l}`,{method:"PUT",headers:{"Content-Type":"application/json"},body:JSON.stringify({title:p.trim()})})}catch(t){console.error("rename error",t)}},[l,p,f]),Xs=a.useCallback(t=>{if(L===t){i(null),m([]);return}i(t);const s=x.find(o=>o.id===t),n=s?.sections&&Array.isArray(s.sections)?s.sections.map(o=>({...o,id:o.id||Ot()})):[];m(n)},[L,x]),ds=a.useCallback(async t=>{if(L)try{await fetch(`${T}/storyteller/chapters/${L}`,{method:"PUT",headers:{"Content-Type":"application/json"},body:JSON.stringify({sections:t})}),E(s=>s.map(n=>n.id===L?{...n,sections:t}:n)),L===f&&F(s=>({...s,sections:t}))}catch(s){console.error("save sections error",s)}},[L,f]);a.useEffect(()=>{if(!(!L||y.length===0))return clearTimeout(mt.current),mt.current=setTimeout(()=>ds(y),1500),()=>clearTimeout(mt.current)},[y,L,ds]);const Zs=a.useCallback((t="body")=>{const s={id:Ot(),type:t,content:""};m(n=>[...n,s]),Gt(!1),setTimeout(()=>{v(s.id),we("")},50)},[]),ps=a.useCallback(()=>{C&&(m(t=>t.map(s=>s.id===C?{...s,content:q}:s)),v(null))},[C,q]),ea=a.useCallback(t=>{m(s=>s.filter(n=>n.id!==t))},[]),ms=a.useCallback((t,s)=>{m(n=>{const o=n.findIndex(z=>z.id===t);if(o<0)return n;const c=o+s;if(c<0||c>=n.length)return n;const u=[...n];return[u[o],u[c]]=[u[c],u[o]],u})},[]),hs=a.useCallback(async()=>{const t=S.trim()||`Chapter ${x.length+1}`;Q(!1),K("");try{const n=await(await fetch(`${T}/storyteller/books/${g}/chapters`,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({title:t,chapter_number:x.length+1,sort_order:x.length+1})})).json(),o=n.chapter||n;E(c=>[...c,o])}catch(s){console.error("add chapter error",s)}},[g,x.length,S]),me=a.useCallback(async(t,s)=>{F(n=>({...n,[t]:s})),E(n=>n.map(o=>o.id===f?{...o,[t]:s}:o)),se(null);try{await fetch(`${T}/storyteller/chapters/${f}`,{method:"PUT",headers:{"Content-Type":"application/json"},body:JSON.stringify({[t]:s})})}catch(n){console.error("save context field error",n)}},[f]),Lt=a.useMemo(()=>{const t=x.length,s=x.filter(o=>o.draft_prose?.trim()).length,n=x.reduce((o,c)=>o+(c.draft_prose?c.draft_prose.split(/\s+/).filter(Boolean).length:0),0);return{total:t,written:s,totalWords:n}},[x]);if(j)return e.jsx("div",{className:"wm-load-screen",children:e.jsx(ta,{variant:"editor"})});const Qe=ye.filter(t=>t.status==="approved"||t.status==="edited"),ke=ye.filter(t=>t.status==="pending");function us(t,s){const n=_t===t.id,o=t.text||t.content||"";return e.jsxs("div",{className:`wm-review-line wm-review-line--${t.status}${n?" editing":""}`,children:[e.jsx("div",{className:"wm-review-line-content",children:n?e.jsxs(e.Fragment,{children:[e.jsx("textarea",{className:"wm-review-line-edit",value:Ke,onChange:c=>Et(c.target.value),autoFocus:!0}),e.jsxs("div",{className:"wm-review-line-edit-actions",children:[e.jsx("button",{className:"wm-review-save",onClick:Us,children:"Save"}),e.jsx("button",{className:"wm-review-cancel",onClick:()=>Tt(null),children:"Cancel"})]})]}):e.jsx("p",{className:`wm-review-line-text${s?" pending":""}`,children:o})}),!n&&e.jsxs("div",{className:"wm-review-line-actions",children:[s&&e.jsx("button",{className:"wm-line-approve",onClick:()=>os(t.id),title:"Approve",children:"✓"}),e.jsx("button",{className:"wm-line-edit",onClick:()=>Hs(t),title:"Edit",children:"✎"}),s&&e.jsx("button",{className:"wm-line-reject",onClick:()=>Ws(t.id),title:"Reject",children:"✕"})]})]},t.id)}return e.jsxs("div",{className:`wm-root${Pe?" wm-focus-mode":""}`,children:[Pe&&e.jsx("button",{className:"wm-focus-exit",onClick:Ve,title:"Exit focus mode (F11)",children:"✕"}),!A&&e.jsxs("header",{className:"wm-topbar",children:[e.jsx("button",{className:"wm-back-btn",onClick:()=>Nt(!0),children:"←"}),e.jsx("button",{className:`wm-sidebar-toggle${I?" active":""}`,onClick:()=>R(t=>!t),title:"Table of Contents (Ctrl+B)",children:"☰"}),e.jsxs("div",{className:"wm-chapter-info",children:[e.jsx("div",{className:"wm-chapter-title",children:r?.title||"Untitled"}),e.jsx("div",{className:"wm-book-title",children:w?.title||w?.character||""})]}),e.jsxs("div",{className:"wm-session-timer",children:[e.jsx("span",{className:"wm-timer-icon",children:"⏱"}),e.jsxs("span",{className:"wm-timer-value",children:[Math.floor(at/3600)>0&&`${Math.floor(at/3600)}:`,String(Math.floor(at%3600/60)).padStart(2,"0"),":",String(at%60).padStart(2,"0")]})]}),e.jsxs("div",{className:"wm-top-right",children:[e.jsxs("div",{className:"wm-quick-char-wrap",children:[e.jsxs("button",{className:"wm-quick-char-btn",onClick:()=>Fe(t=>!t),title:"Quick switch character",children:[e.jsx("span",{children:$?.icon||"👤"}),e.jsx("span",{className:"wm-quick-char-caret",children:ot?"▲":"▼"})]}),ot&&e.jsxs("div",{className:"wm-quick-char-dropdown",children:[e.jsxs("div",{className:`wm-quick-char-option${$?"":" selected"}`,onClick:()=>{Ue(null),Fe(!1)},children:[e.jsx("span",{className:"wm-quick-char-option-icon",children:"—"}),e.jsx("span",{children:"Narrator"})]}),jt.map(t=>e.jsxs("div",{className:`wm-quick-char-option${$?.id===t.id?" selected":""}`,onClick:()=>{Ue(t),Fe(!1)},children:[e.jsx("span",{className:"wm-quick-char-option-icon",children:t.icon||"👤"}),e.jsx("span",{children:t.display_name||t.selected_name})]},t.id))]})]}),ue>0&&e.jsxs("div",{className:"wm-word-count",onClick:()=>Ct(t=>!t),title:"Click to set word goal",children:[ue,"w",Le>0&&e.jsxs("span",{className:"wm-goal-fraction",children:[" / ",Le]})]}),e.jsx("div",{className:"wm-save-status",children:gt?"·· saving":xt?"":"· unsaved"}),e.jsxs("button",{className:`wm-history-btn${rt?" active":""}`,onClick:()=>it(t=>!t),title:`Snapshots (${ze.length})`,children:["📜",ze.length>0&&e.jsx("span",{className:"wm-history-badge",children:ze.length})]}),e.jsx("button",{className:`wm-focus-btn${Pe?" active":""}`,onClick:Ve,title:"Focus mode (F11)",children:"⛶"}),e.jsx("button",{className:`wm-sidebar-toggle wm-ctx-toggle${te?" active":""}`,onClick:()=>U(t=>!t),title:"Chapter context panel",children:"ℹ"})]})]}),Le>0&&e.jsxs("div",{className:"wm-goal-bar-wrap",children:[e.jsx("div",{className:"wm-goal-bar",children:e.jsx("div",{className:"wm-goal-fill",style:{width:`${Math.min(100,(ue-nt.current)/Le*100)}%`}})}),e.jsxs("span",{className:"wm-goal-label",children:[Math.max(0,ue-nt.current)," / ",Le," words this session"]})]}),St&&e.jsxs("div",{className:"wm-goal-input-wrap",children:[e.jsx("label",{className:"wm-goal-input-label",children:"Session word goal:"}),e.jsx("input",{className:"wm-goal-input",type:"number",min:0,step:50,value:Le,onChange:t=>{const s=parseInt(t.target.value)||0;Ms(s),localStorage.setItem("wm-word-goal",s)},placeholder:"e.g. 500"}),e.jsx("button",{className:"wm-goal-input-close",onClick:()=>Ct(!1),children:"✓"})]}),e.jsxs("div",{className:"wm-hub-layout",children:[O&&e.jsxs("aside",{className:"wm-toc-sidebar",children:[e.jsxs("div",{className:"wm-toc-header",children:[e.jsx("span",{className:"wm-toc-header-title",children:"Contents"}),e.jsxs("span",{className:"wm-toc-stats",children:[Lt.written,"/",Lt.total," · ",Lt.totalWords.toLocaleString(),"w"]})]}),e.jsx("div",{className:"wm-toc-list",children:x.map((t,s)=>{const n=t.id===f,o=t.draft_prose?t.draft_prose.split(/\s+/).filter(Boolean).length:0,c=L===t.id;t.sections&&Array.isArray(t.sections)&&t.sections.length>0;const u=t.chapter_type||"chapter",z=u==="prologue"?"◈":u==="epilogue"?"◇":u==="interlude"?"~":u==="afterword"?"∗":null,M=t.part_number&&(s===0||t.part_number!==x[s-1]?.part_number);return e.jsxs("div",{className:"wm-toc-chapter-group",children:[M&&e.jsx("div",{className:"wm-toc-part-divider",children:e.jsxs("span",{className:"wm-toc-part-label",children:["Part ",t.part_number,t.part_title?` — ${t.part_title}`:""]})}),e.jsxs("div",{className:`wm-toc-item${n?" current":""}${le===s?" drag-over":""}`,draggable:!0,onDragStart:()=>J(s),onDragOver:b=>{b.preventDefault(),he(s)},onDragEnd:Qs,onClick:()=>!l&&Pt(t.id),children:[e.jsx("span",{className:"wm-toc-drag",children:"≡"}),e.jsx("button",{className:`wm-toc-expand${c?" expanded":""}`,onClick:b=>{b.stopPropagation(),Xs(t.id)},title:c?"Collapse sections":"Show sections",children:"▸"}),e.jsx("span",{className:"wm-toc-num",children:t.chapter_number||s+1}),z&&e.jsx("span",{className:"wm-toc-type-badge",title:u,children:z}),l===t.id?e.jsx("input",{className:"wm-toc-edit-input",value:p,onChange:b=>P(b.target.value),onBlur:cs,onKeyDown:b=>{b.key==="Enter"&&cs(),b.key==="Escape"&&d(null)},autoFocus:!0,onClick:b=>b.stopPropagation()}):e.jsx("span",{className:"wm-toc-title",onDoubleClick:b=>{b.stopPropagation(),d(t.id),P(t.title||"")},children:t.title||"Untitled"}),e.jsx("span",{className:"wm-toc-words",children:o>0?`${o}w`:"—"})]}),c&&e.jsxs("div",{className:"wm-toc-sections",children:[y.length===0&&e.jsx("div",{className:"wm-toc-sec-empty",children:"No sections yet"}),y.map(b=>{const N=bs.find(ne=>ne.type===b.type)||{icon:"?",label:b.type},ee=ua.includes(b.type),Se=b.type==="divider";return e.jsxs("div",{className:`wm-toc-sec-item${ee?" is-header":""}${Se?" is-divider":""}`,children:[e.jsx("span",{className:"wm-toc-sec-icon",title:N.label,children:N.icon}),Se?e.jsx("span",{className:"wm-toc-sec-divider-line"}):C===b.id?e.jsx("input",{className:"wm-toc-sec-edit",value:q,onChange:ne=>we(ne.target.value),onBlur:ps,onKeyDown:ne=>{ne.key==="Enter"&&ps(),ne.key==="Escape"&&v(null)},placeholder:N.label+"…",autoFocus:!0}):e.jsx("span",{className:"wm-toc-sec-text",onClick:ne=>{ne.stopPropagation(),v(b.id),we(b.content||"")},children:b.content||e.jsx("span",{className:"wm-toc-sec-placeholder",children:N.label})}),e.jsxs("div",{className:"wm-toc-sec-actions",children:[e.jsx("button",{onClick:ne=>{ne.stopPropagation(),ms(b.id,-1)},title:"Move up",children:"↑"}),e.jsx("button",{onClick:ne=>{ne.stopPropagation(),ms(b.id,1)},title:"Move down",children:"↓"}),e.jsx("button",{className:"wm-toc-sec-del",onClick:ne=>{ne.stopPropagation(),ea(b.id)},title:"Delete",children:"×"})]})]},b.id)}),ws&&L===t.id?e.jsx("div",{className:"wm-toc-sec-type-menu",children:bs.map(b=>e.jsxs("button",{className:"wm-toc-sec-type-opt",onClick:()=>Zs(b.type),children:[e.jsx("span",{className:"wm-toc-sec-type-icon",children:b.icon})," ",b.label]},b.type))}):e.jsx("button",{className:"wm-toc-sec-add",onClick:b=>{b.stopPropagation(),Gt(!0)},children:"+ Add Section"})]})]},t.id)})}),ce?e.jsx("div",{className:"wm-toc-add-row",children:e.jsx("input",{className:"wm-toc-add-input",value:S,onChange:t=>K(t.target.value),onBlur:hs,onKeyDown:t=>{t.key==="Enter"&&hs(),t.key==="Escape"&&Q(!1)},placeholder:`Chapter ${x.length+1}`,autoFocus:!0})}):e.jsx("button",{className:"wm-toc-add-btn",onClick:()=>Q(!0),children:"+ Add Chapter"}),e.jsxs("div",{className:"wm-toc-nav",children:[e.jsxs("button",{className:"wm-toc-nav-btn",disabled:x.findIndex(t=>t.id===f)<=0,onClick:()=>Re(-1),children:["←"," Prev"]}),e.jsxs("button",{className:"wm-toc-nav-btn",disabled:x.findIndex(t=>t.id===f)>=x.length-1,onClick:()=>Re(1),children:["Next ","→"]})]})]}),e.jsxs("div",{className:"wm-main-col",children:[e.jsx("div",{className:"wm-center-tabs",children:ys.map(t=>e.jsxs("button",{className:`wm-center-tab${ge===t.id?" wm-center-tab--active":""}`,onClick:()=>Je(t.id),children:[t.label,t.id==="review"&&ke.length>0&&e.jsx("span",{className:"wm-tab-badge",children:ke.length})]},t.id))}),be&&e.jsxs("div",{className:"wm-mobile-bar",children:[e.jsxs("div",{className:"wm-mob-char-wrap",children:[e.jsxs("button",{className:"wm-mob-char-btn",onClick:()=>Fe(t=>!t),children:[e.jsx("span",{className:"wm-mob-char-icon",children:$?.icon||"👤"}),e.jsx("span",{className:"wm-mob-char-name",children:$?.display_name||$?.selected_name||"Narrator"}),e.jsx("span",{className:"wm-mob-char-caret",children:ot?"▲":"▼"})]}),ot&&e.jsxs("div",{className:"wm-mob-char-dropdown",children:[e.jsxs("button",{className:`wm-mob-char-option${$?"":" selected"}`,onClick:()=>{Ue(null),Fe(!1)},children:[e.jsx("span",{className:"wm-mob-char-opt-icon",children:"—"}),"Narrator"]}),jt.map(t=>e.jsxs("button",{className:`wm-mob-char-option${$?.id===t.id?" selected":""}`,onClick:()=>{Ue(t),Fe(!1)},children:[e.jsx("span",{className:"wm-mob-char-opt-icon",children:t.icon||"👤"}),t.display_name||t.selected_name]},t.id))]})]}),x.length>1&&e.jsxs("div",{className:"wm-mob-chapter-nav",children:[e.jsx("button",{className:"wm-mob-nav-btn",disabled:x.findIndex(t=>t.id===f)<=0,onClick:()=>Re(-1),children:"‹"}),e.jsx("span",{className:"wm-mob-nav-label",children:`${x.findIndex(s=>s.id===f)+1}/${x.length}`}),e.jsx("button",{className:"wm-mob-nav-btn",disabled:x.findIndex(t=>t.id===f)>=x.length-1,onClick:()=>Re(1),children:"›"})]}),ue>0&&e.jsxs("span",{className:"wm-mob-wc",children:[ue,"w"]})]}),ge==="write"&&e.jsxs(e.Fragment,{children:[e.jsx("div",{className:"wm-content-row",children:e.jsxs("div",{className:"wm-prose-wrap",ref:Ae,children:[e.jsxs("div",{className:"wm-manuscript-page",children:[e.jsx("div",{className:"wm-chapter-opening",children:e.jsx("h2",{className:"wm-chapter-heading",children:r?.title||"Untitled"})}),Ys?e.jsx("div",{className:"wm-canvas-sections",children:r.sections.map((t,s)=>{const n=["h2","h3","h4"].includes(t.type),o=t.type==="h2"&&t.content?.trim().toLowerCase()===(r?.title||"").trim().toLowerCase();return e.jsxs("div",{className:"wm-cs-block",children:[t.type==="divider"&&e.jsx("div",{className:"wm-cs-divider",children:e.jsx("span",{className:"wm-cs-divider-line"})}),t.type==="h2"&&!o&&e.jsx("h2",{className:"wm-cs-h2",children:t.content||"Untitled Section"}),t.type==="h3"&&e.jsx("h3",{className:"wm-cs-h3",children:t.content||"Untitled Section"}),t.type==="h4"&&e.jsx("h4",{className:"wm-cs-h4",children:t.content||"Untitled"}),t.type==="quote"&&e.jsx("blockquote",{className:"wm-cs-quote",children:t.content}),t.type==="reflection"&&e.jsx("div",{className:"wm-cs-reflection",children:t.content}),t.type==="body"&&e.jsx("p",{className:"wm-cs-body",children:t.content}),n&&e.jsx("textarea",{className:"wm-prose-area wm-section-prose",value:vs[t.id]||"",onChange:c=>{Vs(t.id,c.target.value),dt(c.target)},placeholder:`Write under ${t.content||"this section"}…`,spellCheck:!1,readOnly:_})]},t.id||s)})}):e.jsx("textarea",{className:"wm-prose-area",ref:Mt,value:He?h?h.trimEnd()+`

`+He:He:h,onChange:qs,placeholder:ve?"":"Begin writing…",spellCheck:!1,readOnly:_})]}),Ls&&e.jsxs("div",{className:"wm-ni-panel",children:[e.jsx("div",{className:"wm-ni-panel-header",children:e.jsx("span",{className:"wm-ni-label",children:"Narrative Intelligence"})}),e.jsx(xs,{chapter:r,lines:h.split(/\n\n+/).filter(t=>t.trim()).map((t,s)=>({id:`prose-${s}`,content:t,text:t,status:"approved"})),lineIndex:ts-1,book:w,characters:es})]}),!ve&&h.trim()&&e.jsx("div",{className:`wm-para-float-hint${Z!==null?" active":""}`,onClick:()=>{Z!==null?(Ne(null),De(null)):Ne(0)},title:"Paragraph actions",children:"¶"}),Z!==null&&e.jsx("div",{className:"wm-para-overlay",children:h.split(/\n\n+/).map((t,s)=>e.jsxs("div",{className:`wm-para-block${s===Z?" selected":""}`,onClick:()=>Ne(s===Z?null:s),children:[e.jsx("p",{children:t}),s===Z&&e.jsxs("div",{className:"wm-para-actions",children:[e.jsx("button",{onClick:n=>{n.stopPropagation(),Dt("rewrite")},disabled:_,children:_&&Xt==="rewrite"?"Rewriting…":"✎ Rewrite"}),e.jsx("button",{onClick:n=>{n.stopPropagation(),Dt("expand")},disabled:_,children:_&&Xt==="expand"?"Expanding…":"↔ Expand"}),e.jsx("button",{className:"wm-para-delete",onClick:n=>{n.stopPropagation(),Dt("delete")},disabled:_,children:"✗ Delete"}),e.jsx("button",{className:"wm-para-cancel",onClick:n=>{n.stopPropagation(),Ne(null),De(null)},children:"✕"})]})]},s))}),_&&!He&&e.jsxs("div",{className:"wm-generating",children:[e.jsxs("div",{className:"wm-generating-dots",children:[e.jsx("span",{className:"wm-generating-dot"}),e.jsx("span",{className:"wm-generating-dot"}),e.jsx("span",{className:"wm-generating-dot"})]}),e.jsx("div",{className:"wm-generating-label",children:_e==="continue"?"continuing your story":_e==="deepen"?"deepening the moment":_e==="nudge"?"thinking":"writing"})]}),Yt&&!_&&e.jsxs("div",{className:"wm-hint",children:[e.jsx("div",{className:"wm-hint-dot"}),e.jsx("div",{className:"wm-hint-text",children:Yt})]})]})}),Ce&&Ut&&e.jsx("div",{className:"wm-transcript",children:e.jsx("div",{className:"wm-transcript-text",children:Ut})}),Kt&&!_&&e.jsxs("div",{className:"wm-nudge",children:[e.jsx("div",{className:"wm-nudge-icon",children:"💡"}),e.jsx("div",{className:"wm-nudge-text",children:Kt}),e.jsx("button",{className:"wm-nudge-close",onClick:()=>Ge(null),children:"×"})]}),!ve&&e.jsxs("div",{className:"wm-ai-toolbar",children:[e.jsxs("button",{className:`wm-ai-btn${_e==="continue"?" active":""}`,onClick:At,disabled:_,title:h.trim()?"Continue writing":"Generate an opening for this chapter",children:[e.jsx("span",{className:"wm-ai-icon",children:"✨"})," Continue"]}),e.jsxs("button",{className:`wm-ai-btn${_e==="deepen"?" active":""}`,onClick:$t,disabled:_||!h.trim(),title:h.trim()?"Deepen the prose":"Write something first — then Deepen will enrich your text",children:[e.jsx("span",{className:"wm-ai-icon",children:"🔍"})," Deepen"]}),e.jsxs("button",{className:`wm-ai-btn${_e==="nudge"?" active":""}`,onClick:Os,disabled:_,title:"Get a creative writing prompt",children:[e.jsx("span",{className:"wm-ai-icon",children:"💡"})," Nudge"]}),We!==null&&!_&&e.jsxs("button",{className:"wm-ai-btn wm-undo-ai",onClick:Gs,children:[e.jsx("span",{className:"wm-ai-icon",children:"↩"})," Undo"]}),e.jsx("button",{className:`wm-len-toggle${Ee==="sentence"?" sentence":""}`,onClick:()=>{ks(t=>{const s=t==="paragraph"?"sentence":"paragraph";return D(s==="sentence"?"Continue will generate 1-2 sentences":"Continue will generate full paragraphs"),setTimeout(()=>D(null),3e3),s})},title:Ee==="sentence"?"Generating one sentence at a time":"Generating full paragraphs",children:Ee==="sentence"?"1 line":"¶ full"}),h.trim()&&e.jsxs("button",{className:`wm-ai-btn wm-para-mode-btn${Z!==null?" active":""}`,onClick:()=>{Z!==null?(Ne(null),De(null)):Ne(0)},title:"Paragraph-level actions",children:[e.jsx("span",{className:"wm-ai-icon",children:"¶"})," Paragraphs"]}),!h.trim()&&e.jsxs("span",{className:"wm-ai-hint",children:["Tap ",e.jsx("strong",{children:"Continue"})," to start writing — or ",e.jsx("strong",{children:"Nudge"})," for a creative prompt"]})]}),rt&&e.jsxs("div",{className:"wm-history-panel",children:[e.jsxs("div",{className:"wm-history-header",children:[e.jsx("span",{className:"wm-history-title",children:"Snapshots"}),e.jsx("button",{className:"wm-history-close",onClick:()=>it(!1),children:"×"})]}),ze.length===0?e.jsx("div",{className:"wm-history-empty",children:"No snapshots yet. Snapshots are taken automatically before each AI action."}):e.jsx("div",{className:"wm-history-list",children:[...ze].reverse().map((t,s)=>{ze.length-1-s;const n=new Date(t.timestamp),o=`${n.getHours()}:${String(n.getMinutes()).padStart(2,"0")}`;return e.jsxs("div",{className:"wm-history-item",children:[e.jsxs("div",{className:"wm-history-item-header",children:[e.jsx("span",{className:"wm-history-item-label",children:t.label}),e.jsxs("span",{className:"wm-history-item-meta",children:[o," · ",t.wordCount,"w"]})]}),e.jsx("div",{className:"wm-history-item-preview",children:t.prose.length>200?t.prose.slice(0,200)+"…":t.prose}),e.jsx("button",{className:"wm-history-restore",onClick:()=>{pe("Before restore"),ae(t.prose),ie(t.prose.split(/\s+/).filter(Boolean).length),xe(!1),it(!1)},children:"Restore this version"})]},s)})})]}),ve&&e.jsxs("div",{className:"wm-edit-panel",children:[e.jsx("div",{className:"wm-edit-label",children:"What needs to change?"}),e.jsxs("div",{className:"wm-edit-row",children:[e.jsx("textarea",{className:"wm-edit-input",value:Be,onChange:t=>yt(t.target.value),placeholder:"That part is right but she wouldn't say it that way...",rows:3}),e.jsx("button",{className:"wm-edit-mic-btn",onPointerDown:Fs,onPointerUp:Is,children:Ns?e.jsx("span",{className:"wm-mic-active-ring",children:"🎙"}):"🎙"})]}),e.jsx("button",{className:"wm-apply-btn",style:{opacity:Be.trim()?1:.35},onClick:Rs,disabled:!Be.trim()||_,children:_?"Rewriting…":"Apply →"})]}),Jt&&e.jsx("div",{className:"wm-mic-error",children:Jt}),!ve&&e.jsxs("div",{className:"wm-bottom-bar",children:[e.jsx("button",{className:`wm-mic-btn${Ce?" listening":""}`,onClick:zs,disabled:_,children:e.jsxs("svg",{width:"20",height:"20",viewBox:"0 0 28 28",fill:"none",children:[e.jsx("rect",{x:"9",y:"3",width:"10",height:"16",rx:"5",fill:Ce?"#F5F0E8":"#1a1a1a"}),e.jsx("path",{d:"M5 14c0 5 3.5 9 9 9s9-4 9-9",stroke:Ce?"#F5F0E8":"#1a1a1a",strokeWidth:"2",strokeLinecap:"round",fill:"none"}),e.jsx("line",{x1:"14",y1:"23",x2:"14",y2:"26",stroke:Ce?"#F5F0E8":"#1a1a1a",strokeWidth:"2",strokeLinecap:"round"})]})}),e.jsx("div",{className:"wm-bottom-hint",children:Ce?"Tap mic to stop & write":_?_e==="continue"?"Continuing…":_e==="deepen"?"Deepening…":"Writing your story…":h?"Tap mic to speak — or use AI tools above":"Tap mic to speak, or type and use AI tools"}),h.length>20&&e.jsx("button",{className:"wm-send-btn",onClick:Ks,disabled:gt,children:gt?"…":"→ Review"})]})]}),ge==="review"&&e.jsxs("div",{className:"wm-review-tab",children:[e.jsxs("div",{className:"wm-review-header",children:[e.jsxs("button",{className:"wm-review-back-btn",onClick:()=>Je("write"),children:["←"," Back to Write"]}),e.jsxs("div",{className:"wm-review-stats",children:[e.jsxs("span",{className:"wm-review-stat approved",children:[Qe.length," approved"]}),ke.length>0&&e.jsxs("span",{className:"wm-review-stat pending",children:[ke.length," pending"]}),e.jsxs("span",{className:"wm-review-stat total",children:[ye.length," total"]})]}),ke.length>0&&e.jsxs("button",{className:"wm-approve-all-btn",onClick:Js,children:["Approve all (",ke.length,")"]})]}),Bs?e.jsxs("div",{className:"wm-review-loading",children:["Loading lines","…"]}):ye.length===0?e.jsxs("div",{className:"wm-review-empty",children:[e.jsx("div",{className:"wm-review-empty-icon",children:"◌"}),e.jsxs("div",{className:"wm-review-empty-text",children:["No lines yet. Write in the Write tab and click ","→"," Review to send them here."]}),e.jsxs("button",{className:"wm-review-go-write",onClick:()=>Je("write"),children:["Go to Write tab ","→"]})]}):e.jsxs("div",{className:"wm-review-manuscript",children:[Qe.map((t,s)=>e.jsxs("div",{children:[us(t,!1),(s+1)%5===0&&s<Qe.length-1&&e.jsx("div",{className:"wm-ni-inline",children:e.jsx(xs,{chapter:r,lines:Qe.slice(Math.max(0,s-4),s+1),lineIndex:s,book:w,characters:es})})]},t.id)),e.jsx(ra,{chapter:r,lines:Qe,book:w,triggerLine:As}),ke.length>0&&e.jsxs("div",{className:"wm-pending-section",children:[e.jsxs("div",{className:"wm-pending-label",children:[ke.length," pending"]}),ke.map(t=>us(t,!0))]})]})]}),ge==="structure"&&e.jsx("div",{className:"wm-panel-tab",children:e.jsx(ha,{bookId:g,allChapters:x,onChapterUpdate:(t,s)=>{E(n=>n.map(o=>o.id===t?{...o,...s}:o))},onReloadChapters:ns})}),ge==="scenes"&&e.jsx("div",{className:"wm-panel-tab",children:e.jsx(ma,{bookId:g,chapters:x,onChaptersChange:ns,book:w})}),ge==="memory"&&e.jsx("div",{className:"wm-panel-tab",children:e.jsx(ia,{bookId:g})}),ge==="lala"&&e.jsx("div",{className:"wm-panel-tab",children:e.jsx(oa,{bookId:g})}),ge==="export"&&e.jsx("div",{className:"wm-panel-tab",children:e.jsx(la,{bookId:g})})]}),V&&e.jsxs("aside",{className:"wm-context-panel",children:[e.jsx("div",{className:"wm-ctx-header",children:e.jsxs("div",{className:"wm-ctx-tabs",children:[e.jsx("button",{className:`wm-ctx-tab${et==="plan"?" wm-ctx-tab--active":""}`,onClick:()=>ut("plan"),children:"Chapter Plan"}),e.jsxs("button",{className:`wm-ctx-tab${et==="ai-writer"?" wm-ctx-tab--active":""}`,onClick:()=>ut("ai-writer"),children:["✦"," Write"]})]})}),et==="ai-writer"&&e.jsx(da,{chapterId:f,bookId:g,selectedCharacter:$,characters:jt,onSelectCharacter:Ue,currentProse:h,chapterContext:{scene_goal:r?.scene_goal,theme:r?.theme,emotional_arc_start:r?.emotional_state_start,emotional_arc_end:r?.emotional_state_end,pov:r?.pov},onInsert:t=>{ae(s=>s?s+`

`+t:t)}}),et==="plan"&&e.jsxs(e.Fragment,{children:[e.jsxs("div",{className:"wm-ctx-field",children:[e.jsx("label",{className:"wm-ctx-label",children:"Scene Goal"}),Te==="scene_goal"?e.jsx("textarea",{className:"wm-ctx-input",value:G,onChange:t=>de(t.target.value),onBlur:()=>me("scene_goal",G),onKeyDown:t=>{t.key==="Enter"&&!t.shiftKey&&(t.preventDefault(),me("scene_goal",G)),t.key==="Escape"&&se(null)},rows:3,autoFocus:!0}):e.jsx("div",{className:"wm-ctx-value",onClick:()=>{se("scene_goal"),de(r?.scene_goal||"")},title:"Click to edit",children:r?.scene_goal||e.jsx("span",{className:"wm-ctx-empty",children:"What happens in this chapter?"})})]}),e.jsxs("div",{className:"wm-ctx-field",children:[e.jsx("label",{className:"wm-ctx-label",children:"Theme"}),Te==="theme"?e.jsx("input",{className:"wm-ctx-input",value:G,onChange:t=>de(t.target.value),onBlur:()=>me("theme",G),onKeyDown:t=>{t.key==="Enter"&&me("theme",G),t.key==="Escape"&&se(null)},autoFocus:!0}):e.jsx("div",{className:"wm-ctx-value",onClick:()=>{se("theme"),de(r?.theme||"")},children:r?.theme||e.jsx("span",{className:"wm-ctx-empty",children:"Central theme"})})]}),e.jsxs("div",{className:"wm-ctx-field",children:[e.jsx("label",{className:"wm-ctx-label",children:"Emotional Arc"}),e.jsxs("div",{className:"wm-ctx-arc",children:[Te==="emotional_state_start"?e.jsx("input",{className:"wm-ctx-input wm-ctx-input-sm",value:G,onChange:t=>de(t.target.value),onBlur:()=>me("emotional_state_start",G),onKeyDown:t=>{t.key==="Enter"&&me("emotional_state_start",G),t.key==="Escape"&&se(null)},placeholder:"Start",autoFocus:!0}):e.jsx("span",{className:"wm-ctx-arc-point",onClick:()=>{se("emotional_state_start"),de(r?.emotional_state_start||"")},children:r?.emotional_state_start||"Start"}),e.jsx("span",{className:"wm-ctx-arc-arrow",children:"→"}),Te==="emotional_state_end"?e.jsx("input",{className:"wm-ctx-input wm-ctx-input-sm",value:G,onChange:t=>de(t.target.value),onBlur:()=>me("emotional_state_end",G),onKeyDown:t=>{t.key==="Enter"&&me("emotional_state_end",G),t.key==="Escape"&&se(null)},placeholder:"End",autoFocus:!0}):e.jsx("span",{className:"wm-ctx-arc-point",onClick:()=>{se("emotional_state_end"),de(r?.emotional_state_end||"")},children:r?.emotional_state_end||"End"})]})]}),e.jsxs("div",{className:"wm-ctx-field",children:[e.jsx("label",{className:"wm-ctx-label",children:"POV"}),Te==="pov"?e.jsx("input",{className:"wm-ctx-input",value:G,onChange:t=>de(t.target.value),onBlur:()=>me("pov",G),onKeyDown:t=>{t.key==="Enter"&&me("pov",G),t.key==="Escape"&&se(null)},autoFocus:!0}):e.jsx("div",{className:"wm-ctx-value",onClick:()=>{se("pov"),de(r?.pov||"")},children:r?.pov||e.jsx("span",{className:"wm-ctx-empty",children:"Perspective"})})]}),e.jsxs("div",{className:"wm-ctx-field",children:[e.jsx("label",{className:"wm-ctx-label",children:"Notes"}),Te==="chapter_notes"?e.jsx("textarea",{className:"wm-ctx-input",value:G,onChange:t=>de(t.target.value),onBlur:()=>me("chapter_notes",G),onKeyDown:t=>{t.key==="Enter"&&!t.shiftKey&&(t.preventDefault(),me("chapter_notes",G)),t.key==="Escape"&&se(null)},rows:4,autoFocus:!0}):e.jsx("div",{className:"wm-ctx-value wm-ctx-notes",onClick:()=>{se("chapter_notes"),de(r?.chapter_notes||"")},children:r?.chapter_notes||e.jsx("span",{className:"wm-ctx-empty",children:"Reminders, ideas, references…"})})]}),Oe&&e.jsxs("div",{className:"wm-ctx-prev",children:[e.jsxs("label",{className:"wm-ctx-label",children:["Previous: ",Oe.title]}),e.jsxs("div",{className:"wm-ctx-prev-stats",children:[Oe.wordCount.toLocaleString()," words"]}),Oe.excerpt?e.jsxs("div",{className:"wm-ctx-prev-excerpt",children:["“",Oe.excerpt,"”"]}):e.jsx("div",{className:"wm-ctx-prev-excerpt wm-ctx-empty",children:"Not yet written"})]}),e.jsxs("button",{className:"wm-ctx-structure-link",onClick:()=>{I||R(!0),i(t=>{if(t!==f){const s=x.find(o=>o.id===f),n=s?.sections&&Array.isArray(s.sections)?s.sections.map(o=>({...o,id:o.id||Ot()})):[];m(n)}return f})},children:["☰"," Show Chapter Structure"]})]})]})]}),Cs&&e.jsx("div",{className:"wm-modal-overlay",onClick:()=>Nt(!1),children:e.jsxs("div",{className:"wm-modal",onClick:t=>t.stopPropagation(),children:[e.jsx("div",{className:"wm-modal-title",children:"Leave Write Mode?"}),e.jsx("div",{className:"wm-modal-sub",children:h?"Your draft is saved. You can come back.":"Nothing written yet."}),e.jsxs("div",{className:"wm-modal-btns",children:[e.jsx("button",{className:"wm-modal-cancel",onClick:()=>Nt(!1),children:"Stay"}),e.jsx("button",{className:"wm-modal-leave",onClick:async()=>{h&&await Ie(h),H(`/book/${g}`)},children:h?"Save & Leave":"Leave"})]})]})})]})}export{ja as default};
